# Paid Course Orders Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Let a signed-in learner order a paid published course through the existing manual-payment flow and receive server-enforced course access only after an administrator approves the receipt.

**Architecture:** Reuse `qnr_orders`, `qnr_order_items`, `qnr_manual_payments`, the existing `create-order` and `review-payment` Edge Functions, and `qnr_course_entitlements`. Make order lines explicitly either a physical product or a course. The database reads current prices, gives course-only orders zero shipping, prevents duplicate active purchases, and grants an entitlement atomically with payment approval.

**Tech Stack:** React 19, TypeScript, Supabase Postgres/RLS, Supabase Edge Functions (Deno), Node.js built-in test runner.

**Spec:** `C:/Users/user/Downloads/ابرپرامپت_بدون_پیشنیاز_چهل_تکه_دوزی_نقش_نگار.txt`, especially sections 9, 10, 21, 23, and 26.

## Global Constraints

- Preserve existing product checkout, private receipts, admin review, order history, PWA, and visual identity.
- Never trust a client price, user id, purchase status, or entitlement claim.
- Only published, priced courses in IRR can be purchased; a course line quantity is exactly one.
- Create entitlement only after an administrator's approved payment decision; rejected, pending, or expired payments grant none.
- Keep payment receipts private; keep secret keys only in Edge Function environment variables.
- Do not add runtime dependencies or invent course content, policy text, or store payment details.
- This checkout feature does not finish the larger app specification; unrelated incomplete areas remain separate work.

## Review Focus

1. A client submits a forged price or course id — assert the server prices from the published course row and rejects unavailable courses.
2. Two active orders are attempted for one learner/course — assert a pending or paid order blocks a duplicate.
3. A course-only order is placed — assert shipping is zero and no delivery address is required.
4. A mixed order includes products and courses — assert physical stock/shipping is handled and course lines do not consume inventory.
5. A payment is rejected or expires — assert no course entitlement is created; an approved payment creates exactly one entitlement.

---

### Task 1: Validate order line shapes

**Files:**
- Create: `supabase/functions/create-order/order-lines.ts`
- Create: `supabase/functions/create-order/order-lines.test.ts`
- Modify: `supabase/functions/create-order/index.ts`

**Interfaces:**
- Produces `parseOrderLines(raw: unknown)`, returning a typed list of `{ product_id, quantity }` or `{ course_id, quantity: 1 }`, or a stable validation error code.
- `create-order` remains authenticated and continues to derive the acting user from the verified JWT.

- [x] **Step 1: Write failing parser tests** for empty/oversized arrays, valid product lines, valid one-course lines, mixed lines, invalid UUIDs, both/no identifiers, and course quantity other than one.
- [x] **Step 2: Run** `node --experimental-strip-types --test supabase/functions/create-order/order-lines.test.ts`; confirm it fails because the parser module is absent.
- [x] **Step 3: Implement** the pure parser and use it in the Edge Function; map course availability/duplicate-order failures to a clear Persian 409 response.
- [x] **Step 4: Re-run** the same test command; all parser cases pass.

### Task 2: Extend the protected order and payment transaction

**Files:**
- Create: `supabase/migrations/20261022192829_qnr_course_orders.sql`
- Modify: remote Supabase schema through the Supabase migration tool.

**Interfaces:**
- `qnr_order_items` stores exactly one of `product_id` or `course_id`; existing product rows remain valid.
- `qnr_create_order(uuid, jsonb, text, jsonb, jsonb)` accepts the union of product and course lines.
- `qnr_review_payment(uuid, uuid, text, text)` grants purchase entitlements inside the same transaction that marks payment approved.

- [x] **Step 1: Record current schema and policies** for order items, published courses, entitlements, receipt storage, and payment review.
- [x] **Step 2: Extend the migration** with a nullable course foreign key, an exclusive product/course check, a course index, server-priced course validation, course-only shipping exemption, active-order duplicate guard, and approval-only entitlement grant.
- [x] **Step 3: Apply the versioned migration** to the connected project without modifying existing customer/order rows.
- [x] **Step 4: Verify** catalog constraints, function signatures/definitions, existing order-item readability, storage policies, and Supabase security/performance advisors.

### Task 3: Add course purchase to the learner flow

**Files:**
- Modify: `src/app/App.tsx`
- Modify: `src/theme.css`

**Interfaces:**
- `CourseDetail` continues to use `qnr_courses` and RLS-protected lesson queries.
- Paid-course submission invokes the existing `create-order` function with a course line, explicit privacy/terms consent, and a stable idempotency key.
- After success, show the server order number, server total, configured card destination, expiry, and link to `/orders` for receipt upload.

- [x] **Step 1: Implement course price/checkout states** for signed out, free, already enrolled, checkout unavailable, submitting, error, and created order.
- [x] **Step 2: Add Persian responsive styling** without changing unrelated route layouts.
- [ ] **Step 3: Verify** TypeScript build and inspect the course screen at narrow/mobile and desktop widths. The production build passed; visual course-detail inspection remains pending because the connected database has no published courses.

### Task 4: Close documentation and verification

**Files:**
- Modify: `README.md`
- Modify: `docs/superpowers/plans/2026-10-22-paid-course-orders.md`
- Create/update: `work/plans/2026-10-22-paid-course-orders-ledger.md`

- [x] **Step 1: Run** parser tests and `npm run build`.
- [x] **Step 2: Recheck** Supabase schema and both advisor classes; record any non-blocking unused-index suggestions separately.
- [x] **Step 3: Document** course purchase/receipt/approval behavior and any end-to-end verification limit that requires a real authenticated test account or configured store.
- [x] **Step 4: Review** changes for product-checkout regressions, entitlement bypasses, accidental secret exposure, and unverified success messages.

## Execution Notes

- The app folder is not a Git repository, so no branch, commit, or Git worktree can be used. A pre-change copy of every existing source file planned for modification is saved under `work/backups/2026-10-22-paid-course-orders/`.
- The user authorized native execution by asking to start building the full app and make reasonable product decisions. No subagents are used.
- A live end-to-end payment/entitlement test must not use real customer records or claim a payment; verify schema and function behavior safely and state any remaining limit.
- 2026-10-22 verification: parser tests passed 6/6; `npm run build` exited 0 and generated the PWA, with Vite's existing >500 kB single-chunk advisory. Supabase migration versions match the 18 local filenames; security advisors returned no lints, while performance advisors reported 24 INFO-level unused-index candidates. Visual inspection of a course detail at mobile/desktop widths remains pending because no course is published; purchase flow cannot be exercised until real course/store details are configured.
