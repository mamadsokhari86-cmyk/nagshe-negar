# Messaging Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build secure topic chats, opt-in direct messages, private course questions, image attachments, reports, blocks, and moderation on the existing Supabase app.

**Architecture:** Store rooms, memberships, messages, course-teacher assignments, blocks, reports, and idempotency state in Supabase with RLS. Public-schema RPC wrappers are invoker functions that call guarded private-schema functions; users cannot write message or membership tables directly. A JWT-verified Edge Function verifies and metadata-cleans private images before the caller-scoped message RPC attaches them.

**Tech Stack:** React 19, TypeScript, Supabase Postgres/RLS/Realtime/Storage/Edge Functions, existing Supabase JS client, Node built-in test runner.

**Spec:** `docs/superpowers/specs/2026-10-22-messaging-design.md`; product brief sections 15, 16, 20, 21, 26, and 27.

## Global Constraints

- Text is capped at 5,000 characters, images at 10 MiB, image rate at 10/day, messages at 30 per 5 minutes, and page size at 30.
- Direct-message directory shows only profiles with an explicit opt-in and never returns phone or email.
- Course Q&A requires an assigned teacher and actual course access for paid courses.
- Room membership and user identity are validated on the server; no direct message/room/report writes from clients.
- Attachments are private, room-bound, signature-checked, metadata-cleaned, and idempotent.
- Support conversations remain separate; no fake users, posts, messages, courses, or unread counts.

## Review Focus

1. A user guesses another room ID or file path — RLS withholds history and images.
2. A sender forges a different user/teacher role — server uses the signed-in actor and membership.
3. A non-opted-in or blocking user is searched/contacted — directory and creation RPC reject it.
4. A paid-course learner without entitlement asks a teacher — server rejects the question.
5. A message retry follows a timeout — stable nonce returns the original message and does not duplicate notifications.

---

### Task 1: Define and test text and idempotency rules

**Files:**
- Create: `supabase/functions/_shared/chat-validation.ts`
- Create: `supabase/functions/_shared/chat-validation.test.ts`
- Modify: `package.json`

**Interfaces:**
- `normalizeChatMessage(body: string)` returns trimmed plain text, or `empty`/`too_long`/`invalid_control_chars`.
- `isChatNonce(value: unknown)` accepts only RFC 4122 UUIDs.

- [ ] Add failing tests for whitespace, Persian text, 5,000/5,001 boundaries, empty body, forbidden control chars, and valid/invalid nonce.
- [ ] Implement helpers and rerun focused tests.

### Task 2: Add room, membership, message, privacy, and moderation schema

**Files:**
- Create versioned migration using `supabase migration new qnr_messaging_core`.
- Modify: `supabase/migrations/<new>_qnr_messaging_core.sql`

**Interfaces:**
- Tables: `qnr_chat_rooms`, `qnr_chat_room_members`, `qnr_chat_messages`, `qnr_chat_blocks`, `qnr_chat_reports`, `qnr_course_teachers`, `qnr_chat_upload_events`.
- Profile fields: `chat_handle` (unique nullable) and `allow_direct_messages` (default false).
- Rooms use topic/direct/course_qa types; messages use `client_nonce` unique per sender and optional `image_path`.
- Public RPC surface: `qnr_chat_list_rooms`, `qnr_chat_directory`, `qnr_chat_join_room`, `qnr_chat_start_direct`, `qnr_chat_ask_course_question`, `qnr_chat_history`, `qnr_chat_send_message`, `qnr_chat_mark_read`, `qnr_chat_block_user`, `qnr_chat_unblock_user`, `qnr_chat_report_message`, `qnr_chat_admin_reports`, `qnr_chat_moderate_member`, `qnr_chat_resolve_report`, `qnr_chat_assign_teacher`.

- [ ] Inspect profile, course entitlement, role, notification, and audit structures; confirm no messaging tables exist.
- [ ] Write migration with explicit grants, invoker wrappers, private definer functions, RLS policies, and indexes.
- [ ] Seed only three topic room records, never sample messages or user profiles.
- [ ] Apply migration once and verify direct-write denial, room/message RLS, role checks, indexes, and advisors.

### Task 3: Add protected image-message upload

**Files:**
- Create: `supabase/functions/chat-media/index.ts`
- Create: `supabase/functions/chat-media/deno.json`
- Modify migration: private `qnr-chat` bucket, storage RLS, upload registration table.
- Modify: `package.json` only if a dedicated test script is required.

**Interfaces:**
- `chat-media` supports `register` and `discard`; `verify_jwt=true`.
- `register` requires a signed-in user, active room membership, exact room UUID path, image signature/structure, size ≤10 MiB, metadata removal, caller-owned reupload, and then records a one-time server-verifiable upload ticket.
- `qnr_chat_send_message` attaches only a matching one-time ticket to the caller/room/nonce.

- [ ] Add tests for accepted/rejected image signatures, size limits, metadata stripping, and room-path mismatch.
- [ ] Add private bucket and RLS; deploy Edge Function.
- [ ] Verify attachments cannot be read outside the member room or before message registration.

### Task 4: Build community, DM, and moderation UI

**Files:**
- Create: `src/app/CommunityPage.tsx`, `src/app/community.css`.
- Modify: `src/app/App.tsx`, `src/app/theme.css` only if shared navigation needs adjustment.
- Modify `src/app/App.tsx` course detail for Q&A entry.
- Modify account profile form for handle and direct-message opt-in.

**Interfaces:**
- `/community` tabs: topic rooms, private chats, course questions; query parameter `room` selects a conversation.
- Room history reads 30 rows with cursor paging; Realtime listens only to the active room; sends use stable nonce, retry state, and member read timestamps.
- Public room join, direct-message opt-in directory, blocking, reporting, admin report queue, and moderator ban/mute controls call only server-approved RPCs.
- Course detail posts a course-bound question and links to its private thread.
- Image preview shows name/size/cancel/progress; >10 MiB uses the respectful Persian guidance; upload failure offers retry with the same nonce.

- [ ] Add loading/empty/error/guest/member/teacher/moderator states and desktop/mobile RTL styling.
- [ ] Implement room list, history paging, text send/retry, Realtime, and read receipts.
- [ ] Add direct-message profile opt-in/search/block and private-room creation.
- [ ] Add course-teacher assignment and course question entry from course detail.
- [ ] Add image preview/upload/retry/cancel and room-scoped signed display.
- [ ] Add report/moderation interface and refresh behavior.

### Task 5: Verify and document

**Files:**
- Modify: `README.md`.
- Update: this plan and `work/plans/2026-10-22-messaging-ledger.md`.

- [ ] Run chat validation and existing relevant tests.
- [ ] Build production app and inspect guest/member/mobile states.
- [ ] Verify security advisor has no findings; inspect actual room membership and storage policies.
- [ ] State whether authenticated end-to-end tests were possible; list external dependencies (SMS, Push, Android) separately.
- [ ] Keep the wider app goal active until remaining product requirements are completed.
