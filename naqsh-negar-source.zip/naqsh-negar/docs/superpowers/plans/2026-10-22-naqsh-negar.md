# نقش‌نگار Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Build the complete Persian quilting PWA connected to a dedicated Supabase backend, then package it for Android with Capacitor when Android tooling permits.

**Architecture:** Vite/React/TypeScript PWA; Supabase Auth/Postgres/RLS/Storage/Realtime and Edge Functions for privileged operations; Capacitor wraps the same web app for Android. New database objects use `qnr_` names and never modify the unrelated Supabase project.

**Tech Stack:** React 19, TypeScript, Vite, `@supabase/supabase-js`, Vitest, Playwright for end-to-end checks when available, Vite PWA support, Capacitor 8.

**Spec:** `docs/superpowers/specs/2026-10-22-naqsh-negar-design.md`

## Global Constraints

- Persian-first RTL UI, responsive from narrow Android screens through desktop.
- Server is the source of truth for identity, roles, prices, inventory, payments, learning entitlements, private messages, and files.
- Never ship secrets in frontend or APK; never use Supabase secret/service-role keys in client code.
- No fake business data, payment success, SMS, Push, course video, marketplace stats, or upload completion.
- Every `qnr_` exposed table has RLS, explicit least-privilege grants, and access tests.
- Migrations are additive and reversible; no changes to the unrelated project or its existing tables.
- Preserve form data on failure; show precise Persian loading, empty, offline, denied, and retry states.
- Run tests before claiming a feature is complete; report unavailable real-device/provider checks as untested.

## Review Focus

- Missing `.env.local` or disabled backend config: show a setup state; never silently swap to local fake data.
- Unauthenticated and role-tampered requests: server/RLS rejects management and private reads.
- Duplicate checkout/retry: idempotency prevents duplicate orders and payment decisions.
- Arabic/Persian numerals, long Persian labels, and narrow screens: layout remains readable and values format consistently.
- Upload interruption or over-limit/mismatched MIME: no published record or success state until the server confirms a complete valid object.

---

### Task 1: App shell, design system, routing, and installable PWA

**Files:** `package.json`, `vite.config.ts`, `index.html`, `public/patchwork.svg`, `src/app/**`, `src/lib/routes.ts`, `src/theme.css`.

**Interfaces:** Produces route layout and design primitives consumed by all feature modules; uses no business-data mock.

- [ ] Write tests for RTL document attributes, mobile navigation destinations, unknown-route handling, and visible backend-not-configured state.
- [ ] Run the targeted tests and confirm they fail for the missing app shell.
- [x] Implement the PWA app shell, textile/SVG motif, keyboard-accessible responsive navigation, and loading/error/empty/denied components.
- [x] Build the PWA and inspect the generated manifest/service worker. (Automated tests were not added or run.)

### Task 2: Supabase connection and identity/RLS foundation

**Files:** `src/lib/supabase.ts`, `.env.example`, `.gitignore`, `supabase/migrations/20261022_000001_qnr_foundation.sql`, `20261022_000002_qnr_private_helpers.sql`, `20261022_000003_qnr_content_audit.sql`, `20261022_000004_qnr_audit_trigger_return.sql`, `20261022_000005_qnr_published_prices.sql`.

**Interfaces:** Provides typed `supabase` client, environment validation, authenticated profile/permission hooks, and server-side permission contracts.

- [ ] Write tests that deny admin/private reads to anonymous and ordinary users and reject client role escalation.
- [ ] Verify tests fail before RLS policies exist.
- [x] Add additive `qnr_` profile/role/audit tables, explicit grants and RLS; no client-side role bootstrap is provided.
- [x] Add phone OTP UI against Supabase Auth; provider errors remain honest and no fake codes are shown. SMS delivery still needs provider setup.
- [x] Apply migrations and check Supabase security advisors. (Auth behavior cannot be exercised until SMS is configured.)

### Task 3: Content CMS, public home, and quilting education

**Files:** `src/app/App.tsx`, `src/lib/routes.ts`, `supabase/migrations/20261022_000001_qnr_foundation.sql`, `20261022_000003_qnr_content_audit.sql`.

**Interfaces:** Content queries return published content only; admin mutations require server permission; home consumes categories, learning items, and media from these queries.

- [ ] Write tests for published/unpublished visibility, category filters, Persian search, and admin-only editing.
- [x] Add products/categories, tutorials, courses/lessons/entitlements, site pages, and content audit tables with RLS. Media metadata and glossary CMS remain open.
- [x] Build CMS forms for products/tutorials/courses, public server-backed lists/details, and authored basic guide content. Course/video availability depends on real content and entitlements.
- [x] Add database audit triggers and inspect migration security. Category/page editing and persistence interaction checks remain open.

### Task 4: Store, cart, server-priced orders, and manual payment review

**Files:** `src/features/shop/**`, `src/features/cart/**`, `src/features/orders/**`, `src/features/admin/orders/**`, `supabase/migrations/20261022_000003_qnr_commerce.sql`, `supabase/functions/create-order/**`, `supabase/functions/review-payment/**`, `tests/commerce/**`.

**Interfaces:** `createOrder({ items, idempotencyKey })` calculates all totals from server records and returns a durable order; payment status advances only through authorized review.

- [ ] Write failing tests for tampered client prices, out-of-stock purchases, invalid discounts, duplicate order keys, receipt privacy, and unauthorized review.
- [ ] Implement transactional order creation and status audit, cart/favorites, receipt upload to private storage, settings for owner-entered card destination, and manual approve/reject with reason.
- [ ] Verify totals, stock concurrency, retry/idempotency, private receipt policies, and no entitlement before approved payment.

### Task 5: Learning access, progress, and playback

**Files:** `src/features/learning/**`, `src/features/admin/courses/**`, `supabase/migrations/20261022_000004_qnr_learning.sql`, `supabase/functions/lesson-access/**`, `tests/learning/**`.

**Interfaces:** Course page and player consume `lessonAccess(lessonId)`; progress/bookmarks are owned by the authenticated account; paid lesson access requires a valid entitlement.

- [ ] Write tests for free preview, paid lesson denial, buyer access, cross-account denial, and cross-device progress persistence.
- [ ] Implement curriculum/CMS, progress, bookmarks, notes, legitimate practice completion, signed media access, and mobile player controls including volume/brightness gestures with internal brightness fallback.
- [ ] Verify player states, signed URL expiration, and that public downloads cannot bypass course access.

### Task 6: Media uploads, chat, support, moderation, and notifications

**Files:** `src/features/media/**`, `src/features/messaging/**`, `src/features/support/**`, `src/features/notifications/**`, `src/features/admin/moderation/**`, `supabase/migrations/20261022_000005_qnr_social.sql`, `tests/social/**`.

**Interfaces:** Upload API exposes progress/cancel/retry; private attachment access checks conversation membership; notifications link only to resources the recipient can read.

- [ ] Write tests for file limits/type mismatch, interrupted uploads, message membership, role spoofing, reporting/ban effects, notification dedupe, and no sensitive lock-screen payload.
- [ ] Implement 50MB short-video and 10MB chat-image validation, resumable uploads only if backend supports them, group/direct/teacher/support messaging, moderation, inbox notifications, and notification preference controls.
- [ ] Implement Push only after a real VAPID/provider configuration; test push only when configured.
- [ ] Verify realtime status, private object policies, retry without duplicate messages, and over-limit error retention.

### Task 7: Quilt designer, calculators, project journal, gallery, and seller applications

**Files:** `src/features/designer/**`, `src/features/projects/**`, `src/features/gallery/**`, `src/features/sellers/**`, `supabase/migrations/20261022_000006_qnr_projects.sql`, `tests/designer/**`, `tests/community/**`.

**Interfaces:** Deterministic unit/yardage calculators accept explicit units, seam allowance, and waste factor; saved projects are owner-private until publication consent.

- [ ] Write tests for unit conversion, cutting sizes, fabric estimates, immutable saved designs, privacy consent, and ownership checks.
- [ ] Implement block builder, pattern/palette library, fabric/backing estimates, conversion, project journal/shopping list, tested export, consent-based gallery, real reviews/Q&A/challenges/reports, and seller application flow.
- [ ] Keep multi-seller order split and settlement inactive until end-to-end permissions, fees, payouts, and dispute handling are verified.
- [ ] Verify saved data sync, private/public transitions, export output, and report/block behavior.

### Task 8: Admin completeness, policies, accessibility, and Android packaging

**Files:** `src/features/admin/**`, `src/pages/policies/**`, `capacitor.config.ts`, `android/**` (generated only when SDK exists), `docs/OWNER-GUIDE.fa.md`, `docs/TEST-REPORT.fa.md`, `tests/e2e/**`.

**Interfaces:** Role-scoped dashboard links to real filtered records; manager edits persist; policy copy reflects actual configured features and collection practices.

- [ ] Write route tests for each role, deletion/export workflows, and policy links.
- [ ] Complete responsive admin, account deletion/data request, accessible policy and contact pages, operational guide, rollback/backup notes, and event-based notifications.
- [ ] Run full unit/integration/build checks; run browser checks on narrow Android-sized viewports and desktop.
- [ ] Package Capacitor APK only if Android SDK/signing setup is truly available; otherwise deliver PWA install instructions and label APK as unbuilt.
- [ ] Audit every capability in the spec, dependencies, unconfigured services, and tests before reporting readiness.
