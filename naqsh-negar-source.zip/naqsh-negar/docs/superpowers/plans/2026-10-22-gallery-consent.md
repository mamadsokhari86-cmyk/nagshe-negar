# Gallery With Creator Consent Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Turn `/gallery` from a placeholder into a server-backed, opt-in gallery with private drafts, consented public submissions, moderated publication, reports, and private image storage.

**Architecture:** Add an RLS-protected gallery submission/report schema and a private 10 MiB image bucket. Public gallery reads use a safe-column `security_invoker` view; creator/admin operations use narrowly scoped authenticated RPCs. The client checks image signatures and copy, the Edge Function repeats checks and strips embedded metadata, and Storage enforces independent file size and media-type limits.

**Tech Stack:** React 19, TypeScript, Supabase Postgres/RLS, Supabase Storage, Supabase JS, Node.js built-in test runner.

**Spec:** `docs/superpowers/specs/2026-10-22-gallery-consent-design.md`; source requirements `C:/Users/user/Downloads/ابرپرامپت_بدون_پیشنیاز_چهل_تکه_دوزی_نقش_نگار.txt`, sections 19, 23, 26, and 25.

## Global Constraints

- A private user project remains private; gallery submission copies only explicitly provided fields.
- No public appearance before affirmative consent and admin approval.
- No user identifiers, phone numbers, fake posts, reviews, ratings, or engagement counts appear in the public gallery.
- Images are limited to JPEG, PNG, WebP and 10 MiB; Storage is private, embedded metadata is removed before registration, and signed URLs expire after five minutes.
- Only server-verified admins can moderate. Reports are unique per reporter and post.
- Existing routes, RTL design, account flow, PWA, and order behavior stay intact.
- Do not add runtime dependencies or invent seller policies, payment data, or community content.

## Review Focus

1. A user uploads a spoofed image MIME type or file signature — reject it before Storage and keep bucket restrictions in place.
2. A user tries to publish another user's work or skip consent/moderation — reject the write in the database.
3. A guest requests pending/private images or user identifiers — RLS/RPC/view must withhold them.
4. A report is duplicated or submitted for a withdrawn/nonpublic post — enforce unique and status checks server-side.
5. A moderation request comes from a non-admin — reject it and make no audit/status change.

---

### Task 1: Test gallery input rules

**Files:**
- Create: `src/lib/gallery-validation.ts`
- Create: `src/lib/gallery-validation.test.ts`
- Create: `supabase/functions/_shared/gallery-validation.ts`
- Modify: `package.json`

**Interfaces:**
- `validateGalleryImage(file: { name: string; type: string; size: number; slice(start: number, end: number): Blob }): Promise<{ ok: true; extension: 'jpg' | 'png' | 'webp'; mimeType: string } | { ok: false; error: 'too_large' | 'unsupported_type' | 'invalid_signature' }>` lives in `_shared` and is imported by both the web app and Edge Function.
- `normalizeGalleryText(title: string, caption: string)` trims input and returns a stable validation result for a 2–100 character title and a caption up to 1000 characters.

- [x] Write tests for exact 10 MiB acceptance and 10 MiB + 1 rejection, valid JPEG/PNG/WebP signatures, MIME/signature mismatch, SVG rejection, and text bounds.
- [x] Run the focused test command and confirm failures are caused by the missing helper.
- [x] Implement the pure validation helpers and metadata stripping.
- [x] Re-run focused tests and confirm all cases pass.

### Task 2: Add protected gallery data and Storage

**Files:**
- Create: `supabase/migrations/<version>_qnr_gallery_consent.sql` using `supabase migration new`.
- Create: `supabase/functions/gallery-manage/index.ts` and its `deno.json`.
- Modify: remote Supabase schema once, after reviewing the complete migration.

**Interfaces:**
- `qnr_gallery_posts` stores private drafts and public submissions with owner, explicit consent, review status, bounded metadata, and optional image path.
- `qnr_gallery_reports` stores one report per authenticated user/post.
- `qnr_public_gallery_posts` is a safe-column, `security_invoker` view.
- `gallery-manage` authenticates the caller, downloads their uploaded object through user-scoped Storage access, verifies the bytes again, then inserts the post with service credentials. It also handles owner-checked post deletion and safe cleanup of unattached uploads.
- `qnr_my_gallery_posts()`, `qnr_admin_gallery_queue()`, `qnr_admin_gallery_reports()`, `qnr_report_gallery_post(uuid,text,text)`, `qnr_moderate_gallery_post(uuid,text,text)`, and `qnr_admin_resolve_gallery_report(uuid,text,text)` enforce ownership/admin checks and return only necessary fields.
- `qnr-gallery` Storage bucket is private, 10 MiB, JPEG/PNG/WebP only.

- [x] Inspect current table grants, role helper, Storage schema, and bucket names; record before state.
- [x] Create local versioned migrations and review constraints, RLS, RPC grants, audit logging, upload limits, and Storage policies. Clients cannot directly insert/delete gallery rows.
- [x] Apply to Supabase; no owner content was added or changed.
- [x] Verify the table/view/functions, denied direct access, Storage restrictions, migration ledger, and Supabase security/performance advisors.

### Task 3: Implement gallery creation and reading

**Files:**
- Modify: `src/app/App.tsx`
- Modify: `src/theme.css`
- Modify: `src/lib/routes.ts` only if copy needs adjustment.

**Interfaces:**
- `/gallery` reads approved cards from `qnr_public_gallery_posts` and the signed-in user's own drafts/submissions from `qnr_my_gallery_posts()`.
- The create form uploads a verified image to the private bucket, creates a private draft or public pending submission, and compensates failed writes by removing the object when possible.
- Public filtering uses the server fields for topic, use, difficulty, and color family.
- Report uses `qnr_report_gallery_post` and has no effect until the server records it.

- [x] Implement gallery states for guest, loading, empty, error, signed-in creator, and submission confirmation.
- [x] Add explicit private/public choice, separate public consent, image preview, upload/error/cleanup handling, and deletion confirmation.
- [x] Add signed image URLs, filters, own submissions, and report flow.
- [x] Add responsive Persian RTL styling and truthful consent copy for user-published work.

### Task 4: Add moderation and audit flow

**Files:**
- Modify: `src/app/App.tsx`
- Modify: `src/theme.css`

- [x] Add an admin-only queue using `qnr_admin_gallery_queue()` and `qnr_admin_gallery_reports()`.
- [x] Support approve, reject, and hide with a bounded optional reason; only RPC results may confirm a decision.
- [x] Refresh public cards and creator status after moderation and show only actual server counts.

### Task 5: Verify and document

**Files:**
- Modify: `README.md`
- Update: this plan and `work/plans/2026-10-22-gallery-consent-ledger.md`.

- [x] Run the focused unit tests and `npm run build`.
- [x] Verify public/owner/admin policy grants, report uniqueness, Storage policy, Supabase advisors, and migration parity.
- [ ] Inspect guest/creator/admin empty states and responsive layouts; state if authenticated E2E is unavailable.
- [x] Review against the spec and update the remaining-feature list without claiming full app completion.
