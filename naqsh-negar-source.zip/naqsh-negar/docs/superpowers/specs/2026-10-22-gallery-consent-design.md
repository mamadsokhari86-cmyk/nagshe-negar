# نقش‌نگار Gallery With Creator Consent

## Context and intent

The product brief asks for a real gallery/community with creator permission, privacy choices, moderation, reports, and no invented work or engagement counts. The current `/gallery` route is an empty-state placeholder; `qnr_projects` is private and should stay that way unless a user deliberately submits an independent copy for review.

## Design decision

Build a user-submitted gallery at `/gallery`. Signed-in users can save a private draft or request public publication. Public sharing requires a separate, unchecked consent control. A public submission remains pending until an administrator approves it. The feed includes only approved, consented submissions. A creator may withdraw any submission by deleting it. Public cards show the artwork's title, description, subject, intended use, difficulty, selected color family, and optional image; they do not reveal account identifiers, phone numbers, or profile details.

Images use a private Supabase Storage bucket. The interface accepts JPEG, PNG, and WebP up to 10 MiB and checks the file signature before upload. A server function then reads the uploaded object under the caller's Storage permissions, repeats the signature/size check, removes embedded EXIF, text, location, and color-profile metadata, stores the cleaned image, and only then registers the post. Bucket-level size/content-type restrictions provide another boundary. Owners and authorized moderators can read pending images; the public can obtain short-lived signed URLs only for approved work. Uploaded content must not be presented as licensed, verified, or owned by the platform.

Readers can report an approved work with a reason and optional note. A unique reporter/work pair prevents duplicate reports. The admin queue can approve, reject, or hide a submission and review reports. Moderation actions are server-authorized, audited, and recorded with a note. No likes, reviews, ratings, challenge badges, or counts are added in this phase, so the gallery cannot show fabricated engagement.

Private drafts and public submissions live in a new gallery table and never mutate or expose a user's saved `qnr_projects`. Public reads use a safe-column `security_invoker` view. Owner and admin queues use authenticated, narrowly scoped RPCs so the public API does not disclose owner IDs or moderation-only metadata.

## Data and access rules

- New `qnr_gallery_posts` rows have an authenticated owner, bounded text, constrained subject/use/difficulty/color fields, private/public visibility, consent timestamp, moderation status, required image path, and review metadata.
- New `qnr_gallery_reports` rows are visible only to the reporting user through a safe RPC and to admins through a separate queue RPC.
- Row-level security allows public access only to public, approved, consented work; owners can read their own items; only the authenticated server function can create/delete posts, and only admins can moderate.
- Private Storage bucket `qnr-gallery` is limited to JPEG/PNG/WebP and 10 MiB per object. Storage RLS ties upload/read to the uploader and read access to an admin or an approved post; the authenticated server function handles deletion.
- Public image links expire after five minutes. Removing a post removes it from the feed immediately; an already issued signed URL may work until it expires, and copies made by viewers cannot be recalled.
- Gallery consent describes the exact displayed fields, states that the user's name and phone are not shown, and explains that anyone can copy an approved image. Deleting a submission withdraws it from the app.

## User experience

The Persian RTL page has a public feed, real filters, an empty/loading/error state, a private "آثار من" list, a submission form, and an optional image preview. The submit control stays disabled until valid image data is confirmed and the requested visibility is selected; public publication additionally requires explicit consent. Guests may browse approved work and are prompted to sign in to submit or report.

Admins see a moderation queue on the same page after server role verification. Approve/reject/hide actions refresh the queue and public feed. Report reasons and any moderator note are shown only to authorized staff and the submitting creator where applicable.

## Failure behavior and scope

Storage quota or network failures are shown directly; failed post creation attempts remove an uploaded orphan when possible. The app must never claim a submission is public before approval. The app must not insert seed users, posts, counts, or sample photos. This phase implements gallery publication and moderation; private/group chat, teacher questions, seller onboarding, and broader community comments remain separate work.

## Verification

Unit tests cover accepted/rejected file signatures, 10 MiB limits, media type mismatches, safe image extensions, and bounded text. Apply the versioned database migration, verify RLS/view/RPC catalog state and Storage bucket restrictions, run Supabase security/performance advisors, run the focused test suite and production build, then inspect the gallery at narrow and desktop widths. A live authenticated upload/moderation test is only claimed if a real test account is available.
