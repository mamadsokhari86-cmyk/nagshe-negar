import { useEffect, useState, type FormEvent } from 'react'
import { Link, NavLink, Route, Routes, useLocation, useParams, useSearchParams } from 'react-router-dom'
import { ArrowLeft, Bell, BookOpen, Bookmark, Check, Compass, Home, Menu, MessageCircle, ShoppingBag, ShoppingCart, UserRound, X } from 'lucide-react'
import { EmptyState } from './EmptyState'
import { PatchworkMark } from './PatchworkMark'
import { backendMessage, supabase, supabaseConfigured } from '../lib/supabase'
import { routeInfo } from '../lib/routes'
import { GalleryPage } from './GalleryPage'
import { CommunityPage } from './CommunityPage'

const bottomLinks = [
  { to: '/', label: 'خانه', Icon: Home },
  { to: '/shop', label: 'فروشگاه', Icon: ShoppingBag },
  { to: '/learn', label: 'یادگیری', Icon: BookOpen },
  { to: '/projects', label: 'پروژه‌ها', Icon: Compass },
  { to: '/account', label: 'حساب', Icon: UserRound },
]

const moreLinks = [
  ['/courses', 'دوره‌ها'], ['/guide', 'دانشنامه'], ['/designer', 'طراح بلوک'], ['/gallery', 'گالری'],
  ['/community', 'گفت‌وگو'], ['/seller', 'فروشندگی'], ['/support', 'پشتیبانی'], ['/orders', 'سفارش‌ها'], ['/notifications', 'اعلان‌ها'], ['/admin', 'مدیریت'],
]

function Header() {
  const [menuOpen, setMenuOpen] = useState(false)
  return (
    <header className="site-header">
      <div className="header-inner">
        <Link className="brand" to="/" aria-label="نقش‌نگار، صفحهٔ خانه">
          <PatchworkMark className="brand__mark" />
          <span><strong>نقش‌نگار</strong><small>چهل‌تکه‌دوزی</small></span>
        </Link>
        <nav className="desktop-nav" aria-label="ناوبری اصلی">
          {bottomLinks.slice(0, 4).map(({ to, label }) => <NavLink key={to} to={to} end={to === '/'}>{label}</NavLink>)}
          <NavLink to="/designer">طراح بلوک</NavLink>
        </nav>
        <div className="header-actions">
          <Link className="icon-button" to="/notifications" aria-label="اعلان‌ها"><Bell size={19} /></Link>
          <Link className="icon-button support-shortcut" to="/support" aria-label="پشتیبانی"><MessageCircle size={19} /></Link>
          <Link className="icon-button" to="/cart" aria-label="سبد خرید"><ShoppingCart size={20} /></Link>
          <button className="icon-button menu-trigger" onClick={() => setMenuOpen(!menuOpen)} aria-label={menuOpen ? 'بستن منو' : 'باز کردن منو'} aria-expanded={menuOpen}>
            {menuOpen ? <X size={20} /> : <Menu size={20} />}
          </button>
        </div>
      </div>
      {menuOpen && <nav className="more-menu" aria-label="بخش‌های دیگر">
        {moreLinks.map(([to, label]) => <Link onClick={() => setMenuOpen(false)} key={to} to={to}>{label}</Link>)}
        <Link onClick={() => setMenuOpen(false)} to="/about">درباره</Link>
        <Link onClick={() => setMenuOpen(false)} to="/privacy">حریم خصوصی</Link>
        <Link onClick={() => setMenuOpen(false)} to="/terms">شرایط استفاده</Link>
      </nav>}
    </header>
  )
}

function BottomNav() {
  return <nav className="bottom-nav" aria-label="ناوبری موبایل">
    {bottomLinks.map(({ to, label, Icon }) => <NavLink key={to} to={to} end={to === '/'}>
      <Icon size={20} strokeWidth={1.8} /><span>{label}</span>
    </NavLink>)}
  </nav>
}

function ConnectionNotice() {
  return <div className={`connection-notice ${supabaseConfigured ? 'is-connected' : ''}`} role="status">
    <span className="connection-dot" />{backendMessage()}
  </div>
}

function HomePage() {
  return <>
    <section className="hero">
      <div className="hero__copy">
        <span className="eyebrow">هنرِ کنار هم نشاندن تکه‌ها</span>
        <h1>هر تکه<br /><em>قصه‌ای دارد</em></h1>
        <p>با چند تکه پارچه، طرحی تازه بساز. از یک دوخت ساده شروع کن و آرام‌آرام سبک خودت را پیدا کن.</p>
        <div className="hero__actions">
          <Link className="button button--primary" to="/learn">شروع یادگیری <ArrowLeft size={17} /></Link>
          <Link className="text-link" to="/designer">رفتن به طراح بلوک</Link>
        </div>
      </div>
      <div className="hero__art" aria-hidden="true">
        <div className="hero__orbit hero__orbit--one" /><div className="hero__orbit hero__orbit--two" />
        <PatchworkMark className="hero__mark" />
        <span className="stitch stitch--one" /><span className="stitch stitch--two" />
      </div>
      <span className="hero__caption">یک شروع کوچک، یک اثر ماندگار</span>
    </section>

    <ConnectionNotice />

    <section className="pathways" aria-labelledby="pathways-title">
      <div className="section-heading"><div><span className="eyebrow">راه خودت را پیدا کن</span><h2 id="pathways-title">از کجا شروع کنیم؟</h2></div><span className="section-heading__ornament" aria-hidden="true">✳</span></div>
      <div className="pathway-grid">
        <Link className="pathway-card pathway-card--learn" to="/learn"><span className="pathway-card__icon"><BookOpen /></span><span className="pathway-card__title">یاد بگیر</span><span className="pathway-card__text">آشنایی با ابزارها، برش و دوخت پایه</span><span className="pathway-card__arrow"><ArrowLeft size={18} /></span></Link>
        <Link className="pathway-card pathway-card--design" to="/designer"><span className="pathway-card__icon"><Compass /></span><span className="pathway-card__title">طراحی کن</span><span className="pathway-card__text">بلوک خودت را بچین و اندازه‌ها را ببین</span><span className="pathway-card__arrow"><ArrowLeft size={18} /></span></Link>
        <Link className="pathway-card pathway-card--shop" to="/shop"><span className="pathway-card__icon"><ShoppingBag /></span><span className="pathway-card__title">کشف کن</span><span className="pathway-card__text">ابزارها و پارچه‌ها، وقتی فروشگاه آماده باشد</span><span className="pathway-card__arrow"><ArrowLeft size={18} /></span></Link>
      </div>
    </section>

    <section className="home-note"><div className="home-note__stamp">✿</div><div><span className="eyebrow">با حوصله و دست‌های خودت</span><h2>لازم نیست کامل باشد؛<br />فقط از یک تکه شروع کن.</h2></div><Link to="/guide" className="text-link">دیدن دانشنامه <ArrowLeft size={16} /></Link></section>
  </>
}

function GuidePage() {
  return <>
    <PageIntro path="/guide" />
    <div className="editorial-grid">
      <article className="editorial-card editorial-card--large"><span className="editorial-card__number">۰۱</span><span className="eyebrow">آماده‌سازی</span><h2>پیش از اولین برش</h2><p>پارچه را بشوی و اتو کن تا آبرفت آن پیش از دوخت انجام شود. پارچهٔ خشک را روی سطح صاف بگذار، راستای تار را پیدا کن و سپس اندازه بگیر.</p><div className="tag-row"><span>پارچه</span><span>ابزار پایه</span><span>شروع</span></div></article>
      <article className="editorial-card"><span className="editorial-card__number">۰۲</span><span className="eyebrow">اندازه‌گیری</span><h2>جای دوخت را حساب کن</h2><p>اندازهٔ برش را برابر اندازهٔ نهایی تکه به‌علاوهٔ دو جای دوخت بگیر. اگر جای دوخت یک‌چهارم اینچ است، دو برابر آن را به هر ضلع اضافه کن.</p></article>
      <article className="editorial-card"><span className="editorial-card__number">۰۳</span><span className="eyebrow">واژه‌نامه</span><h2>بلوک چهل‌تکه</h2><p>واحدی از تکه‌های دوخته‌شده که با کنار هم قرار گرفتن، بخشی از نقش نهایی quilt را می‌سازد.</p></article>
    </div>
    <p className="editorial-source">این راهنما محتوای آموزشی پایهٔ نقش‌نگار است؛ مطالب تازه پس از بازبینی در همین‌جا افزوده می‌شوند.</p>
  </>
}

type ContentItem = {
  id: string
  slug: string
  title: string
  summary: string
  price_amount?: number | null
  currency?: string
  inventory_count?: number
  level?: string
  duration_minutes?: number | null
}

type CollectionKind = 'products' | 'tutorials' | 'courses'

async function fetchCollection(kind: CollectionKind): Promise<ContentItem[]> {
  if (!supabase) throw new Error('backend-not-configured')
  if (kind === 'products') {
    const { data, error } = await supabase.from('qnr_products').select('id,slug,name,description,price_amount,currency,inventory_count').eq('is_published', true).order('created_at', { ascending: false })
    if (error) throw error
    return ((data ?? []) as Array<{ id: string; slug: string; name: string; description: string; price_amount: number | null; currency: string; inventory_count: number }>).map((row) => ({ id: row.id, slug: row.slug, title: row.name, summary: row.description, price_amount: row.price_amount, currency: row.currency, inventory_count: row.inventory_count }))
  }
  if (kind === 'tutorials') {
    const { data, error } = await supabase.from('qnr_tutorials').select('id,slug,title,summary,level,duration_minutes').eq('is_published', true).order('published_at', { ascending: false })
    if (error) throw error
    return ((data ?? []) as Array<{ id: string; slug: string; title: string; summary: string; level: string; duration_minutes: number | null }>).map((row) => ({ id: row.id, slug: row.slug, title: row.title, summary: row.summary, level: row.level, duration_minutes: row.duration_minutes }))
  }
  const { data, error } = await supabase.from('qnr_courses').select('id,slug,title,summary,price_amount,currency').eq('is_published', true).order('published_at', { ascending: false })
  if (error) throw error
  return ((data ?? []) as Array<{ id: string; slug: string; title: string; summary: string; price_amount: number | null; currency: string }>).map((row) => ({ id: row.id, slug: row.slug, title: row.title, summary: row.summary, price_amount: row.price_amount, currency: row.currency }))
}

function PublicCollection({ kind }: { kind: CollectionKind }) {
  const [items, setItems] = useState<ContentItem[]>([])
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  useEffect(() => {
    let current = true
    if (!supabase) { setStatus('offline'); return () => { current = false } }
    setStatus('loading')
    fetchCollection(kind).then((rows) => { if (current) { setItems(rows); setStatus('ready') } }).catch(() => { if (current) setStatus('error') })
    return () => { current = false }
  }, [kind])

  if (status === 'loading') return <p className="collection-state" role="status">در حال دریافت محتوای منتشرشده…</p>
  if (status === 'offline') return <EmptyState title="اتصال سرور تنظیم نشده" detail="برای نمایش محتوای واقعی، تنظیمات سرور را بررسی کنید." />
  if (status === 'error') return <EmptyState title="دریافت محتوا ممکن نشد" detail="اتصال را بررسی کنید و کمی بعد دوباره تلاش کنید." />
  if (!items.length) {
    const title = kind === 'products' ? 'فروشگاه هنوز محصولی ندارد' : kind === 'tutorials' ? 'آموزش منتشرشده‌ای نیست' : 'دورهٔ منتشرشده‌ای نیست'
    const detail = kind === 'products' ? 'پس از ثبت و انتشار کالای واقعی، قیمت و موجودی آن اینجا دیده می‌شود.' : 'محتوا پس از ثبت و انتشار از پنل مدیریت نمایش داده می‌شود.'
    return <EmptyState title={title} detail={detail} />
  }
  return <div className="content-grid">{items.map((item) => {
    const to = kind === 'products' ? `/shop/${item.slug}` : kind === 'courses' ? `/courses/${item.slug}` : `/learn/${item.slug}`
    return <Link className="content-card" to={to} key={item.id}>
      <span className="content-card__patch" aria-hidden="true"><PatchworkMark /></span>
      <h2>{item.title}</h2><p>{item.summary}</p>
      <span className="content-card__meta">{kind === 'products' ? (item.price_amount == null ? 'قیمت اعلام نشده' : `${new Intl.NumberFormat('fa-IR').format(item.price_amount)} ${item.currency === 'IRR' ? 'ریال' : item.currency}`) : kind === 'tutorials' ? `${item.duration_minutes ? `${new Intl.NumberFormat('fa-IR').format(item.duration_minutes)} دقیقه` : 'آموزش'} · ${item.level === 'beginner' ? 'مقدماتی' : item.level === 'intermediate' ? 'میانی' : 'پیشرفته'}` : (item.price_amount == null ? 'اطلاعات قیمت تکمیل نشده' : `${new Intl.NumberFormat('fa-IR').format(item.price_amount)} ریال`)}</span>
    </Link>
  })}</div>
}

function ProductDetail() {
  const { slug = '' } = useParams()
  const [item, setItem] = useState<ContentItem | null>(null)
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  const [userId, setUserId] = useState<string | null>(null)
  const [quantity, setQuantity] = useState(1)
  const [cartBusy, setCartBusy] = useState(false)
  const [cartMessage, setCartMessage] = useState('')
  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setUserId(data.session?.user.id ?? null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUserId(session?.user.id ?? null))
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let current = true
    if (!supabase) { setStatus('offline'); return () => { current = false } }
    supabase.from('qnr_products').select('id,slug,name,description,price_amount,currency,inventory_count').eq('slug', slug).eq('is_published', true).maybeSingle().then(({ data, error }) => {
      if (!current) return
      if (error) { setStatus('error'); return }
      if (!data) { setStatus('ready'); return }
      const row = data as { id: string; slug: string; name: string; description: string; price_amount: number | null; currency: string; inventory_count: number }
      setItem({ id: row.id, slug: row.slug, title: row.name, summary: row.description, price_amount: row.price_amount, currency: row.currency, inventory_count: row.inventory_count })
      setStatus('ready')
    })
    return () => { current = false }
  }, [slug])
  async function addToCart() {
    if (!supabase || !item || !userId) return
    setCartBusy(true); setCartMessage('')
    const { error } = await supabase.rpc('qnr_add_to_cart', { p_product_id: item.id, p_quantity: quantity })
    setCartBusy(false)
    if (error) { setCartMessage(error.message.includes('STOCK') || error.message.includes('UNAVAILABLE') ? 'موجودی برای این تعداد کافی نیست.' : 'افزودن به سبد انجام نشد؛ دوباره تلاش کن.'); return }
    setCartMessage('به سبد خرید اضافه شد.')
  }
  if (status === 'loading') return <p className="collection-state" role="status">در حال دریافت اطلاعات کالا…</p>
  if (status === 'offline') return <EmptyState title="اتصال سرور تنظیم نشده" detail="اطلاعات کالا از سرور خوانده می‌شود." />
  if (status === 'error') return <EmptyState title="اطلاعات کالا دریافت نشد" detail="اتصال را بررسی کنید و دوباره تلاش کنید." />
  if (!item) return <EmptyState title="این کالا پیدا نشد" detail="ممکن است کالا از فهرست فروش خارج شده باشد." />
  const available = item.inventory_count ?? 0
  return <><PageIntro path="/shop" /><article className="detail-card"><span className="eyebrow">فروشگاه نقش‌نگار</span><h1>{item.title}</h1><p>{item.summary || 'توضیحی برای این کالا ثبت نشده است.'}</p><div className="detail-card__facts"><span>{item.price_amount == null ? 'قیمت اعلام نشده' : `${new Intl.NumberFormat('fa-IR').format(item.price_amount)} ${item.currency === 'IRR' ? 'ریال' : item.currency}`}</span><span>{item.inventory_count ? `موجودی: ${new Intl.NumberFormat('fa-IR').format(item.inventory_count)}` : 'در حال حاضر ناموجود'}</span></div>
    {available > 0 && item.price_amount != null && userId ? <div className="cart-add-row"><label className="field-label" htmlFor="product-quantity">تعداد</label><input id="product-quantity" type="number" min="1" max={Math.min(99, available)} value={quantity} onChange={(event) => setQuantity(Math.max(1, Math.min(Number(event.target.value) || 1, available, 99)))} /><button className="button button--primary" onClick={addToCart} disabled={cartBusy}>{cartBusy ? 'در حال افزودن…' : 'افزودن به سبد خرید'}</button></div>
      : available > 0 && item.price_amount != null ? <Link className="button button--primary full-button" to="/account">برای افزودن به سبد، وارد حساب شو <ArrowLeft size={16} /></Link>
      : <button className="button button--disabled full-button" disabled>{available <= 0 ? 'در حال حاضر ناموجود' : 'قیمت کالا هنوز مشخص نیست'}</button>}
    {cartMessage && <p className="form-message" role="status">{cartMessage} {cartMessage.includes('اضافه') && <Link to="/cart">دیدن سبد</Link>}</p>}
  </article></>
}

type CartLine = { id: string; product_id: string; quantity: number; product: ContentItem | null }
async function fetchCartLines(): Promise<CartLine[]> {
  if (!supabase) return []
  const { data: cart, error } = await supabase.from('qnr_cart_items').select('id,product_id,quantity').order('updated_at', { ascending: false })
  if (error) throw error
  const rows = (cart ?? []) as Array<{ id: string; product_id: string; quantity: number }>
  if (!rows.length) return []
  const { data: products, error: productsError } = await supabase.from('qnr_products').select('id,slug,name,description,price_amount,currency,inventory_count').in('id', rows.map((row) => row.product_id)).eq('is_published', true)
  if (productsError) throw productsError
  const productsById = new Map(((products ?? []) as Array<{ id: string; slug: string; name: string; description: string; price_amount: number | null; currency: string; inventory_count: number }>).map((row) => [row.id, { id: row.id, slug: row.slug, title: row.name, summary: row.description, price_amount: row.price_amount, currency: row.currency, inventory_count: row.inventory_count }]))
  return rows.map((row) => ({ ...row, product: productsById.get(row.product_id) ?? null }))
}

function CartPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [lines, setLines] = useState<CartLine[]>([])
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  const [notice, setNotice] = useState('')
  useEffect(() => {
    if (!supabase) { setStatus('offline'); return }
    supabase.auth.getSession().then(({ data }) => setUserId(data.session?.user.id ?? null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUserId(session?.user.id ?? null))
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!supabase) { setStatus('offline'); return () => { active = false } }
    if (!userId) { setLines([]); setStatus('ready'); return () => { active = false } }
    setStatus('loading')
    fetchCartLines().then((rows) => { if (active) { setLines(rows); setStatus('ready') } }).catch(() => { if (active) setStatus('error') })
    return () => { active = false }
  }, [userId])
  async function changeQuantity(line: CartLine, quantity: number) {
    if (!supabase) return
    if (quantity < 1) { await removeLine(line); return }
    const { error } = await supabase.from('qnr_cart_items').update({ quantity }).eq('id', line.id)
    if (error) { setNotice('تعداد تغییر نکرد؛ ممکن است موجودی کالا عوض شده باشد.'); return }
    try { setLines(await fetchCartLines()); setNotice('سبد به‌روز شد.') } catch { setNotice('تعداد تغییر کرد، اما سبد تازه نشد.') }
  }
  async function removeLine(line: CartLine) {
    if (!supabase) return
    const { error } = await supabase.from('qnr_cart_items').delete().eq('id', line.id)
    if (error) { setNotice('حذف از سبد انجام نشد.'); return }
    setLines((current) => current.filter((item) => item.id !== line.id)); setNotice('کالا از سبد حذف شد.')
  }
  const subtotal = lines.reduce((sum, line) => sum + (line.product?.price_amount == null ? 0 : Number(line.product.price_amount) * line.quantity), 0)
  return <><PageIntro path="/cart" />
    {!supabaseConfigured || status === 'offline' ? <EmptyState title="اتصال سرور تنظیم نشده" detail="سبد خرید برای هر حساب به‌صورت خصوصی در سرور نگهداری می‌شود." />
      : !userId && status === 'ready' ? <div className="projects-signin"><EmptyState title="سبد خرید به حساب نیاز دارد" detail="برای نگهداری خصوصی سبد، وارد حساب نقش‌نگار شو." /><Link className="button button--primary" to="/account">ورود به حساب <ArrowLeft size={16} /></Link></div>
      : status === 'loading' ? <p className="collection-state" role="status">در حال دریافت سبد…</p>
      : status === 'error' ? <EmptyState title="سبد دریافت نشد" detail="اتصال را بررسی کنید و دوباره تلاش کنید." />
      : !lines.length ? <><EmptyState title="سبد خریدت خالی است" detail="کالاهای منتشرشده را در فروشگاه ببین و به سبد اضافه کن." /><Link className="button button--primary centered-action" to="/shop">رفتن به فروشگاه <ArrowLeft size={16} /></Link></>
      : <div className="cart-layout"><div className="cart-lines">{lines.map((line) => <article className="cart-line" key={line.id}><div className="cart-line__copy"><h2>{line.product?.title ?? 'این کالا دیگر در دسترس نیست'}</h2>{line.product && <p>{line.product.price_amount == null ? 'قیمت اعلام نشده' : `${new Intl.NumberFormat('fa-IR').format(line.product.price_amount)} ${line.product.currency === 'IRR' ? 'ریال' : line.product.currency}`}</p>}{line.product && (line.product.inventory_count ?? 0) < line.quantity && <span className="stock-warning">موجودی فعلی کمتر از تعداد سبد است.</span>}</div>{line.product ? <label className="quantity-control"><span>تعداد</span><input type="number" min="1" max={line.product.inventory_count ?? 1} value={line.quantity} onChange={(event) => changeQuantity(line, Number(event.target.value) || 1)} /></label> : <button className="text-button" onClick={() => removeLine(line)}>حذف کالای ناموجود</button>}<button className="text-button danger-action" onClick={() => removeLine(line)}>حذف</button></article>)}</div>
        <aside className="cart-summary"><h2>خلاصهٔ سبد</h2><div><span>جمع فعلی</span><strong>{new Intl.NumberFormat('fa-IR').format(subtotal)} ریال</strong></div><p>قیمت و موجودی نهایی هنگام ثبت سفارش دوباره از سرور بررسی می‌شود.</p><Link className="button button--secondary" to="/checkout">ادامه به ثبت سفارش <ArrowLeft size={16} /></Link>{notice && <p className="form-message" role="status">{notice}</p>}</aside>
      </div>}
  </>
}

type CheckoutSettings = { card_holder: string; card_number: string; shipping_amount: number; shipping_policy: string; returns_policy: string; contact_phone: string; reservation_minutes: number }
type CreatedOrder = { id: string; order_number: string; status: string; subtotal_amount: number; shipping_amount: number; total_amount: number; reservation_expires_at: string }

function CheckoutPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [settings, setSettings] = useState<CheckoutSettings | null>(null)
  const [lines, setLines] = useState<CartLine[]>([])
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  const [fullName, setFullName] = useState('')
  const [phone, setPhone] = useState('')
  const [province, setProvince] = useState('')
  const [city, setCity] = useState('')
  const [address, setAddress] = useState('')
  const [postalCode, setPostalCode] = useState('')
  const [privacyAccepted, setPrivacyAccepted] = useState(false)
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [order, setOrder] = useState<CreatedOrder | null>(null)
  const [idempotencyKey, setIdempotencyKey] = useState('')
  useEffect(() => {
    if (!supabase) { setStatus('offline'); return }
    supabase.auth.getSession().then(({ data }) => {
      const user = data.session?.user
      setUserId(user?.id ?? null)
      setPhone(user?.phone ?? '')
    })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user.id ?? null)
      setPhone((current) => current || session?.user.phone || '')
    })
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!supabase) { setStatus('offline'); return () => { active = false } }
    if (!userId) { setSettings(null); setLines([]); setStatus('ready'); return () => { active = false } }
    setStatus('loading')
    Promise.all([
      supabase.from('qnr_store_settings').select('card_holder,card_number,shipping_amount,shipping_policy,returns_policy,contact_phone,reservation_minutes').eq('singleton', true).eq('checkout_enabled', true).maybeSingle(),
      fetchCartLines(),
    ]).then(([settingsResult, cartLines]) => {
      if (!active) return
      if (settingsResult.error) { setStatus('error'); return }
      setSettings(settingsResult.data as CheckoutSettings | null); setLines(cartLines); setStatus('ready')
    }).catch(() => { if (active) setStatus('error') })
    return () => { active = false }
  }, [userId])
  async function placeOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    setBusy(true); setNotice('')
    const key = idempotencyKey || crypto.randomUUID()
    if (!idempotencyKey) setIdempotencyKey(key)
    const { data, error } = await supabase.functions.invoke('create-order', {
      body: {
        idempotency_key: key,
        items: lines.filter((line) => line.product).map((line) => ({ product_id: line.product_id, quantity: line.quantity })),
        shipping: { full_name: fullName, phone: normalizeIranPhone(phone), province, city, address, postal_code: postalCode },
        consent: { privacy: privacyAccepted, terms: termsAccepted },
      },
    })
    setBusy(false)
    if (error || !data?.order) { setNotice('ثبت سفارش انجام نشد؛ موجودی، سیاست‌ها و اطلاعات ارسال را بررسی و دوباره تلاش کن.'); return }
    setOrder(data.order as CreatedOrder); setNotice('سفارش ثبت شد. انتقال وجه فقط به شمارهٔ کارت زیر انجام بده.')
  }
  const subtotal = lines.reduce((sum, line) => sum + (line.product?.price_amount == null ? 0 : Number(line.product.price_amount) * line.quantity), 0)
  return <><PageIntro path="/checkout" />
    {!supabaseConfigured || status === 'offline' ? <EmptyState title="اتصال سرور تنظیم نشده" detail="ثبت سفارش نیازمند اتصال امن به سرور است." />
      : status === 'loading' ? <p className="collection-state" role="status">در حال آماده‌سازی ثبت سفارش…</p>
      : status === 'error' ? <EmptyState title="اطلاعات ثبت سفارش دریافت نشد" detail="اتصال را بررسی کنید و دوباره تلاش کنید." />
      : !userId ? <div className="projects-signin"><EmptyState title="برای ثبت سفارش وارد حساب شو" detail="سبد خصوصی و سفارش‌ها به حساب کاربری متصل‌اند." /><Link className="button button--primary" to="/account">ورود به حساب <ArrowLeft size={16} /></Link></div>
      : order && settings ? <div className="order-confirmation"><span className="eyebrow">ثبت سفارش انجام شد</span><h2>شمارهٔ سفارش: {order.order_number}</h2><p>جمع کالاها: {new Intl.NumberFormat('fa-IR').format(order.subtotal_amount)} ریال</p><p>هزینهٔ ارسال: {new Intl.NumberFormat('fa-IR').format(order.shipping_amount)} ریال</p><strong>مبلغ نهایی: {new Intl.NumberFormat('fa-IR').format(order.total_amount)} ریال</strong><div className="payment-destination"><span>واریز به نام</span><strong>{settings.card_holder}</strong><span>شمارهٔ کارت مقصد</span><b dir="ltr">{settings.card_number.replace(/(\d{4})(?=\d)/g, '$1 ')}</b><p>مهلت پرداخت تا {new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(order.reservation_expires_at))}</p></div><p>{settings.shipping_policy}</p><p>پس از واریز، رسید را از صفحهٔ سفارش‌ها بارگذاری کن. تأیید پرداخت پس از بررسی مدیر انجام می‌شود.</p><Link className="button button--primary" to="/orders">رفتن به سفارش‌ها <ArrowLeft size={16} /></Link></div>
      : !settings ? <EmptyState title="ثبت سفارش هنوز فعال نیست" detail="مدیر فروشگاه باید شمارهٔ کارت مقصد، هزینه و قواعد ارسال/مرجوعی را وارد کند و صفحه‌های حریم خصوصی و شرایط را منتشر کند." />
      : !lines.length ? <><EmptyState title="سبد خرید خالی است" detail="برای ثبت سفارش، ابتدا کالا به سبد اضافه کن." /><Link className="button button--primary centered-action" to="/shop">رفتن به فروشگاه <ArrowLeft size={16} /></Link></>
      : <div className="checkout-grid"><form className="checkout-form" onSubmit={placeOrder}><h2>نشانی تحویل</h2><label className="field-label" htmlFor="shipping-name">نام و نام خانوادگی</label><input id="shipping-name" required minLength={3} maxLength={120} value={fullName} onChange={(event) => setFullName(event.target.value)} /><label className="field-label" htmlFor="shipping-phone">شمارهٔ همراه</label><input id="shipping-phone" required inputMode="tel" autoComplete="tel" value={phone} onChange={(event) => setPhone(event.target.value)} /><div className="checkout-fields"><label><span>استان</span><input required value={province} onChange={(event) => setProvince(event.target.value)} /></label><label><span>شهر</span><input required value={city} onChange={(event) => setCity(event.target.value)} /></label></div><label className="field-label" htmlFor="shipping-address">نشانی کامل</label><textarea id="shipping-address" rows={4} required minLength={8} value={address} onChange={(event) => setAddress(event.target.value)} /><label className="field-label" htmlFor="shipping-postal">کد پستی</label><input id="shipping-postal" required minLength={5} maxLength={20} value={postalCode} onChange={(event) => setPostalCode(event.target.value)} /><div className="policy-preview"><h3>ارسال</h3><p>{settings.shipping_policy}</p><h3>مرجوعی</h3><p>{settings.returns_policy}</p></div><label className="consent-row"><input type="checkbox" checked={privacyAccepted} onChange={(event) => setPrivacyAccepted(event.target.checked)} required /><span>سیاست <Link to="/privacy" target="_blank" rel="noreferrer">حریم خصوصی</Link> را خوانده‌ام و می‌پذیرم.</span></label><label className="consent-row"><input type="checkbox" checked={termsAccepted} onChange={(event) => setTermsAccepted(event.target.checked)} required /><span><Link to="/terms" target="_blank" rel="noreferrer">شرایط فروش و مرجوعی</Link> را خوانده‌ام و می‌پذیرم.</span></label><button className="button button--primary" type="submit" disabled={busy}>{busy ? 'در حال بررسی موجودی…' : 'ثبت سفارش و رزرو موقت کالا'}</button>{notice && <p className="form-message" role="status">{notice}</p>}</form><aside className="cart-summary"><h2>خلاصهٔ سفارش</h2><div><span>جمع کالاها</span><strong>{new Intl.NumberFormat('fa-IR').format(subtotal)} ریال</strong></div><div><span>ارسال</span><strong>{new Intl.NumberFormat('fa-IR').format(settings.shipping_amount)} ریال</strong></div><div className="checkout-total"><span>جمع کل</span><strong>{new Intl.NumberFormat('fa-IR').format(subtotal + settings.shipping_amount)} ریال</strong></div><p>قیمت نهایی در لحظهٔ ثبت دوباره از سرور محاسبه می‌شود.</p></aside></div>}
  </>
}

type OrderRecord = {
  id: string; order_number: string; status: string; subtotal_amount: number; shipping_amount: number; total_amount: number;
  shipping_snapshot: { full_name?: string; phone?: string; province?: string; city?: string; address?: string; postal_code?: string };
  reservation_expires_at: string; created_at: string;
}
type PaymentRecord = { id: string; order_id: string; amount: number; receipt_path: string; reference_code: string | null; status: string; review_reason: string | null; created_at: string; receipt_url?: string }
type OrderLineRecord = { id: string; order_id: string; product_name: string; quantity: number; unit_price_amount: number; line_total_amount: number }
type OrderView = OrderRecord & { items: OrderLineRecord[]; payments: PaymentRecord[] }

function orderStatusLabel(status: string) {
  const labels: Record<string, string> = {
    awaiting_payment: 'در انتظار پرداخت', payment_review: 'در انتظار بررسی رسید', paid: 'پرداخت تأیید شد',
    payment_rejected: 'پرداخت تأیید نشد', expired: 'مهلت پرداخت پایان یافت', cancelled: 'لغوشده',
  }
  return labels[status] ?? 'وضعیت نامشخص'
}

function OrderCard({ order, userId, onRefresh }: { order: OrderView; userId: string; onRefresh: () => Promise<void> }) {
  const [receipt, setReceipt] = useState<File | null>(null)
  const [reference, setReference] = useState('')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const payment = [...order.payments].sort((a, b) => b.created_at.localeCompare(a.created_at))[0]
  const canSubmit = order.status === 'awaiting_payment' && (!payment || payment.status === 'expired')
  async function submitReceipt(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !receipt) return
    const allowed = ['image/jpeg', 'image/png', 'image/webp', 'application/pdf']
    if (!allowed.includes(receipt.type) || receipt.size > 10 * 1024 * 1024) {
      setNotice('فقط تصویر JPG، PNG، WebP یا PDF تا سقف ۱۰ مگابایت پذیرفته می‌شود.'); return
    }
    setBusy(true); setNotice('')
    const ext = receipt.type === 'application/pdf' ? 'pdf' : receipt.type.split('/')[1]
    const path = `${userId}/${order.id}/${crypto.randomUUID()}.${ext}`
    const { error: uploadError } = await supabase.storage.from('qnr-payment-receipts').upload(path, receipt, { contentType: receipt.type, upsert: false })
    if (uploadError) { setBusy(false); setNotice('بارگذاری رسید انجام نشد؛ نوع فایل و اتصال را بررسی کن.'); return }
    const { error: insertError } = await supabase.from('qnr_manual_payments').insert({
      order_id: order.id, user_id: userId, amount: order.total_amount, receipt_path: path, reference_code: reference.trim() || null,
    })
    if (insertError) {
      await supabase.storage.from('qnr-payment-receipts').remove([path])
      setBusy(false); setNotice('رسید به سفارش متصل نشد؛ ممکن است مهلت پرداخت تمام شده باشد یا رسید دیگری در انتظار بررسی باشد.'); return
    }
    setReceipt(null); setReference(''); setBusy(false); setNotice('رسید ثبت شد و برای بررسی مدیر فرستاده شد.')
    await onRefresh()
  }
  const expiresAt = new Date(order.reservation_expires_at)
  return <article className="order-card">
    <div className="order-card__heading"><div><span className="eyebrow">سفارش {order.order_number}</span><time dateTime={order.created_at}>{new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium' }).format(new Date(order.created_at))}</time></div><span className={`order-status order-status--${order.status}`}>{orderStatusLabel(order.status)}</span></div>
    <div className="order-items">{order.items.map((item) => <div key={item.id}><span>{item.product_name} × {new Intl.NumberFormat('fa-IR').format(item.quantity)}</span><strong>{new Intl.NumberFormat('fa-IR').format(item.line_total_amount)} ریال</strong></div>)}</div>
    <div className="order-totals"><span>کالاها: {new Intl.NumberFormat('fa-IR').format(order.subtotal_amount)} ریال</span><span>ارسال: {new Intl.NumberFormat('fa-IR').format(order.shipping_amount)} ریال</span><strong>مبلغ سفارش: {new Intl.NumberFormat('fa-IR').format(order.total_amount)} ریال</strong></div>
    {order.status === 'awaiting_payment' && <p className="order-deadline">مهلت پرداخت: {new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(expiresAt)}</p>}
    {payment && <div className="payment-history"><span>وضعیت رسید: {payment.status === 'pending' ? 'در صف بررسی' : payment.status === 'approved' ? 'تأییدشده' : payment.status === 'rejected' ? 'ردشده' : 'منقضی‌شده'}</span>{payment.reference_code && <span>پیگیری بانکی: {payment.reference_code}</span>}{payment.review_reason && <p>{payment.review_reason}</p>}{payment.receipt_url && <a href={payment.receipt_url} target="_blank" rel="noreferrer">مشاهدهٔ رسید بارگذاری‌شده</a>}</div>}
    {canSubmit && <form className="receipt-form" onSubmit={submitReceipt}><h3>{payment?.status === 'expired' ? 'مهلت قبلی پایان یافت' : 'ثبت رسید پرداخت'}</h3><label className="field-label" htmlFor={`receipt-${order.id}`}>تصویر یا فایل PDF رسید (حداکثر ۱۰ مگابایت)</label><input id={`receipt-${order.id}`} type="file" accept="image/jpeg,image/png,image/webp,application/pdf" required onChange={(event) => setReceipt(event.target.files?.[0] ?? null)} /><label className="field-label" htmlFor={`reference-${order.id}`}>شمارهٔ پیگیری بانکی (اختیاری)</label><input id={`reference-${order.id}`} maxLength={120} value={reference} onChange={(event) => setReference(event.target.value)} /><button className="button button--primary" type="submit" disabled={busy || !receipt}>{busy ? 'در حال بارگذاری امن…' : 'ارسال رسید برای بررسی'}</button>{notice && <p className="form-message" role="status">{notice}</p>}</form>}
  </article>
}

function OrdersPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  const [orders, setOrders] = useState<OrderView[]>([])
  const [refreshKey, setRefreshKey] = useState(0)
  useEffect(() => {
    if (!supabase) { setAuthLoading(false); setStatus('offline'); return }
    supabase.auth.getSession().then(({ data }) => { setUserId(data.session?.user.id ?? null); setAuthLoading(false) })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { setUserId(session?.user.id ?? null); setAuthLoading(false) })
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!supabase) { setStatus('offline'); return () => { active = false } }
    if (!userId) { setOrders([]); setStatus('ready'); return () => { active = false } }
    setStatus('loading')
    async function load() {
      const { data: orderRows, error: orderError } = await supabase!.from('qnr_orders').select('id,order_number,status,subtotal_amount,shipping_amount,total_amount,shipping_snapshot,reservation_expires_at,created_at').eq('user_id', userId).order('created_at', { ascending: false })
      if (orderError) throw orderError
      const ids = (orderRows ?? []).map((row) => row.id)
      if (!ids.length) { if (active) { setOrders([]); setStatus('ready') }; return }
      const [itemResult, paymentResult] = await Promise.all([
        supabase!.from('qnr_order_items').select('id,order_id,product_name,quantity,unit_price_amount,line_total_amount').in('order_id', ids),
        supabase!.from('qnr_manual_payments').select('id,order_id,amount,receipt_path,reference_code,status,review_reason,created_at').in('order_id', ids),
      ])
      if (itemResult.error || paymentResult.error) throw itemResult.error ?? paymentResult.error
      const payments = await Promise.all((paymentResult.data ?? []).map(async (payment) => {
        const signed = await supabase!.storage.from('qnr-payment-receipts').createSignedUrl(payment.receipt_path, 300)
        return { ...payment, receipt_url: signed.error ? undefined : signed.data.signedUrl } as PaymentRecord
      }))
      const views = (orderRows ?? []).map((row) => ({
        ...row,
        items: (itemResult.data ?? []).filter((item) => item.order_id === row.id) as OrderLineRecord[],
        payments: payments.filter((payment) => payment.order_id === row.id),
      })) as OrderView[]
      if (active) { setOrders(views); setStatus('ready') }
    }
    load().catch(() => { if (active) setStatus('error') })
    return () => { active = false }
  }, [userId, refreshKey])
  const refresh = async () => setRefreshKey((key) => key + 1)
  return <><PageIntro path="/orders" />
    {!supabaseConfigured || status === 'offline' ? <EmptyState title="اتصال سرور تنظیم نشده" detail="پیگیری سفارش‌ها به حساب امن و اتصال فروشگاه نیاز دارد." />
      : authLoading || status === 'loading' ? <p className="collection-state" role="status">در حال دریافت سفارش‌ها…</p>
      : !userId ? <div className="projects-signin"><EmptyState title="برای دیدن سفارش‌ها وارد حساب شو" detail="فهرست سفارش‌ها و رسیدها فقط برای حساب خودت نمایش داده می‌شوند." /><Link className="button button--primary" to="/account">ورود به حساب <ArrowLeft size={16} /></Link></div>
      : status === 'error' ? <EmptyState title="سفارش‌ها دریافت نشد" detail="اتصال و دسترسی حساب را بررسی کن و دوباره تلاش کن." />
      : orders.length ? <div className="orders-list">{orders.map((order) => <OrderCard key={order.id} order={order} userId={userId} onRefresh={refresh} />)}</div>
      : <EmptyState title="هنوز سفارشی ثبت نشده" detail="پس از ثبت سفارش، وضعیت و رسید پرداخت در همین بخش دیده می‌شود." />}
  </>
}

type ReviewPayment = PaymentRecord & { order_number: string; order_total: number }
function PaymentReviewPanel() {
  const [payments, setPayments] = useState<ReviewPayment[]>([])
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading')
  const [busyId, setBusyId] = useState<string | null>(null)
  const [notice, setNotice] = useState('')
  const [revision, setRevision] = useState(0)
  useEffect(() => {
    let active = true
    if (!supabase) { setState('error'); return () => { active = false } }
    async function load() {
      const { data: paymentRows, error: paymentError } = await supabase!.from('qnr_manual_payments').select('id,order_id,amount,receipt_path,reference_code,status,review_reason,created_at').eq('status', 'pending').order('created_at', { ascending: true })
      if (paymentError) throw paymentError
      const orderIds = [...new Set((paymentRows ?? []).map((payment) => payment.order_id))]
      if (!orderIds.length) { if (active) { setPayments([]); setState('ready') }; return }
      const { data: orderRows, error: orderError } = await supabase!.from('qnr_orders').select('id,order_number,total_amount').in('id', orderIds)
      if (orderError) throw orderError
      const entries = await Promise.all((paymentRows ?? []).map(async (payment) => {
        const order = (orderRows ?? []).find((item) => item.id === payment.order_id)
        const signed = await supabase!.storage.from('qnr-payment-receipts').createSignedUrl(payment.receipt_path, 300)
        return { ...payment, order_number: order?.order_number ?? '—', order_total: Number(order?.total_amount ?? payment.amount), receipt_url: signed.error ? undefined : signed.data.signedUrl } as ReviewPayment
      }))
      if (active) { setPayments(entries); setState('ready') }
    }
    load().catch(() => { if (active) setState('error') })
    return () => { active = false }
  }, [revision])
  async function review(payment: ReviewPayment, decision: 'approved' | 'rejected') {
    if (!supabase) return
    const reason = decision === 'rejected' ? window.prompt('علت رد رسید را کوتاه و روشن بنویس:')?.trim() : ''
    if (decision === 'rejected' && (!reason || reason.length < 4)) return
    setBusyId(payment.id); setNotice('')
    const { data, error } = await supabase.functions.invoke('review-payment', { body: { payment_id: payment.id, decision, reason } })
    setBusyId(null)
    if (error || data?.status !== decision) { setNotice(error?.message || 'وضعیت رسید تغییر نکرد؛ دوباره فهرست را تازه کن.'); return }
    setNotice(decision === 'approved' ? 'پرداخت تأیید و سفارش به‌روز شد.' : 'رسید رد شد و موجودی سفارش آزاد شد.')
    setRevision((value) => value + 1)
  }
  return <section className="payment-review"><div className="audit-panel__heading"><h2>بررسی رسیدهای پرداخت</h2><button className="text-button" type="button" onClick={() => setRevision((value) => value + 1)}>تازه‌سازی</button></div>
    {state === 'loading' ? <p className="collection-state">در حال دریافت رسیدها…</p> : state === 'error' ? <p className="audit-empty">فهرست رسیدها دریافت نشد؛ اتصال و نقش مدیر را بررسی کن.</p> : payments.length ? <div className="review-list">{payments.map((payment) => <article className="review-card" key={payment.id}><div><span className="eyebrow">سفارش {payment.order_number}</span><strong>{new Intl.NumberFormat('fa-IR').format(payment.amount)} ریال</strong>{payment.reference_code && <small>پیگیری بانکی: {payment.reference_code}</small>}{payment.receipt_url ? <a href={payment.receipt_url} target="_blank" rel="noreferrer">بازکردن رسید خصوصی</a> : <small>رسید در دسترس نیست؛ لینک تازه بگیر.</small>}</div><div className="admin-record__actions"><button disabled={busyId === payment.id} onClick={() => review(payment, 'approved')}>{busyId === payment.id ? 'در حال ثبت…' : 'تأیید پرداخت'}</button><button className="danger-action" disabled={busyId === payment.id} onClick={() => review(payment, 'rejected')}>رد رسید</button></div></article>)}</div> : <p className="audit-empty">رسید معوقی برای بررسی نیست.</p>}
    {notice && <p className="form-message" role="status">{notice}</p>}
  </section>
}

type SupportTicket = { id: string; ticket_number: string; user_id: string; subject: string; status: 'waiting_staff' | 'waiting_user' | 'closed'; priority: 'normal' | 'high'; created_at: string; last_message_at: string }
type SupportMessage = { id: string; ticket_id: string; sender_id: string | null; sender_role: 'customer' | 'staff'; body: string; created_at: string }

function supportStatusLabel(status: SupportTicket['status']) {
  return status === 'waiting_staff' ? 'در انتظار پشتیبانی' : status === 'waiting_user' ? 'در انتظار پاسخ تو' : 'بسته‌شده'
}

function SupportConversation({ ticket, isStaff, onSent }: { ticket: SupportTicket; isStaff: boolean; onSent: () => void }) {
  const [messages, setMessages] = useState<SupportMessage[]>([])
  const [message, setMessage] = useState('')
  const [loading, setLoading] = useState(true)
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [revision, setRevision] = useState(0)
  useEffect(() => {
    let active = true
    if (!supabase) { setLoading(false); return () => { active = false } }
    setLoading(true)
    supabase.from('qnr_support_messages').select('id,ticket_id,sender_id,sender_role,body,created_at').eq('ticket_id', ticket.id).order('created_at').then(({ data, error }) => {
      if (!active) return
      if (error) { setNotice('پیام‌های این درخواست دریافت نشدند.'); setMessages([]) }
      else { setMessages((data ?? []) as SupportMessage[]); setNotice('') }
      setLoading(false)
    })
    return () => { active = false }
  }, [ticket.id, revision])
  async function sendMessage(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !message.trim()) return
    setBusy(true); setNotice('')
    const { error } = await supabase.rpc('qnr_reply_support_ticket', { p_ticket_id: ticket.id, p_body: message.trim() })
    setBusy(false)
    if (error) { setNotice('پیام ذخیره نشد؛ اتصال را بررسی کن و دوباره تلاش کن.'); return }
    setMessage(''); setRevision((value) => value + 1); onSent()
  }
  return <section className="support-thread" aria-label={`گفت‌وگوی ${ticket.ticket_number}`}>
    <div className="support-thread__heading"><div><span className="eyebrow">{ticket.ticket_number}</span><h3>{ticket.subject}</h3></div><span className="order-status">{supportStatusLabel(ticket.status)}</span></div>
    <div className="support-messages" aria-live="polite">
      {loading ? <p className="collection-state">در حال دریافت پیام‌ها…</p> : messages.length ? messages.map((entry) => <article className={`support-message ${entry.sender_role === 'staff' ? 'support-message--staff' : ''}`} key={entry.id}><span>{entry.sender_role === 'staff' ? 'پشتیبانی نقش‌نگار' : 'تو'}</span><p>{entry.body}</p><time dateTime={entry.created_at}>{new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(entry.created_at))}</time></article>) : <p className="audit-empty">پیامی برای نمایش نیست.</p>}
    </div>
    {ticket.status === 'closed' && !isStaff ? <p className="connection-notice">این درخواست بسته شده است. اگر موضوع ادامه دارد، درخواست تازه‌ای ثبت کن.</p> : <form className="support-reply" onSubmit={sendMessage}><label className="field-label" htmlFor={`reply-${ticket.id}`}>{isStaff ? 'پاسخ پشتیبانی' : 'پیام تازه'}</label><textarea id={`reply-${ticket.id}`} rows={3} maxLength={5000} value={message} onChange={(event) => setMessage(event.target.value)} required placeholder="پیامت را روشن و محترمانه بنویس…" /><button className="button button--primary" type="submit" disabled={busy || !message.trim()}>{busy ? 'در حال ثبت…' : 'ارسال پیام'}</button>{notice && <p className="form-message" role="status">{notice}</p>}</form>}
  </section>
}

function SupportPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [subject, setSubject] = useState('')
  const [initialMessage, setInitialMessage] = useState('')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [state, setState] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  const [revision, setRevision] = useState(0)
  useEffect(() => {
    if (!supabase) { setState('offline'); setAuthLoading(false); return }
    supabase.auth.getSession().then(({ data }) => { setUserId(data.session?.user.id ?? null); setAuthLoading(false) })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { setUserId(session?.user.id ?? null); setAuthLoading(false) })
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!supabase) { setState('offline'); return () => { active = false } }
    if (!userId) { setTickets([]); setState('ready'); return () => { active = false } }
    setState('loading')
    supabase.from('qnr_support_tickets').select('id,ticket_number,user_id,subject,status,priority,created_at,last_message_at').eq('user_id', userId).order('last_message_at', { ascending: false }).then(({ data, error }) => {
      if (!active) return
      if (error) { setState('error'); return }
      const rows = (data ?? []) as SupportTicket[]
      setTickets(rows); setSelectedId((current) => current && rows.some((ticket) => ticket.id === current) ? current : rows[0]?.id ?? null); setState('ready')
    })
    return () => { active = false }
  }, [userId, revision])
  async function openTicket(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    setBusy(true); setNotice('')
    const { data, error } = await supabase.rpc('qnr_open_support_ticket', { p_subject: subject.trim(), p_body: initialMessage.trim() })
    setBusy(false)
    if (error) { setNotice(error.code === '42900' ? 'در هر ساعت می‌توان حداکثر پنج درخواست تازه ثبت کرد.' : 'درخواست ثبت نشد؛ اتصال و متن پیام را بررسی کن.'); return }
    setSubject(''); setInitialMessage(''); setSelectedId(data?.id ?? null); setNotice('درخواست پشتیبانی ثبت شد. شمارهٔ پیگیری در فهرست دیده می‌شود.'); setRevision((value) => value + 1)
  }
  return <><PageIntro path="/support" />
    {state === 'offline' ? <EmptyState title="اتصال سرور تنظیم نشده" detail="صندوق پشتیبانی برای ثبت امن پیام‌ها به سرور نیاز دارد." />
      : authLoading ? <p className="collection-state" role="status">در حال بررسی حساب…</p>
      : !userId ? <div className="projects-signin"><EmptyState title="پشتیبانی امن نقش‌نگار" detail="برای ثبت و پیگیری پیام، وارد حساب شو تا پاسخ‌ها فقط برای خودت نمایش داده شوند." /><Link className="button button--primary" to="/account">ورود به حساب <ArrowLeft size={16} /></Link></div>
      : state === 'loading' ? <p className="collection-state" role="status">در حال دریافت درخواست‌ها…</p>
      : state === 'error' ? <EmptyState title="صندوق پشتیبانی دریافت نشد" detail="اتصال را بررسی کن و دوباره تلاش کن." />
      : <div className="support-layout"><section className="support-compose"><h2>درخواست تازه</h2><p>پیام‌ها فقط برای تو و تیم مجاز پشتیبانی قابل مشاهده‌اند.</p><form className="support-reply" onSubmit={openTicket}><label className="field-label" htmlFor="support-subject">موضوع</label><input id="support-subject" minLength={5} maxLength={120} required value={subject} onChange={(event) => setSubject(event.target.value)} /><label className="field-label" htmlFor="support-message">شرح درخواست</label><textarea id="support-message" rows={5} maxLength={5000} required value={initialMessage} onChange={(event) => setInitialMessage(event.target.value)} /><button className="button button--primary" type="submit" disabled={busy}>{busy ? 'در حال ثبت امن…' : 'ثبت درخواست'}</button>{notice && <p className="form-message" role="status">{notice}</p>}</form></section><section className="support-ticket-list"><div className="audit-panel__heading"><h2>درخواست‌های من</h2><button className="text-button" type="button" onClick={() => setRevision((value) => value + 1)}>تازه‌سازی</button></div>{tickets.length ? tickets.map((ticket) => <button className={`support-ticket-row ${selectedId === ticket.id ? 'is-selected' : ''}`} type="button" key={ticket.id} onClick={() => setSelectedId(ticket.id)}><span><strong>{ticket.subject}</strong><small>{ticket.ticket_number}</small></span><span className="order-status">{supportStatusLabel(ticket.status)}</span></button>) : <p className="audit-empty">هنوز درخواستی ثبت نکرده‌ای.</p>}</section>{selectedId && tickets.find((ticket) => ticket.id === selectedId) && <SupportConversation ticket={tickets.find((ticket) => ticket.id === selectedId)!} isStaff={false} onSent={() => setRevision((value) => value + 1)} />}</div>}
  </>
}

function SupportInboxPanel() {
  const [tickets, setTickets] = useState<SupportTicket[]>([])
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading')
  const [notice, setNotice] = useState('')
  const [revision, setRevision] = useState(0)
  const [query, setQuery] = useState('')
  const [statusFilter, setStatusFilter] = useState<'all' | SupportTicket['status']>('all')
  useEffect(() => {
    let active = true
    if (!supabase) { setState('error'); return () => { active = false } }
    supabase.from('qnr_support_tickets').select('id,ticket_number,user_id,subject,status,priority,created_at,last_message_at').order('last_message_at', { ascending: false }).limit(100).then(({ data, error }) => {
      if (!active) return
      if (error) { setState('error'); return }
      const rows = (data ?? []) as SupportTicket[]
      setTickets(rows); setSelectedId((current) => current && rows.some((ticket) => ticket.id === current) ? current : rows[0]?.id ?? null); setState('ready')
    })
    return () => { active = false }
  }, [revision])
  async function setTicket(ticket: SupportTicket, values: { status?: SupportTicket['status']; priority?: SupportTicket['priority'] }) {
    if (!supabase) return
    setNotice('')
    const { error } = await supabase.rpc('qnr_update_support_ticket', { p_ticket_id: ticket.id, p_status: values.status ?? ticket.status, p_priority: values.priority ?? ticket.priority })
    if (error) { setNotice('تغییر درخواست ذخیره نشد.'); return }
    setNotice('درخواست به‌روز شد.'); setRevision((value) => value + 1)
  }
  const visible = tickets.filter((ticket) => `${ticket.ticket_number} ${ticket.subject}`.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()) && (statusFilter === 'all' || ticket.status === statusFilter))
  const selected = tickets.find((ticket) => ticket.id === selectedId)
  return <section className="support-inbox"><div className="audit-panel__heading"><h2>صندوق پشتیبانی</h2><button className="text-button" type="button" onClick={() => setRevision((value) => value + 1)}>تازه‌سازی</button></div>
    {state === 'loading' ? <p className="collection-state">در حال دریافت درخواست‌ها…</p> : state === 'error' ? <p className="audit-empty">صندوق در دسترس نیست؛ نقش مدیر را بررسی کن.</p> : <><div className="support-inbox__search"><input aria-label="جست‌وجوی درخواست‌ها" placeholder="جست‌وجو با موضوع یا شمارهٔ پیگیری" value={query} onChange={(event) => setQuery(event.target.value)} /><select aria-label="فیلتر وضعیت" value={statusFilter} onChange={(event) => setStatusFilter(event.target.value as typeof statusFilter)}><option value="all">همهٔ وضعیت‌ها</option><option value="waiting_staff">در انتظار پشتیبانی</option><option value="waiting_user">در انتظار کاربر</option><option value="closed">بسته‌شده</option></select></div><div className="support-inbox__columns"><div className="support-inbox__list">{visible.map((ticket) => <button type="button" className={`support-ticket-row ${selectedId === ticket.id ? 'is-selected' : ''}`} key={ticket.id} onClick={() => setSelectedId(ticket.id)}><span><strong>{ticket.subject}</strong><small>{ticket.ticket_number} · {supportStatusLabel(ticket.status)}</small></span><span className={`order-status ${ticket.priority === 'high' ? 'order-status--payment_rejected' : ''}`}>{ticket.priority === 'high' ? 'مهم' : 'عادی'}</span></button>)}{visible.length === 0 && <p className="audit-empty">درخواستی مطابق جست‌وجو پیدا نشد.</p>}</div>{selected && <div className="support-inbox__detail"><div className="support-inbox__actions"><label>اولویت<select value={selected.priority} onChange={(event) => setTicket(selected, { priority: event.target.value as SupportTicket['priority'] })}><option value="normal">عادی</option><option value="high">مهم</option></select></label><button className="text-button" type="button" onClick={() => setTicket(selected, { status: selected.status === 'closed' ? 'waiting_staff' : 'closed' })}>{selected.status === 'closed' ? 'بازگشایی درخواست' : 'بستن درخواست'}</button></div><SupportConversation ticket={selected} isStaff onSent={() => setRevision((value) => value + 1)} /></div>}</div>{notice && <p className="form-message" role="status">{notice}</p>}</>}
  </section>
}

function NotificationsPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [loading, setLoading] = useState(true)
  const [notifications, setNotifications] = useState<Array<{ id: string; notification_type: string; title: string; body: string; target_path: string | null; read_at: string | null; created_at: string }>>([])
  const [error, setError] = useState(false)
  const [revision, setRevision] = useState(0)
  useEffect(() => {
    if (!supabase) { setLoading(false); return }
    supabase.auth.getSession().then(({ data }) => { setUserId(data.session?.user.id ?? null); setLoading(false) })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUserId(session?.user.id ?? null))
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!supabase || !userId) { setNotifications([]); return () => { active = false } }
    setLoading(true)
    supabase.from('qnr_notifications').select('id,notification_type,title,body,target_path,read_at,created_at').eq('recipient_id', userId).order('created_at', { ascending: false }).limit(100).then(({ data, error: queryError }) => {
      if (!active) return
      setError(Boolean(queryError)); setNotifications((data ?? []) as typeof notifications); setLoading(false)
    })
    return () => { active = false }
  }, [userId, revision])
  async function markRead(id: string) {
    if (!supabase) return
    const { error: updateError } = await supabase.from('qnr_notifications').update({ read_at: new Date().toISOString() }).eq('id', id).is('read_at', null)
    if (!updateError) setRevision((value) => value + 1)
  }
  return <><PageIntro path="/notifications" />
    {!supabaseConfigured ? <EmptyState title="اتصال سرور تنظیم نشده" detail="اعلان‌ها از حساب کاربری دریافت می‌شوند." />
      : loading ? <p className="collection-state" role="status">در حال دریافت اعلان‌ها…</p>
      : !userId ? <div className="projects-signin"><EmptyState title="اعلان‌های حساب تو" detail="برای دیدن پاسخ‌ها و پیگیری‌ها وارد حساب شو." /><Link className="button button--primary" to="/account">ورود به حساب <ArrowLeft size={16} /></Link></div>
      : error ? <EmptyState title="اعلان‌ها دریافت نشدند" detail="اتصال و دسترسی حساب را بررسی کن." />
      : notifications.length ? <div className="notification-list">{notifications.map((item) => <Link className={`notification-row ${item.read_at ? '' : 'is-unread'}`} key={item.id} to={item.target_path || '/notifications'} onClick={() => { if (!item.read_at) void markRead(item.id) }}><span className="notification-dot" aria-hidden="true" /><span><strong>{item.title}</strong><small>{item.body}</small><time dateTime={item.created_at}>{new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(item.created_at))}</time></span></Link>)}</div>
      : <EmptyState title="اعلان تازه‌ای نیست" detail="پاسخ پشتیبانی و به‌روزرسانی سفارش‌ها اینجا نشان داده می‌شوند." />}
  </>
}

type LessonBlock = { text?: string; type?: string; heading?: string }
function ContentBody({ blocks }: { blocks: unknown }) {
  if (typeof blocks === 'string') return <div className="article-body"><p>{blocks}</p></div>
  if (!Array.isArray(blocks)) return null
  return <div className="article-body">{(blocks as LessonBlock[]).map((block, index) => block.heading
    ? <section key={index}><h2>{block.heading}</h2>{block.text && <p>{block.text}</p>}</section>
    : block.text ? <p key={index}>{block.text}</p> : null)}</div>
}

function DynamicPage({ path }: { path: '/about' | '/privacy' | '/terms' }) {
  const [page, setPage] = useState<{ title: string; body: unknown } | null>(null)
  const [status, setStatus] = useState<'loading' | 'ready' | 'error'>('loading')
  useEffect(() => {
    let active = true
    const slug = path.slice(1)
    if (!supabase) { setStatus('ready'); return () => { active = false } }
    supabase.from('qnr_site_pages').select('title,body').eq('slug', slug).eq('is_published', true).maybeSingle().then(({ data, error }) => {
      if (!active) return
      if (error) { setStatus('error'); return }
      setPage(data as { title: string; body: unknown } | null); setStatus('ready')
    })
    return () => { active = false }
  }, [path])
  if (status === 'loading') return <p className="collection-state" role="status">در حال دریافت صفحه…</p>
  if (status === 'error') return <EmptyState title="صفحه دریافت نشد" detail="اتصال را بررسی کنید و دوباره تلاش کنید." />
  if (!page) return <ListingPage path={path} />
  return <><PageIntro path={path} /><article className="detail-card"><ContentBody blocks={page.body} /></article></>
}

function TutorialDetail() {
  const { slug = '' } = useParams()
  const [item, setItem] = useState<{ title: string; summary: string; body: unknown } | null>(null)
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  useEffect(() => {
    let current = true
    if (!supabase) { setStatus('offline'); return () => { current = false } }
    supabase.from('qnr_tutorials').select('title,summary,body').eq('slug', slug).eq('is_published', true).maybeSingle().then(({ data, error }) => {
      if (!current) return
      if (error) { setStatus('error'); return }
      setItem(data as { title: string; summary: string; body: unknown } | null)
      setStatus('ready')
    })
    return () => { current = false }
  }, [slug])
  if (status === 'loading') return <p className="collection-state" role="status">در حال دریافت آموزش…</p>
  if (status === 'offline') return <EmptyState title="اتصال سرور تنظیم نشده" detail="آموزش‌ها از سرور خوانده می‌شوند." />
  if (status === 'error') return <EmptyState title="آموزش دریافت نشد" detail="اتصال را بررسی کنید و دوباره تلاش کنید." />
  if (!item) return <EmptyState title="این آموزش منتشر نشده است" detail="ممکن است نشانی اشتباه باشد یا آموزش از انتشار خارج شده باشد." />
  return <><PageIntro path="/learn" /><article className="detail-card"><span className="eyebrow">آموزش نقش‌نگار</span><h1>{item.title}</h1><p>{item.summary}</p><ContentBody blocks={item.body} /></article></>
}

type CourseLessonProgress = { lesson_id: string; bookmarked: boolean; note: string; last_position_seconds: number; completed_at: string | null }
type CourseLesson = { id: string; slug: string; title: string; summary: string; body: unknown }
const blankLessonProgress = (lesson_id: string): CourseLessonProgress => ({ lesson_id, bookmarked: false, note: '', last_position_seconds: 0, completed_at: null })

function LessonProgressPanel({ progress, signedIn, loading, loadError, onRetry, onSave }: { progress: CourseLessonProgress; signedIn: boolean; loading: boolean; loadError: boolean; onRetry: () => void; onSave: (next: CourseLessonProgress) => Promise<boolean> }) {
  const [note, setNote] = useState(progress.note)
  const [position, setPosition] = useState(String(progress.last_position_seconds))
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  useEffect(() => { setNote(progress.note); setPosition(String(progress.last_position_seconds)) }, [progress.note, progress.last_position_seconds])

  async function save(patch: Partial<CourseLessonProgress> = {}) {
    if (!signedIn || busy) return
    const seconds = Math.max(0, Math.min(7200, Math.floor(Number(position) || 0)))
    const next = { ...progress, note: note.slice(0, 2000), last_position_seconds: seconds, ...patch }
    setBusy(true); setNotice('')
    try {
      const saved = await onSave(next)
      setNotice(saved ? 'پیشرفت ذخیره شد.' : 'ذخیره انجام نشد؛ دوباره تلاش کن.')
    } catch {
      setNotice('ذخیره انجام نشد؛ اتصال را بررسی کن و دوباره تلاش کن.')
    } finally { setBusy(false) }
  }

  if (!signedIn) return <div className="lesson-progress__signin"><Link to="/account">برای ذخیرهٔ نشانک و یادداشت وارد حساب شو <ArrowLeft size={14} /></Link></div>
  if (loading) return <div className="lesson-progress__signin" role="status">در حال دریافت پیشرفت این درس…</div>
  if (loadError) return <div className="lesson-progress__signin" role="alert">پیشرفت این درس دریافت نشد. <button className="text-button" type="button" onClick={onRetry}>تلاش دوباره</button></div>
  return <div className="lesson-progress">
    <div className="lesson-progress__actions">
      <button type="button" className={`lesson-progress__button ${progress.bookmarked ? 'is-active' : ''}`} onClick={() => save({ bookmarked: !progress.bookmarked })} disabled={busy}><Bookmark size={15} />{progress.bookmarked ? 'نشانک‌دار' : 'افزودن نشانک'}</button>
      <button type="button" className={`lesson-progress__button ${progress.completed_at ? 'is-active' : ''}`} onClick={() => save({ completed_at: progress.completed_at ? null : new Date().toISOString() })} disabled={busy}><Check size={15} />{progress.completed_at ? 'انجام‌شده' : 'علامت‌گذاری به‌عنوان انجام‌شده'}</button>
    </div>
    <div className="lesson-progress__fields"><label>زمان پخش (ثانیه)<input type="number" min="0" max="7200" value={position} onChange={(event) => setPosition(event.target.value)} /></label><label>یادداشت شخصی<textarea rows={2} maxLength={2000} value={note} onChange={(event) => setNote(event.target.value)} placeholder="نکته‌ای که می‌خواهی برای این درس نگه داری…" /></label></div>
    <div className="lesson-progress__footer"><button className="text-button" type="button" onClick={() => save()} disabled={busy}>{busy ? 'در حال ذخیره…' : 'ذخیرهٔ یادداشت و زمان'}</button>{notice && <span role="status">{notice}</span>}</div>
  </div>
}

function CourseDetail() {
  const { slug = '' } = useParams()
  const [course, setCourse] = useState<{ id: string; title: string; summary: string; price_amount: number | null; currency: string } | null>(null)
  const [lessons, setLessons] = useState<CourseLesson[]>([])
  const [progressRows, setProgressRows] = useState<Record<string, CourseLessonProgress>>({})
  const [userId, setUserId] = useState<string | null>(null)
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  const [entitlementState, setEntitlementState] = useState<'loading' | 'ready' | 'error'>('loading')
  const [hasActiveEntitlement, setHasActiveEntitlement] = useState(false)
  const [entitlementReload, setEntitlementReload] = useState(0)
  const [progressLoading, setProgressLoading] = useState(false)
  const [progressLoadError, setProgressLoadError] = useState(false)
  const [progressReload, setProgressReload] = useState(0)
  const [privacyAccepted, setPrivacyAccepted] = useState(false)
  const [termsAccepted, setTermsAccepted] = useState(false)
  const [purchaseBusy, setPurchaseBusy] = useState(false)
  const [purchaseNotice, setPurchaseNotice] = useState('')
  const [courseOrderKey, setCourseOrderKey] = useState('')
  const [courseOrder, setCourseOrder] = useState<CreatedOrder | null>(null)
  const [paymentSettings, setPaymentSettings] = useState<Pick<CheckoutSettings, 'card_holder' | 'card_number'> | null>(null)
  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setUserId(data.session?.user.id ?? null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setLessons([])
      setProgressRows({})
      setHasActiveEntitlement(false)
      setEntitlementState('loading')
      setCourseOrder(null)
      setPaymentSettings(null)
      setCourseOrderKey('')
      setPurchaseNotice('')
      setPrivacyAccepted(false)
      setTermsAccepted(false)
      setUserId(session?.user.id ?? null)
    })
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let current = true
    if (!supabase) { setStatus('offline'); return () => { current = false } }
    setStatus('loading')
    setCourse(null)
    setLessons([])
    setHasActiveEntitlement(false)
    setEntitlementState('loading')
    setCourseOrder(null)
    setPaymentSettings(null)
    setCourseOrderKey('')
    setPurchaseNotice('')
    setPrivacyAccepted(false)
    setTermsAccepted(false)
    async function load() {
      const courseResponse = await supabase!.from('qnr_courses').select('id,title,summary,price_amount,currency').eq('slug', slug).eq('is_published', true).maybeSingle()
      if (!current) return
      if (courseResponse.error) { setStatus('error'); return }
      if (!courseResponse.data) { setCourse(null); setLessons([]); setStatus('ready'); return }
      const row = courseResponse.data as { id: string; title: string; summary: string; price_amount: number | null; currency: string }
      setCourse(row)
      const lessonResponse = await supabase!.from('qnr_course_lessons').select('id,slug,title,summary,body').eq('course_id', row.id).eq('is_published', true).order('sort_order')
      if (!current) return
      if (lessonResponse.error) { setStatus('error'); return }
      setLessons((lessonResponse.data ?? []) as CourseLesson[])
      setStatus('ready')
    }
    load().catch(() => { if (current) setStatus('error') })
    return () => { current = false }
  }, [slug, userId, entitlementReload])
  useEffect(() => {
    let current = true
    if (!course || !supabase) return () => { current = false }
    if (!userId) {
      setHasActiveEntitlement(false)
      setEntitlementState('ready')
      return () => { current = false }
    }
    setEntitlementState('loading')
    Promise.resolve(supabase.from('qnr_course_entitlements').select('expires_at').eq('user_id', userId).eq('course_id', course.id).maybeSingle()).then(({ data, error }) => {
      if (!current) return
      if (error) { setEntitlementState('error'); return }
      setHasActiveEntitlement(Boolean(data && (!data.expires_at || new Date(data.expires_at).getTime() > Date.now())))
      setEntitlementState('ready')
    }).catch(() => { if (current) setEntitlementState('error') })
    return () => { current = false }
  }, [userId, course?.id, entitlementReload])
  useEffect(() => {
    let current = true
    if (!supabase || !userId || !lessons.length) { setProgressRows({}); setProgressLoading(false); setProgressLoadError(false); return () => { current = false } }
    setProgressLoading(true)
    supabase.from('qnr_course_lesson_progress').select('lesson_id,bookmarked,note,last_position_seconds,completed_at').eq('user_id', userId).in('lesson_id', lessons.map((lesson) => lesson.id)).then(({ data, error }) => {
      if (!current) return
      if (error) setProgressLoadError(true)
      else { setProgressRows(Object.fromEntries(((data ?? []) as CourseLessonProgress[]).map((row) => [row.lesson_id, row]))); setProgressLoadError(false) }
      setProgressLoading(false)
    })
    return () => { current = false }
  }, [userId, lessons, progressReload])

  async function saveLessonProgress(next: CourseLessonProgress) {
    if (!supabase || !userId) return false
    const row = { ...next, note: next.note.slice(0, 2000), last_position_seconds: Math.max(0, Math.min(7200, Math.floor(next.last_position_seconds || 0))) }
    let data: CourseLessonProgress | null = null
    let error: { message: string } | null = null
    if (progressRows[row.lesson_id]) {
      const response = await supabase.from('qnr_course_lesson_progress').update({ bookmarked: row.bookmarked, note: row.note, last_position_seconds: row.last_position_seconds, completed_at: row.completed_at }).eq('user_id', userId).eq('lesson_id', row.lesson_id).select('lesson_id,bookmarked,note,last_position_seconds,completed_at').maybeSingle()
      data = response.data as CourseLessonProgress | null; error = response.error
    } else {
      const response = await supabase.from('qnr_course_lesson_progress').insert({ user_id: userId, ...row }).select('lesson_id,bookmarked,note,last_position_seconds,completed_at').single()
      data = response.data as CourseLessonProgress | null; error = response.error
      if (error) {
        const existing = await supabase.from('qnr_course_lesson_progress').select('lesson_id').eq('user_id', userId).eq('lesson_id', row.lesson_id).maybeSingle()
        if (!existing.error && existing.data) {
          const retry = await supabase.from('qnr_course_lesson_progress').update({ bookmarked: row.bookmarked, note: row.note, last_position_seconds: row.last_position_seconds, completed_at: row.completed_at }).eq('user_id', userId).eq('lesson_id', row.lesson_id).select('lesson_id,bookmarked,note,last_position_seconds,completed_at').maybeSingle()
          data = retry.data as CourseLessonProgress | null; error = retry.error
        }
      }
    }
    if (error || !data) return false
    setProgressRows((previous) => ({ ...previous, [row.lesson_id]: data! }))
    return true
  }

  async function createCourseOrder(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !userId || !course || !privacyAccepted || !termsAccepted) return
    setPurchaseBusy(true)
    setPurchaseNotice('')
    const key = courseOrderKey || crypto.randomUUID()
    if (!courseOrderKey) setCourseOrderKey(key)
    try {
      const { data, error } = await supabase.functions.invoke('create-order', {
        body: {
          idempotency_key: key,
          items: [{ course_id: course.id, quantity: 1 }],
          shipping: {},
          consent: { privacy: privacyAccepted, terms: termsAccepted },
        },
      })
      if (error || !data?.order) {
        let message = 'سفارش دوره ثبت نشد؛ اتصال، شرایط فروش و تنظیمات فروشگاه را بررسی کن.'
        const context = (error as { context?: unknown } | null)?.context
        if (context instanceof Response) {
          try {
            const body = await context.clone().json() as { error?: unknown }
            if (typeof body.error === 'string') message = body.error
          } catch { /* Use the clear local fallback when the server response is not JSON. */ }
        }
        setPurchaseNotice(message)
        return
      }
      const created = data.order as CreatedOrder
      setCourseOrder(created)
      setPurchaseNotice('سفارش دوره ثبت شد؛ دسترسی درس‌ها بعد از تأیید رسید توسط مدیر فعال می‌شود.')
      try {
        const settings = await supabase.from('qnr_store_settings').select('card_holder,card_number').eq('singleton', true).eq('checkout_enabled', true).maybeSingle()
        setPaymentSettings(settings.error ? null : settings.data as Pick<CheckoutSettings, 'card_holder' | 'card_number'> | null)
      } catch {
        setPaymentSettings(null)
      }
    } catch {
      setPurchaseNotice('ثبت سفارش به‌دلیل اختلال ارتباط انجام نشد؛ وضعیت سفارش‌ها را پیش از تلاش دوباره بررسی کن.')
    } finally {
      setPurchaseBusy(false)
    }
  }

  if (status === 'loading') return <p className="collection-state" role="status">در حال دریافت دوره…</p>
  if (status === 'offline') return <EmptyState title="اتصال سرور تنظیم نشده" detail="اطلاعات دوره از سرور خوانده می‌شود." />
  if (status === 'error') return <EmptyState title="دوره دریافت نشد" detail="ممکن است دسترسی یا اتصال سرور آماده نباشد." />
  if (!course) return <EmptyState title="این دوره منتشر نشده است" detail="ممکن است نشانی اشتباه باشد یا دوره از انتشار خارج شده باشد." />
  const completedCount = lessons.filter((lesson) => Boolean(progressRows[lesson.id]?.completed_at)).length
  const coursePrice = course.price_amount == null ? 'قیمت اعلام نشده' : `${new Intl.NumberFormat('fa-IR').format(course.price_amount)} ${course.currency === 'IRR' ? 'ریال' : course.currency}`
  return <><PageIntro path="/courses" /><article className="detail-card"><span className="eyebrow">دورهٔ نقش‌نگار</span><h1>{course.title}</h1><p>{course.summary}</p><div className="course-overview"><span>{coursePrice}</span>{lessons.length > 0 && userId && <span>پیشرفت: {new Intl.NumberFormat('fa-IR').format(completedCount)} از {new Intl.NumberFormat('fa-IR').format(lessons.length)} درس</span>}</div>
    {courseOrder ? <div className="order-confirmation course-order-confirmation"><span className="eyebrow">سفارش دوره ثبت شد</span><h2>شمارهٔ سفارش: {courseOrder.order_number}</h2><p>مبلغ قابل پرداخت: {new Intl.NumberFormat('fa-IR').format(courseOrder.total_amount)} ریال</p>
      {paymentSettings ? <div className="payment-destination"><span>واریز به نام</span><strong>{paymentSettings.card_holder}</strong><span>شمارهٔ کارت مقصد</span><b dir="ltr">{paymentSettings.card_number.replace(/(\d{4})(?=\d)/g, '$1 ')}</b><p>مهلت پرداخت تا {new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(courseOrder.reservation_expires_at))}</p></div> : <p>اطلاعات مقصد پرداخت دریافت نشد؛ جزئیات سفارش را از بخش سفارش‌ها ببین.</p>}
      <p>{purchaseNotice}</p><Link className="button button--primary" to="/orders">رفتن به سفارش‌ها و بارگذاری رسید <ArrowLeft size={16} /></Link>
      <button className="text-button course-access-refresh" type="button" onClick={() => setEntitlementReload((value) => value + 1)}>رسید تأیید شده است؟ تازه‌کردن دسترسی</button>
    </div> : hasActiveEntitlement ? <div className="course-access-ready"><strong>این دوره به حساب تو دسترسی دارد.</strong><button className="text-button" type="button" onClick={() => setEntitlementReload((value) => value + 1)}>تازه‌کردن درس‌ها</button></div>
      : course.price_amount != null && course.price_amount > 0 && course.currency === 'IRR' ? <section className="course-checkout checkout-form"><h2>خرید و دسترسی به دوره</h2>
        {!userId ? <div className="lesson-progress__signin"><Link to="/account">برای سفارش دوره وارد حساب شو <ArrowLeft size={14} /></Link></div>
          : entitlementState === 'loading' ? <p className="collection-state" role="status">در حال بررسی دسترسی دوره…</p>
            : entitlementState === 'error' ? <div className="connection-notice">وضعیت دسترسی بررسی نشد؛ اتصال را بررسی کن و دوباره تلاش کن.<button className="text-button" type="button" onClick={() => setEntitlementReload((value) => value + 1)}>تلاش دوباره</button></div>
              : <form onSubmit={createCourseOrder}><p>قیمت نهایی از سرور خوانده می‌شود. پرداخت با رسید دستی است و دسترسی فقط پس از تأیید مدیر فعال خواهد شد.</p>
                <label className="consent-row"><input type="checkbox" checked={privacyAccepted} onChange={(event) => setPrivacyAccepted(event.target.checked)} required /><span>سیاست <Link to="/privacy" target="_blank" rel="noreferrer">حریم خصوصی</Link> را خوانده‌ام و می‌پذیرم.</span></label>
                <label className="consent-row"><input type="checkbox" checked={termsAccepted} onChange={(event) => setTermsAccepted(event.target.checked)} required /><span><Link to="/terms" target="_blank" rel="noreferrer">شرایط فروش و مرجوعی</Link> را خوانده‌ام و می‌پذیرم.</span></label>
                <button className="button button--primary" type="submit" disabled={purchaseBusy || !privacyAccepted || !termsAccepted}>{purchaseBusy ? 'در حال ثبت سفارش…' : 'ثبت سفارش دوره'}</button>
                {purchaseNotice && <p className="form-message" role="status">{purchaseNotice}</p>}
              </form>}
      </section> : course.price_amount === 0 ? <div className="course-access-ready"><strong>این دوره رایگان است.</strong><span>درس‌های رایگان را می‌توانی باز کنی و پیشرفتت را ذخیره کنی.</span></div>
        : <div className="connection-notice">خرید این دوره هنوز فعال نیست؛ قیمت باید به ریال و به‌صورت واقعی در پنل مدیریت ثبت شود.</div>}
    {lessons.length ? <div className="lesson-list">{lessons.map((lesson, index) => <details key={lesson.id} className="lesson-row"><summary><span>{new Intl.NumberFormat('fa-IR').format(index + 1)}. {lesson.title}</span><small>{lesson.summary}</small></summary><ContentBody blocks={lesson.body} /><LessonProgressPanel progress={progressRows[lesson.id] ?? blankLessonProgress(lesson.id)} signedIn={Boolean(userId)} loading={progressLoading} loadError={progressLoadError} onRetry={() => setProgressReload((value) => value + 1)} onSave={saveLessonProgress} /></details>)}</div> : <div className="connection-notice">درس قابل‌نمایشی برای این حساب در دسترس نیست؛ دسترسی به درس‌های پولی از سرور کنترل می‌شود.</div>}</article></>
}

function normalizeIranPhone(value: string) {
  const digits = value.replace(/[۰-۹٠-٩]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩'.indexOf(digit) % 10)).replace(/[\s()-]/g, '')
  if (/^09\d{9}$/.test(digits)) return `+98${digits.slice(1)}`
  if (/^9\d{9}$/.test(digits)) return `+98${digits}`
  return digits
}

function PageIntro({ path }: { path: keyof typeof routeInfo }) {
  const info = routeInfo[path]
  return <div className="page-intro"><div><span className="eyebrow">نقش‌نگار <span aria-hidden="true">/</span> {info.title}</span><h1>{info.title}</h1><p>{info.description}</p></div><PatchworkMark className="page-intro__mark" /></div>
}

function ListingPage({ path }: { path: keyof typeof routeInfo }) {
  const info = routeInfo[path]
  const detail: Record<string, string> = {
    '/shop': 'هنوز محصولی منتشر نشده است. پس از ورود اطلاعات واقعی، فهرست کالاها، قیمت و موجودی اینجا نمایش داده می‌شود.',
    '/learn': 'آموزش‌های کوتاه پس از آماده‌شدن محتوای بازبینی‌شده منتشر می‌شوند. برای شروع، دانشنامه را ببین.',
    '/courses': 'در حال حاضر دوره‌ای منتشر نشده است. دسترسی دوره‌ها پس از آماده‌شدن محتوای واقعی فعال می‌شود.',
    '/projects': 'هنوز پروژه‌ای ثبت نشده است. پس از ورود به حساب، طرح‌ها و یادداشت‌هایت را اینجا نگه می‌داری.',
    '/gallery': 'هنوز اثری با اجازهٔ انتشار در گالری نیست. آثار پس از رضایت سازندگان نمایش داده می‌شوند.',
    '/community': 'فضای گفت‌وگو هنوز راه‌اندازی نشده است؛ برای حفظ حریم کاربران، پیام نمونه نمایش داده نمی‌شود.',
    '/seller': 'فرم بررسی فروشندگی به‌زودی در این بخش قرار می‌گیرد. شرایط و تسویه پس از تعیین سیاست‌ها اعلام می‌شوند.',
    '/support': 'برای ارسال پیام پشتیبانی، ابتدا ورود امن باید فعال شود. مسیر پیام‌رسانی بدون ورود در دسترس نیست.',
    '/orders': 'سفارشی برای این حساب پیدا نشد. سفارش‌های واقعی پس از اتصال فروشگاه در این بخش دیده می‌شوند.',
    '/cart': 'سبد خریدت خالی است. کالاها پس از انتشار کاتالوگ واقعی در فروشگاه در دسترس خواهند بود.',
    '/about': 'نقش‌نگار فضایی برای یادگیری، طراحی و ثبت تجربه‌های چهل‌تکه‌دوزی است؛ با احترام به هنر دست و زمان یادگیری.',
    '/privacy': 'این بخش خلاصهٔ موقت است. سیاست نهایی نگهداری، حذف و استفاده از داده‌ها باید پیش از دریافت اطلاعات واقعی تکمیل شود.',
    '/terms': 'شرایط فروش، مرجوعی و مسئولیت محتوا پیش از فعال‌سازی خرید و اجتماع تکمیل خواهند شد.',
  }
  return <><PageIntro path={path} /><ConnectionNotice /><EmptyState title={info.title + ' هنوز محتوای منتشرشده ندارد'} detail={detail[path] ?? 'این بخش پس از آماده‌شدن دادهٔ واقعی فعال می‌شود.'} />
    {path === '/learn' && <Link className="button button--secondary centered-action" to="/guide">رفتن به دانشنامه <ArrowLeft size={17} /></Link>}
  </>
}

function AccountPage() {
  const [phone, setPhone] = useState('')
  const [token, setToken] = useState('')
  const [phase, setPhase] = useState<'phone' | 'token'>('phone')
  const [message, setMessage] = useState('')
  const [user, setUser] = useState<{ id: string; phone?: string; email?: string } | null>(null)
  const [displayName, setDisplayName] = useState('')
  const [chatHandle, setChatHandle] = useState('')
  const [allowDirectMessages, setAllowDirectMessages] = useState(false)
  const [profileLoading, setProfileLoading] = useState(false)
  const [profileBusy, setProfileBusy] = useState(false)
  const [profileMessage, setProfileMessage] = useState('')
  const [busy, setBusy] = useState(false)
  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setUser(data.session?.user ? { id: data.session.user.id, phone: data.session.user.phone, email: data.session.user.email } : null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUser(session?.user ? { id: session.user.id, phone: session.user.phone, email: session.user.email } : null))
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!supabase || !user) { setDisplayName(''); setChatHandle(''); setAllowDirectMessages(false); setProfileLoading(false); return () => { active = false } }
    setProfileLoading(true)
    supabase.from('qnr_profiles').select('display_name,chat_handle,allow_direct_messages').eq('id', user.id).maybeSingle().then(({ data, error }) => {
      if (!active) return
      if (error) setProfileMessage('نام نمایشی دریافت نشد؛ اطلاعات ورود همچنان امن است.')
      else { setDisplayName(data?.display_name ?? ''); setChatHandle(data?.chat_handle ?? ''); setAllowDirectMessages(Boolean(data?.allow_direct_messages)) }
      setProfileLoading(false)
    })
    return () => { active = false }
  }, [user?.id])
  async function requestCode(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) { setMessage('اتصال سرور تنظیم نشده است.'); return }
    const normalized = normalizeIranPhone(phone)
    if (!/^\+[1-9]\d{7,14}$/.test(normalized)) { setMessage('شماره را با پیش‌شمارهٔ کشور وارد کنید؛ نمونه: 0912… یا ‎+98912…'); return }
    setBusy(true); setMessage('')
    const { error } = await supabase.auth.signInWithOtp({ phone: normalized })
    setBusy(false)
    if (error) {
      const text = error.message.toLowerCase().includes('provider') || error.message.toLowerCase().includes('sms')
        ? 'ارسال پیامک هنوز برای این سرور تنظیم نشده است.'
        : 'ارسال کد انجام نشد؛ شماره را بررسی کنید و کمی بعد دوباره تلاش کنید.'
      setMessage(text)
      return
    }
    setPhone(normalized); setPhase('token'); setMessage('اگر سرویس پیامک فعال باشد، کد ورود برایت ارسال می‌شود.')
  }
  async function verifyCode(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    setBusy(true); setMessage('')
    const { error } = await supabase.auth.verifyOtp({ phone: normalizeIranPhone(phone), token: token.trim(), type: 'sms' })
    setBusy(false)
    setMessage(error ? 'کد تأیید نشد یا منقضی شده است. دوباره بررسی کن.' : 'ورود با موفقیت انجام شد.')
  }
  async function signOut() {
    if (!supabase) return
    await supabase.auth.signOut()
    setPhase('phone'); setToken(''); setMessage('از حسابت خارج شدی.')
  }
  async function saveProfile(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !user) return
    const name = displayName.trim()
    if (name.length < 2 || name.length > 80) { setProfileMessage('نام نمایشی باید بین ۲ تا ۸۰ نویسه باشد.'); return }
    const handle = chatHandle.trim().toLowerCase()
    if (handle && !/^[a-z0-9_]{3,24}$/.test(handle)) { setProfileMessage('شناسهٔ گفت‌وگو باید ۳ تا ۲۴ حرف انگلیسی کوچک، عدد یا زیرخط باشد.'); return }
    if (allowDirectMessages && !handle) { setProfileMessage('برای دریافت پیام خصوصی، ابتدا یک شناسهٔ گفت‌وگو انتخاب کن.'); return }
    setProfileBusy(true); setProfileMessage('')
    const { error } = await supabase.from('qnr_profiles').update({ display_name: name, chat_handle: handle || null, allow_direct_messages: allowDirectMessages }).eq('id', user.id)
    setProfileBusy(false)
    setProfileMessage(error ? (error.code === '23505' ? 'این شناسه قبلاً انتخاب شده است؛ شناسهٔ دیگری امتحان کن.' : 'اطلاعات ذخیره نشد؛ دوباره تلاش کن.') : 'اطلاعات حساب ذخیره شد.')
  }
  return <><PageIntro path="/account" /><div className="account-card">
    <div className="account-card__icon"><UserRound size={25} /></div>
    {user ? <><h2>حساب تو</h2><p>{user.phone || user.email || 'ورود با موفقیت انجام شد.'}</p><div className="connection-notice"><span className="connection-dot" />نشست امن برقرار است.</div><form className="profile-form" onSubmit={saveProfile}><label className="field-label" htmlFor="profile-display-name">نام نمایشی</label><input id="profile-display-name" minLength={2} maxLength={80} value={displayName} disabled={profileLoading} onChange={(event) => setDisplayName(event.target.value)} placeholder="نامی که دیگران می‌بینند" /><label className="field-label" htmlFor="profile-chat-handle">شناسهٔ گفت‌وگو (اختیاری)</label><input id="profile-chat-handle" maxLength={24} value={chatHandle} disabled={profileLoading} onChange={(event) => setChatHandle(event.target.value)} placeholder="مثل: goldooz" dir="ltr" autoCapitalize="none" /><label className="checkbox-label"><input type="checkbox" checked={allowDirectMessages} disabled={profileLoading || !chatHandle.trim()} onChange={(event) => setAllowDirectMessages(event.target.checked)} />پذیرش پیام خصوصی از کاربران دیگر</label><small className="field-hint">فقط با روشن‌کردن این گزینه در جست‌وجو پیدا می‌شوی؛ شماره و ایمیلت نمایش داده نمی‌شود.</small><button className="button button--primary" type="submit" disabled={profileBusy || profileLoading}>{profileBusy ? 'در حال ذخیره…' : profileLoading ? 'در حال دریافت…' : 'ذخیرهٔ اطلاعات'}</button>{profileMessage && <p className="form-message" role="status">{profileMessage}</p>}</form><Link className="text-link" to="/community">رفتن به گفت‌وگوها <ArrowLeft size={15} /></Link><Link className="text-link" to="/support">درخواست اصلاح یا حذف داده‌ها <ArrowLeft size={15} /></Link><button className="button button--secondary" onClick={signOut}>خروج از حساب</button></> : <>
      <h2>ورود امن با شمارهٔ همراه</h2><p>کد یک‌بارمصرف فقط از سرویس پیامک سرور ارسال می‌شود؛ کد آزمایشی یا ساختگی نداریم.</p>
      {!supabaseConfigured && <div className="connection-notice"><span className="connection-dot" />{backendMessage()}</div>}
      {phase === 'phone' ? <form className="auth-form" onSubmit={requestCode}><label className="field-label" htmlFor="phone-number">شمارهٔ همراه</label><input id="phone-number" autoComplete="tel" inputMode="tel" value={phone} onChange={(event) => setPhone(event.target.value)} placeholder="۰۹۱۲…" disabled={!supabaseConfigured || busy} /><button className={`button ${supabaseConfigured ? 'button--primary' : 'button--disabled'}`} type="submit" disabled={!supabaseConfigured || busy}>{busy ? 'در حال ارسال…' : 'دریافت کد ورود'}</button></form> : <form className="auth-form" onSubmit={verifyCode}><label className="field-label" htmlFor="otp-code">کد پیامک‌شده</label><input id="otp-code" inputMode="numeric" autoComplete="one-time-code" value={token} onChange={(event) => setToken(event.target.value)} placeholder="کد تأیید" disabled={busy} /><button className="button button--primary" type="submit" disabled={busy || !token.trim()}>{busy ? 'در حال بررسی…' : 'تأیید و ورود'}</button><button className="text-button" type="button" onClick={() => { setPhase('phone'); setMessage('') }}>ویرایش شماره</button></form>}
      {message && <p className="form-message" role="status">{message}</p>}
    </>}
  </div></>
}

type CmsKind = 'products' | 'tutorials' | 'courses' | 'categories' | 'pages'
type CmsRecord = { id: string; slug: string; title: string; summary: string; is_published: boolean; price_amount?: number | null; inventory_count?: number; body?: unknown }
const cmsLabels: Record<CmsKind, string> = { products: 'کالاها', tutorials: 'آموزش‌ها', courses: 'دوره‌ها', categories: 'دسته‌ها', pages: 'صفحه‌ها' }
const cmsSingularLabels: Record<CmsKind, string> = { products: 'کالا', tutorials: 'آموزش', courses: 'دوره', categories: 'دسته', pages: 'صفحه' }

async function loadCmsRecords(kind: CmsKind): Promise<CmsRecord[]> {
  if (!supabase) return []
  if (kind === 'products') {
    const { data, error } = await supabase.from('qnr_products').select('id,slug,name,description,is_published,price_amount,inventory_count').order('created_at', { ascending: false })
    if (error) throw error
    return ((data ?? []) as Array<{ id: string; slug: string; name: string; description: string; is_published: boolean; price_amount: number | null; inventory_count: number }>).map((row) => ({ id: row.id, slug: row.slug, title: row.name, summary: row.description, is_published: row.is_published, price_amount: row.price_amount, inventory_count: row.inventory_count }))
  }
  if (kind === 'tutorials') {
    const { data, error } = await supabase.from('qnr_tutorials').select('id,slug,title,summary,is_published,body').order('created_at', { ascending: false })
    if (error) throw error
    return ((data ?? []) as Array<{ id: string; slug: string; title: string; summary: string; is_published: boolean; body: unknown }>).map((row) => ({ ...row }))
  }
  if (kind === 'categories') {
    const { data, error } = await supabase.from('qnr_categories').select('id,slug,name,description,is_published').order('sort_order')
    if (error) throw error
    return ((data ?? []) as Array<{ id: string; slug: string; name: string; description: string; is_published: boolean }>).map((row) => ({ id: row.id, slug: row.slug, title: row.name, summary: row.description, is_published: row.is_published }))
  }
  if (kind === 'pages') {
    const { data, error } = await supabase.from('qnr_site_pages').select('id,slug,title,is_published,body').order('slug')
    if (error) throw error
    return ((data ?? []) as Array<{ id: string; slug: string; title: string; is_published: boolean; body: unknown }>).map((row) => ({ ...row, summary: '' }))
  }
  const { data, error } = await supabase.from('qnr_courses').select('id,slug,title,summary,is_published,price_amount').order('created_at', { ascending: false })
  if (error) throw error
  return ((data ?? []) as Array<{ id: string; slug: string; title: string; summary: string; is_published: boolean; price_amount: number | null }>).map((row) => ({ ...row }))
}

function AuditTrail() {
  const [entries, setEntries] = useState<Array<{ id: number; action: string; subject_type: string; created_at: string }>>([])
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading')
  useEffect(() => {
    let active = true
    if (!supabase) { setState('error'); return () => { active = false } }
    supabase.from('qnr_audit_log').select('id,action,subject_type,created_at').order('created_at', { ascending: false }).limit(12).then(({ data, error }) => {
      if (!active) return
      if (error) { setState('error'); return }
      setEntries((data ?? []) as Array<{ id: number; action: string; subject_type: string; created_at: string }>)
      setState('ready')
    })
    return () => { active = false }
  }, [])
  const actionLabels: Record<string, string> = { insert: 'افزود', update: 'ویرایش کرد', delete: 'حذف کرد' }
  const subjectLabels: Record<string, string> = { qnr_products: 'کالا', qnr_tutorials: 'آموزش', qnr_courses: 'دوره', qnr_categories: 'دسته', qnr_site_pages: 'صفحه', qnr_course_lessons: 'درس' }
  return <section className="audit-panel"><div className="audit-panel__heading"><h2>تاریخچهٔ تغییرات</h2><span>ثبت خودکار</span></div>
    {state === 'loading' ? <p className="collection-state">در حال دریافت…</p> : state === 'error' ? <p className="audit-empty">تاریخچه در دسترس نیست.</p> : entries.length ? <ul>{entries.map((entry) => <li key={entry.id}><span>{actionLabels[entry.action] ?? entry.action} {subjectLabels[entry.subject_type] ?? entry.subject_type}</span><time dateTime={entry.created_at}>{new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(entry.created_at))}</time></li>)}</ul> : <p className="audit-empty">هنوز تغییری ثبت نشده است.</p>}
  </section>
}

function StoreSettingsPanel() {
  const [loading, setLoading] = useState(true)
  const [saving, setSaving] = useState(false)
  const [notice, setNotice] = useState('')
  const [cardHolder, setCardHolder] = useState('')
  const [cardNumber, setCardNumber] = useState('')
  const [shippingAmount, setShippingAmount] = useState('')
  const [shippingPolicy, setShippingPolicy] = useState('')
  const [returnsPolicy, setReturnsPolicy] = useState('')
  const [contactPhone, setContactPhone] = useState('')
  const [reservationMinutes, setReservationMinutes] = useState('30')
  const [checkoutEnabled, setCheckoutEnabled] = useState(false)
  useEffect(() => {
    let active = true
    if (!supabase) { setLoading(false); return () => { active = false } }
    supabase.from('qnr_store_settings').select('card_holder,card_number,shipping_amount,shipping_policy,returns_policy,contact_phone,reservation_minutes,checkout_enabled').eq('singleton', true).maybeSingle().then(({ data, error }) => {
      if (!active) return
      if (error) setNotice('تنظیمات فروشگاه دریافت نشد.')
      if (data) {
        const row = data as { card_holder: string | null; card_number: string | null; shipping_amount: number | null; shipping_policy: string | null; returns_policy: string | null; contact_phone: string | null; reservation_minutes: number; checkout_enabled: boolean }
        setCardHolder(row.card_holder ?? ''); setCardNumber(row.card_number ?? ''); setShippingAmount(row.shipping_amount == null ? '' : String(row.shipping_amount)); setShippingPolicy(row.shipping_policy ?? ''); setReturnsPolicy(row.returns_policy ?? ''); setContactPhone(row.contact_phone ?? ''); setReservationMinutes(String(row.reservation_minutes)); setCheckoutEnabled(row.checkout_enabled)
      }
      setLoading(false)
    })
    return () => { active = false }
  }, [])
  async function saveSettings(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    setSaving(true); setNotice('')
    const digits = cardNumber.replace(/\D/g, '')
    const { error } = await supabase.from('qnr_store_settings').update({
      card_holder: cardHolder.trim() || null,
      card_number: digits || null,
      shipping_amount: shippingAmount.trim() ? Number(shippingAmount) : null,
      shipping_policy: shippingPolicy.trim() || null,
      returns_policy: returnsPolicy.trim() || null,
      contact_phone: contactPhone.trim() || null,
      reservation_minutes: Number(reservationMinutes),
      checkout_enabled: checkoutEnabled,
    }).eq('singleton', true)
    setSaving(false)
    if (error) { setNotice('ذخیره نشد؛ برای فعال‌کردن خرید، همهٔ اطلاعات واقعی را کامل کنید.'); return }
    setCardNumber(digits); setNotice(checkoutEnabled ? 'تنظیمات ذخیره شد؛ اطلاعات پرداخت برای کاربران واردشده قابل‌مشاهده است.' : 'تنظیمات ذخیره شد؛ پرداخت همچنان غیرفعال است.')
  }
  if (loading) return <p className="collection-state" role="status">در حال دریافت تنظیمات فروشگاه…</p>
  return <section className="store-settings"><span className="eyebrow">پیش‌نیاز فروش</span><h2>پرداخت و ارسال</h2><p className="store-settings__intro">تا زمانی که اطلاعات واقعی وارد و پرداخت فعال نشود، ثبت سفارش در دسترس خریداران نیست. شمارهٔ کارت پس از فعال‌سازی فقط برای کاربران واردشده نمایش داده می‌شود.</p>
    <form className="admin-form store-settings__form" onSubmit={saveSettings}>
      <label className="field-label" htmlFor="store-card-holder">نام دارندهٔ کارت</label><input id="store-card-holder" value={cardHolder} onChange={(event) => setCardHolder(event.target.value)} />
      <label className="field-label" htmlFor="store-card-number">شمارهٔ کارت مقصد (۱۶ رقم)</label><input id="store-card-number" inputMode="numeric" autoComplete="off" value={cardNumber} onChange={(event) => setCardNumber(event.target.value)} />
      <label className="field-label" htmlFor="store-shipping-amount">هزینهٔ ارسال به ریال (برای ارسال رایگان صفر)</label><input id="store-shipping-amount" type="number" min="0" step="1" value={shippingAmount} onChange={(event) => setShippingAmount(event.target.value)} />
      <label className="field-label" htmlFor="store-shipping-policy">قواعد ارسال</label><textarea id="store-shipping-policy" rows={3} value={shippingPolicy} onChange={(event) => setShippingPolicy(event.target.value)} />
      <label className="field-label" htmlFor="store-returns-policy">قواعد مرجوعی</label><textarea id="store-returns-policy" rows={3} value={returnsPolicy} onChange={(event) => setReturnsPolicy(event.target.value)} />
      <label className="field-label" htmlFor="store-contact-phone">شمارهٔ تماس پشتیبانی</label><input id="store-contact-phone" inputMode="tel" value={contactPhone} onChange={(event) => setContactPhone(event.target.value)} />
      <label className="field-label" htmlFor="store-reservation">مدت نگهداری موجودی برای پرداخت (دقیقه)</label><input id="store-reservation" type="number" min="5" max="1440" step="1" value={reservationMinutes} onChange={(event) => setReservationMinutes(event.target.value)} />
      <label className="publish-toggle"><input type="checkbox" checked={checkoutEnabled} onChange={(event) => setCheckoutEnabled(event.target.checked)} /> فعال‌سازی ثبت سفارش و نمایش شمارهٔ کارت</label>
      <button className="button button--primary" type="submit" disabled={saving}>{saving ? 'در حال ذخیره…' : 'ذخیرهٔ تنظیمات فروشگاه'}</button>
      {notice && <p className="form-message" role="status">{notice}</p>}
    </form>
  </section>
}

function AdminPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [authLoading, setAuthLoading] = useState(true)
  const [accessLoading, setAccessLoading] = useState(false)
  const [authorized, setAuthorized] = useState(false)
  const [accessError, setAccessError] = useState(false)
  const [kind, setKind] = useState<CmsKind>('products')
  const [items, setItems] = useState<CmsRecord[]>([])
  const [itemsLoading, setItemsLoading] = useState(false)
  const [formBusy, setFormBusy] = useState(false)
  const [editingId, setEditingId] = useState<string | null>(null)
  const [slug, setSlug] = useState('')
  const [title, setTitle] = useState('')
  const [summary, setSummary] = useState('')
  const [body, setBody] = useState('')
  const [price, setPrice] = useState('')
  const [stock, setStock] = useState('0')
  const [published, setPublished] = useState(false)
  const [notice, setNotice] = useState('')

  useEffect(() => {
    if (!supabase) { setAuthLoading(false); return }
    supabase.auth.getSession().then(({ data }) => { setUserId(data.session?.user.id ?? null); setAuthLoading(false) })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => { setUserId(session?.user.id ?? null); setAuthLoading(false) })
    return () => listener.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    let active = true
    if (!userId || !supabase) { setAuthorized(false); setAccessLoading(false); return () => { active = false } }
    setAccessLoading(true); setAccessError(false)
    supabase.from('qnr_user_roles').select('role').eq('user_id', userId).eq('role', 'admin').maybeSingle().then(({ data, error }) => {
      if (!active) return
      setAuthorized(Boolean(data && !error)); setAccessError(Boolean(error)); setAccessLoading(false)
    })
    return () => { active = false }
  }, [userId])

  useEffect(() => {
    let active = true
    if (!authorized) return () => { active = false }
    setItemsLoading(true)
    loadCmsRecords(kind).then((records) => { if (active) setItems(records) }).catch(() => { if (active) setNotice('فهرست دریافت نشد؛ مجوزها و اتصال را بررسی کنید.') }).finally(() => { if (active) setItemsLoading(false) })
    return () => { active = false }
  }, [authorized, kind])

  function clearForm() {
    setEditingId(null); setSlug(''); setTitle(''); setSummary(''); setBody(''); setPrice(''); setStock('0'); setPublished(false)
  }
  function editItem(item: CmsRecord) {
    setEditingId(item.id); setSlug(item.slug); setTitle(item.title); setSummary(item.summary); setPrice(item.price_amount == null ? '' : String(item.price_amount)); setStock(String(item.inventory_count ?? 0)); setPublished(item.is_published)
    const blocks = Array.isArray(item.body) ? item.body as LessonBlock[] : []
    setBody(blocks.map((block) => block.heading ? `## ${block.heading}\n${block.text ?? ''}` : block.text ?? '').join('\n\n'))
    setNotice('')
  }
  async function saveItem(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    if (published && (kind === 'products' || kind === 'courses') && !price.trim()) { setNotice('برای انتشار کالا یا دوره، قیمت واقعی را وارد کنید؛ برای محتوای رایگان عدد صفر بگذارید.'); return }
    setFormBusy(true); setNotice('')
    const numberPrice = price.trim() ? Number(price.replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit)))) : null
    const numberStock = Number(stock.replace(/[۰-۹]/g, (digit) => String('۰۱۲۳۴۵۶۷۸۹'.indexOf(digit))))
    let error: { message: string } | null = null
    if (kind === 'products') {
      const payload = { slug: slug.trim(), name: title.trim(), description: summary.trim(), price_amount: numberPrice, inventory_count: numberStock, is_published: published }
      const result = editingId ? await supabase.from('qnr_products').update(payload).eq('id', editingId) : await supabase.from('qnr_products').insert(payload)
      error = result.error
    } else if (kind === 'tutorials') {
      const payload = { slug: slug.trim(), title: title.trim(), summary: summary.trim(), body: body.trim() ? body.split(/\n\s*\n/).map((text) => ({ type: 'paragraph', text: text.trim() })) : [], is_published: published, published_at: published ? new Date().toISOString() : null }
      const result = editingId ? await supabase.from('qnr_tutorials').update(payload).eq('id', editingId) : await supabase.from('qnr_tutorials').insert(payload)
      error = result.error
    } else if (kind === 'courses') {
      const payload = { slug: slug.trim(), title: title.trim(), summary: summary.trim(), price_amount: numberPrice, is_published: published, published_at: published ? new Date().toISOString() : null }
      const result = editingId ? await supabase.from('qnr_courses').update(payload).eq('id', editingId) : await supabase.from('qnr_courses').insert(payload)
      error = result.error
    } else if (kind === 'categories') {
      const payload = { slug: slug.trim(), name: title.trim(), description: summary.trim(), is_published: published }
      const result = editingId ? await supabase.from('qnr_categories').update(payload).eq('id', editingId) : await supabase.from('qnr_categories').insert(payload)
      error = result.error
    } else {
      const bodyBlocks = body.trim().split(/\n\s*\n/).filter(Boolean).map((block) => {
        const heading = block.match(/^##\s+(.+)\n([\s\S]*)$/)
        return heading ? { type: 'heading', heading: heading[1], text: heading[2].trim() } : { type: 'paragraph', text: block.trim() }
      })
      const payload = { slug: slug.trim(), title: title.trim(), body: bodyBlocks, is_published: published, published_at: published ? new Date().toISOString() : null }
      const result = editingId ? await supabase.from('qnr_site_pages').update(payload).eq('id', editingId) : await supabase.from('qnr_site_pages').insert(payload)
      error = result.error
    }
    setFormBusy(false)
    if (error) { setNotice('ذخیره انجام نشد؛ نشانی کوتاه، قیمت و مجوز مدیر را بررسی کنید.'); return }
    setNotice(editingId ? 'تغییرات ذخیره شد.' : 'محتوا ثبت شد.')
    clearForm()
    try { setItems(await loadCmsRecords(kind)) } catch { setNotice('تغییر ذخیره شد، اما فهرست تازه نشد؛ صفحه را دوباره بارگذاری کنید.') }
  }
  async function togglePublished(item: CmsRecord) {
    if (!supabase) return
    if (!item.is_published && (kind === 'products' || kind === 'courses') && item.price_amount == null) { setNotice('پیش از انتشار، قیمت واقعی را ثبت کنید؛ برای مورد رایگان عدد صفر بگذارید.'); return }
    setNotice('')
    let error: { message: string } | null = null
    if (kind === 'products') error = (await supabase.from('qnr_products').update({ is_published: !item.is_published }).eq('id', item.id)).error
    if (kind === 'tutorials') error = (await supabase.from('qnr_tutorials').update({ is_published: !item.is_published, published_at: !item.is_published ? new Date().toISOString() : null }).eq('id', item.id)).error
    if (kind === 'courses') error = (await supabase.from('qnr_courses').update({ is_published: !item.is_published, published_at: !item.is_published ? new Date().toISOString() : null }).eq('id', item.id)).error
    if (kind === 'categories') error = (await supabase.from('qnr_categories').update({ is_published: !item.is_published }).eq('id', item.id)).error
    if (kind === 'pages') error = (await supabase.from('qnr_site_pages').update({ is_published: !item.is_published, published_at: !item.is_published ? new Date().toISOString() : null }).eq('id', item.id)).error
    if (error) { setNotice('وضعیت انتشار تغییر نکرد؛ مجوز مدیر را بررسی کنید.'); return }
    setItems(await loadCmsRecords(kind)); setNotice('وضعیت انتشار به‌روز شد.')
  }
  async function deleteItem(item: CmsRecord) {
    if (!supabase || !window.confirm(`«${item.title}» حذف شود؟ این کار قابل بازگشت نیست.`)) return
    let error: { message: string } | null = null
    if (kind === 'products') error = (await supabase.from('qnr_products').delete().eq('id', item.id)).error
    if (kind === 'tutorials') error = (await supabase.from('qnr_tutorials').delete().eq('id', item.id)).error
    if (kind === 'courses') error = (await supabase.from('qnr_courses').delete().eq('id', item.id)).error
    if (kind === 'categories') error = (await supabase.from('qnr_categories').delete().eq('id', item.id)).error
    if (kind === 'pages') error = (await supabase.from('qnr_site_pages').delete().eq('id', item.id)).error
    if (error) { setNotice('حذف انجام نشد؛ مجوز مدیر را بررسی کنید.'); return }
    setItems(await loadCmsRecords(kind)); setNotice('محتوا حذف شد.')
    if (editingId === item.id) clearForm()
  }

  return <><PageIntro path="/admin" />
    {!supabaseConfigured ? <EmptyState title="اتصال سرور تنظیم نشده" detail={backendMessage()} />
      : authLoading || accessLoading ? <p className="collection-state" role="status">در حال بررسی نشست و نقش…</p>
      : !userId ? <div className="admin-gate"><h2>برای ورود به مدیریت، وارد حساب شو</h2><Link className="button button--primary" to="/account">رفتن به ورود <ArrowLeft size={16} /></Link></div>
      : accessError ? <EmptyState title="بررسی دسترسی انجام نشد" detail="اتصال را بررسی کنید و دوباره تلاش کنید." />
      : !authorized ? <EmptyState title="این حساب دسترسی مدیریت ندارد" detail="نقش مدیر فقط از مسیر امن سرور به حساب اختصاص داده می‌شود." />
      : <div className="admin-panel">
        <div className="admin-heading"><div><span className="eyebrow">پنل نقش‌نگار</span><h2>مدیریت محتوا</h2></div><span className="admin-count">{new Intl.NumberFormat('fa-IR').format(items.length)} مورد در {cmsLabels[kind]}</span></div>
        <div className="admin-tabs" role="tablist" aria-label="نوع محتوا">
          {(Object.keys(cmsLabels) as CmsKind[]).map((value) => <button key={value} role="tab" aria-selected={kind === value} className={kind === value ? 'is-selected' : ''} onClick={() => { setKind(value); clearForm(); setNotice('') }}>{cmsLabels[value]}</button>)}
        </div>
        <div className="admin-columns">
          <form className="admin-form" onSubmit={saveItem}>
            <div className="admin-form__heading"><h3>{editingId ? 'ویرایش محتوا' : `افزودن ${cmsSingularLabels[kind]}`}</h3>{editingId && <button className="text-button" type="button" onClick={clearForm}>لغو ویرایش</button>}</div>
            <label className="field-label" htmlFor="cms-slug">نشانی کوتاه انگلیسی</label><input id="cms-slug" required pattern="[a-z0-9]+(-[a-z0-9]+)*" value={slug} onChange={(event) => setSlug(event.target.value.toLowerCase())} placeholder="مثلاً patchwork-basics" />
            <label className="field-label" htmlFor="cms-title">عنوان</label><input id="cms-title" required value={title} onChange={(event) => setTitle(event.target.value)} />
            {kind !== 'pages' && <><label className="field-label" htmlFor="cms-summary">{kind === 'categories' ? 'توضیح دسته' : 'توضیح کوتاه'}</label><textarea id="cms-summary" rows={3} value={summary} onChange={(event) => setSummary(event.target.value)} /></>}
            {(kind === 'tutorials' || kind === 'pages') && <><label className="field-label" htmlFor="cms-body">{kind === 'pages' ? 'متن صفحه' : 'متن آموزش'}</label><textarea id="cms-body" rows={7} value={body} onChange={(event) => setBody(event.target.value)} placeholder="هر بند را با یک خط خالی جدا کن؛ عنوان بخش با ## شروع شود" /></>}
            {(kind === 'products' || kind === 'courses') && <><label className="field-label" htmlFor="cms-price">{kind === 'products' ? 'قیمت به ریال' : 'شهریه به ریال'}</label><input id="cms-price" type="number" min="0" inputMode="numeric" required={published} value={price} onChange={(event) => setPrice(event.target.value)} />{kind === 'products' && <><label className="field-label" htmlFor="cms-stock">موجودی</label><input id="cms-stock" type="number" min="0" required value={stock} onChange={(event) => setStock(event.target.value)} /></>}</>}
            <label className="publish-toggle"><input type="checkbox" checked={published} onChange={(event) => setPublished(event.target.checked)} /> انتشار عمومی</label>
            <button className="button button--primary" type="submit" disabled={formBusy}>{formBusy ? 'در حال ذخیره…' : editingId ? 'ذخیرهٔ تغییرات' : 'ثبت محتوا'}</button>
            {notice && <p className="form-message" role="status">{notice}</p>}
          </form>
          <section className="admin-list" aria-label={cmsLabels[kind]}>
            {itemsLoading ? <p className="collection-state">در حال دریافت…</p> : items.length ? items.map((item) => <article className="admin-record" key={item.id}>
              <div><h3>{item.title}</h3><p>{item.slug}</p><span className={item.is_published ? 'publish-badge is-published' : 'publish-badge'}>{item.is_published ? 'منتشرشده' : 'پیش‌نویس'}</span></div>
              <div className="admin-record__actions"><button onClick={() => editItem(item)}>ویرایش</button><button onClick={() => togglePublished(item)}>{item.is_published ? 'پیش‌نویس' : 'انتشار'}</button><button className="danger-action" onClick={() => deleteItem(item)}>حذف</button></div>
            </article>) : <EmptyState title="محتوایی ثبت نشده" detail="از فرم کنار صفحه اولین مورد واقعی را اضافه کن." />}
          </section>
        </div>
        <AuditTrail />
        <StoreSettingsPanel />
        <PaymentReviewPanel />
        <SupportInboxPanel />
        {notice && <p className="admin-notice" role="status">{notice}</p>}
      </div>}
  </>
}

function DesignerPage() {
  const [size, setSize] = useState(5)
  const [units, setUnits] = useState<'cm' | 'in'>('cm')
  const [finishedSize, setFinishedSize] = useState(25)
  const [allowance, setAllowance] = useState(.7)
  const [fabricWidth, setFabricWidth] = useState(112)
  const [title, setTitle] = useState('طرح تازه')
  const [cells, setCells] = useState<Record<number, number>>({})
  const [userId, setUserId] = useState<string | null>(null)
  const [searchParams, setSearchParams] = useSearchParams()
  const projectId = searchParams.get('project')
  const [busy, setBusy] = useState(false)
  const [notice, setNotice] = useState('')
  const [loadingProject, setLoadingProject] = useState(Boolean(projectId))
  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setUserId(data.session?.user.id ?? null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUserId(session?.user.id ?? null))
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!projectId) { setLoadingProject(false); return () => { active = false } }
    if (!supabase || !userId) { setLoadingProject(false); return () => { active = false } }
    setLoadingProject(true)
    supabase.from('qnr_projects').select('id,title,grid_size,unit,finished_size,seam_allowance,fabric_width,cells').eq('id', projectId).maybeSingle().then(({ data, error }) => {
      if (!active) return
      if (error || !data) { setNotice('این پروژه پیدا نشد یا در دسترس حساب تو نیست.'); setLoadingProject(false); return }
      const row = data as { title: string; grid_size: number; unit: 'cm' | 'in'; finished_size: number; seam_allowance: number; fabric_width: number; cells: Record<number, number> }
      setTitle(row.title); setSize(row.grid_size); setUnits(row.unit); setFinishedSize(Number(row.finished_size)); setAllowance(Number(row.seam_allowance)); setFabricWidth(Number(row.fabric_width)); setCells(row.cells ?? {})
      setNotice('پروژه از دفتر تو بارگذاری شد.'); setLoadingProject(false)
    })
    return () => { active = false }
  }, [projectId, userId])
  const cutSize = finishedSize > 0 ? finishedSize / size + allowance * 2 : 0
  const squaresPerStrip = cutSize > 0 ? Math.floor(fabricWidth / cutSize) : 0
  const estimatedLength = squaresPerStrip > 0 ? Math.ceil((size * size) / squaresPerStrip) * cutSize * 1.1 : null
  function changeUnits(value: 'cm' | 'in') {
    setUnits(value)
    if (value === 'cm') { setFinishedSize(25); setAllowance(.7); setFabricWidth(112) }
    else { setFinishedSize(10); setAllowance(.25); setFabricWidth(44) }
  }
  async function saveProject() {
    if (!supabase || !userId) { setNotice('برای ذخیرهٔ ابری، ابتدا وارد حساب شو.'); return }
    setBusy(true); setNotice('')
    const payload = { user_id: userId, title: title.trim(), grid_size: size, unit: units, finished_size: finishedSize, seam_allowance: allowance, fabric_width: fabricWidth, cells }
    const result = projectId
      ? await supabase.from('qnr_projects').update(payload).eq('id', projectId).select('id').maybeSingle()
      : await supabase.from('qnr_projects').insert(payload).select('id').single()
    setBusy(false)
    if (result.error || !result.data?.id) { setNotice('ذخیره انجام نشد؛ اتصال و اندازه‌ها را بررسی و دوباره تلاش کن.'); return }
    setSearchParams({ project: result.data.id })
    setNotice('پروژه در دفتر ابری تو ذخیره شد.')
  }
  function newProject() {
    setTitle('طرح تازه'); setSize(5); setCells({}); setSearchParams({}); setFinishedSize(units === 'cm' ? 25 : 10); setAllowance(units === 'cm' ? .7 : .25); setFabricWidth(units === 'cm' ? 112 : 44); setNotice('طرح تازه آماده است.')
  }
  return <><PageIntro path="/designer" /><div className="designer-card">
    <div className="designer-card__copy"><span className="eyebrow">ابزار طراحی</span><h2>{projectId ? 'ویرایش پروژه' : 'یک بلوک ساده بچین'}</h2><p>رنگ خانه‌ها را بچین و اندازهٔ برش را برآورد کن. برآورد برای مربع‌های هم‌اندازه و پارچهٔ بدون عیب است؛ پیش از برش، اندازه‌ها را روی پارچهٔ خودت بازبینی کن.</p>
      <label className="field-label" htmlFor="project-title">نام پروژه</label><input id="project-title" value={title} maxLength={120} onChange={(event) => setTitle(event.target.value)} />
      <label className="field-label" htmlFor="grid-size">تعداد خانه‌ها در هر ضلع</label><select id="grid-size" value={size} onChange={(event) => setSize(Number(event.target.value))}><option value={3}>۳ × ۳</option><option value={5}>۵ × ۵</option><option value={7}>۷ × ۷</option></select>
      <label className="field-label" htmlFor="units">واحد اندازه‌گیری</label><select id="units" value={units} onChange={(event) => changeUnits(event.target.value as 'cm' | 'in')}><option value="cm">سانتی‌متر</option><option value="in">اینچ</option></select>
      <div className="designer-measures"><label><span>اندازهٔ نهایی بلوک ({units})</span><input type="number" min="1" step="0.1" value={finishedSize} onChange={(event) => setFinishedSize(Number(event.target.value))} /></label><label><span>جای دوخت هر لبه ({units})</span><input type="number" min="0" step="0.01" value={allowance} onChange={(event) => setAllowance(Number(event.target.value))} /></label><label><span>عرض پارچه ({units})</span><input type="number" min="1" step="0.1" value={fabricWidth} onChange={(event) => setFabricWidth(Number(event.target.value))} /></label></div>
      <div className="estimate-card"><span>اندازهٔ برش هر مربع</span><strong>{cutSize.toFixed(2)} {units === 'cm' ? 'سانتی‌متر' : 'اینچ'}</strong><span>برآورد طول پارچه با ۱۰٪ پرت</span><strong>{estimatedLength == null ? 'عرض پارچه کافی نیست' : `${estimatedLength.toFixed(1)} ${units === 'cm' ? 'سانتی‌متر' : 'اینچ'}`}</strong></div>
      {!userId && <p className="designer-hint">برای ذخیرهٔ ابری، <Link to="/account">وارد حساب شو</Link>. طرح تا آن زمان فقط در همین صفحه نگه داشته می‌شود.</p>}
      <div className="designer-actions"><button className={`button ${userId ? 'button--primary' : 'button--disabled'}`} onClick={saveProject} disabled={!userId || busy || loadingProject || !title.trim()}>{busy ? 'در حال ذخیره…' : projectId ? 'ذخیرهٔ تغییرات' : 'ذخیره در دفتر پروژه'}</button>{projectId && <button className="button button--secondary" onClick={newProject}>طرح تازه</button>}</div>
      {notice && <p className="form-message" role="status">{notice}</p>}
    </div>
    <div><p className="designer-hint">روی هر خانه بزن تا رنگ آن عوض شود.</p><PatternGrid size={size} cells={cells} onChange={setCells} /></div>
  </div></>
}

function PatternGrid({ size, cells, onChange }: { size: number; cells: Record<number, number>; onChange: (cells: Record<number, number>) => void }) {
  const colors = ['fabric-sage', 'fabric-coral', 'fabric-mustard', 'fabric-indigo', 'fabric-cream']
  return <div className="pattern-grid" style={{ gridTemplateColumns: `repeat(${size}, 1fr)` }} aria-label={`شبکهٔ طراحی ${size} در ${size}`}>
    {Array.from({ length: size * size }, (_, index) => <button key={index} className={`pattern-cell ${colors[cells[index] ?? ((Math.floor(index / size) + index) % colors.length)]}`} aria-label={`خانهٔ ${index + 1}`} onClick={() => onChange({ ...cells, [index]: ((cells[index] ?? ((Math.floor(index / size) + index) % colors.length)) + 1) % colors.length })} />)}
  </div>
}

function ProjectsPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [projects, setProjects] = useState<Array<{ id: string; title: string; grid_size: number; unit: 'cm' | 'in'; finished_size: number; updated_at: string }>>([])
  const [status, setStatus] = useState<'loading' | 'ready' | 'error' | 'offline'>('loading')
  useEffect(() => {
    if (!supabase) { setStatus('offline'); return }
    supabase.auth.getSession().then(({ data }) => setUserId(data.session?.user.id ?? null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setUserId(session?.user.id ?? null))
    return () => listener.subscription.unsubscribe()
  }, [])
  useEffect(() => {
    let active = true
    if (!supabase) { setStatus('offline'); return () => { active = false } }
    if (!userId) { setStatus('ready'); setProjects([]); return () => { active = false } }
    setStatus('loading')
    supabase.from('qnr_projects').select('id,title,grid_size,unit,finished_size,updated_at').order('updated_at', { ascending: false }).then(({ data, error }) => {
      if (!active) return
      if (error) { setStatus('error'); return }
      setProjects((data ?? []) as Array<{ id: string; title: string; grid_size: number; unit: 'cm' | 'in'; finished_size: number; updated_at: string }>)
      setStatus('ready')
    })
    return () => { active = false }
  }, [userId])
  async function removeProject(id: string, title: string) {
    if (!supabase || !window.confirm(`پروژهٔ «${title}» از دفتر حذف شود؟`)) return
    const { error } = await supabase.from('qnr_projects').delete().eq('id', id)
    if (error) { setStatus('error'); return }
    setProjects((current) => current.filter((project) => project.id !== id))
  }
  return <><PageIntro path="/projects" />
    {!supabaseConfigured || status === 'offline' ? <EmptyState title="اتصال سرور تنظیم نشده" detail="دفتر پروژه برای ذخیرهٔ خصوصی به حساب نقش‌نگار نیاز دارد." />
      : !userId && status === 'ready' ? <div className="projects-signin"><EmptyState title="دفتر شخصی تو" detail="برای دیدن و ذخیرهٔ پروژه‌ها، وارد حساب شو. هر پروژه پس از ذخیره فقط برای حساب خودت قابل‌مشاهده است." /><Link className="button button--primary" to="/account">ورود به حساب <ArrowLeft size={16} /></Link></div>
      : status === 'loading' ? <p className="collection-state" role="status">در حال دریافت دفتر پروژه…</p>
      : status === 'error' ? <EmptyState title="دفتر پروژه دریافت نشد" detail="اتصال را بررسی کنید و دوباره تلاش کنید." />
      : projects.length ? <><div className="projects-toolbar"><span>{new Intl.NumberFormat('fa-IR').format(projects.length)} پروژه</span><Link className="button button--primary" to="/designer">ساخت طرح تازه <ArrowLeft size={16} /></Link></div><div className="project-list">{projects.map((project) => <article className="project-card" key={project.id}><PatchworkMark className="project-card__mark" /><div className="project-card__body"><h2>{project.title}</h2><p>{project.grid_size} × {project.grid_size} خانه · اندازهٔ نهایی {project.finished_size} {project.unit === 'cm' ? 'سانتی‌متر' : 'اینچ'}</p><time dateTime={project.updated_at}>آخرین تغییر: {new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium' }).format(new Date(project.updated_at))}</time></div><div className="project-card__actions"><Link to={`/designer?project=${encodeURIComponent(project.id)}`}>بازکردن</Link><button className="danger-action" onClick={() => removeProject(project.id, project.title)}>حذف</button></div></article>)}</div></>
      : <><EmptyState title="هنوز پروژه‌ای ثبت نکرده‌ای" detail="یک بلوک بچین و بعد از ورود به حساب، آن را در دفتر ابری نگه دار." /><Link className="button button--primary centered-action" to="/designer">ساخت اولین طرح <ArrowLeft size={16} /></Link></>}
  </>
}

function NotFound() {
  return <div className="not-found"><PageIntro path="/" /><EmptyState title="این تکه هنوز به نقشه نرسیده" detail="نشانی را بررسی کن یا از صفحهٔ خانه ادامه بده." /><Link className="button button--primary centered-action" to="/">بازگشت به خانه</Link></div>
}

export default function App() {
  const location = useLocation()
  return <div className="app-shell">
    <a className="skip-link" href="#main-content">رفتن به محتوای اصلی</a>
    <Header />
    <main id="main-content" className="main-content" key={location.pathname}>
      <Routes>
        <Route path="/" element={<HomePage />} />
        <Route path="/guide" element={<GuidePage />} />
        <Route path="/designer" element={<DesignerPage />} />
        <Route path="/account" element={<AccountPage />} />
        <Route path="/admin" element={<AdminPage />} />
        <Route path="/admin/*" element={<AdminPage />} />
        <Route path="/shop" element={<><PageIntro path="/shop" /><PublicCollection kind="products" /></>} />
        <Route path="/shop/:slug" element={<ProductDetail />} />
        <Route path="/learn" element={<><PageIntro path="/learn" /><PublicCollection kind="tutorials" /></>} />
        <Route path="/learn/:slug" element={<TutorialDetail />} />
        <Route path="/courses" element={<><PageIntro path="/courses" /><PublicCollection kind="courses" /></>} />
        <Route path="/courses/:slug" element={<CourseDetail />} />
        <Route path="/cart" element={<CartPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/orders" element={<OrdersPage />} />
        <Route path="/support" element={<SupportPage />} />
        <Route path="/notifications" element={<NotificationsPage />} />
        <Route path="/projects" element={<ProjectsPage />} />
        <Route path="/about" element={<DynamicPage path="/about" />} />
        <Route path="/privacy" element={<DynamicPage path="/privacy" />} />
        <Route path="/terms" element={<DynamicPage path="/terms" />} />
        <Route path="/gallery" element={<GalleryPage />} />
        <Route path="/community" element={<CommunityPage />} />
        <Route path="/seller" element={<ListingPage path="/seller" />} />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </main>
    <footer className="site-footer"><Link className="footer-brand" to="/"><PatchworkMark className="footer-brand__mark" /> نقش‌نگار</Link><span>با احترام به تکه‌ها و قصه‌هایشان</span><Link to="/privacy">حریم خصوصی</Link></footer>
    <BottomNav />
  </div>
}
