export function PatchworkMark({ className = '' }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 120 120" role="img" aria-label="نشان چهار تکهٔ نقش‌نگار">
      <rect x="10" y="10" width="50" height="50" rx="8" fill="#71917c" />
      <rect x="60" y="10" width="50" height="50" rx="8" fill="#d8a24a" />
      <rect x="10" y="60" width="50" height="50" rx="8" fill="#d77962" />
      <rect x="60" y="60" width="50" height="50" rx="8" fill="#293d4d" />
      <path d="M60 15v90M15 60h90" fill="none" stroke="#f8f5ed" strokeWidth="2.5" strokeDasharray="4 5" />
      <rect x="10" y="10" width="100" height="100" rx="11" fill="none" stroke="#293d4d" strokeWidth="3" />
    </svg>
  )
}
