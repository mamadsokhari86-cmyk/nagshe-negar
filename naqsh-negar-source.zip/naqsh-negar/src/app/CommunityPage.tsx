import { useEffect, useMemo, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { ArrowLeft, ImagePlus, MessageCircle, RefreshCw, Send, ShieldAlert, Users, X } from 'lucide-react'
import { supabase } from '../lib/supabase'
import { normalizeChatMessage } from '../lib/chat-validation'
import { validateGalleryImage } from '../lib/gallery-validation'
import './community.css'

type Room = {
  id: string; room_type: 'topic' | 'direct' | 'course_qa'; title: string; slug: string | null
  course_id: string | null; member_status: string | null; other_display_name: string | null
  other_chat_handle: string | null; last_message: string | null; last_message_at: string | null; unread_count: number
}
type Message = {
  id: string; room_id: string; sender_id: string; sender_display_name: string; sender_chat_handle: string | null
  body: string; image_path: string | null; created_at: string; is_mine: boolean; image_url?: string
}
type DirectoryUser = { user_id: string; chat_handle: string; display_name: string }
type Report = {
  report_id: string; message_id: string; room_id: string; reporter_id: string; reason: string; description: string
  status: string; created_at: string; message_body: string; image_path: string | null; sender_id: string; sender_display_name: string
}
type Tab = 'topics' | 'direct' | 'courses' | 'reports'
type Attempt = { body: string; nonce: string; file: File | null; imagePath: string | null; prepared: boolean }

const tabLabels: Record<Tab, string> = { topics: 'اتاق‌های موضوعی', direct: 'پیام‌های خصوصی', courses: 'پرسش‌های دوره', reports: 'رسیدگی' }

function friendlyError(error: { code?: string; message?: string } | null, fallback: string) {
  const code = error?.code ?? ''
  const message = error?.message ?? ''
  if (/AUTH_REQUIRED|42501/u.test(code + message)) return 'برای این کار ابتدا وارد حساب شو یا دسترسی اتاق را بررسی کن.'
  if (/COURSE_TEACHER_NOT_ASSIGNED/u.test(message)) return 'برای این دوره هنوز مدرسی منصوب نشده است.'
  if (/COURSE_ACCESS_REQUIRED/u.test(message)) return 'برای پرسش از مدرس باید دسترسی این دوره در حسابت فعال باشد.'
  if (/MEMBER_MUTED|MEMBER_BANNED/u.test(message)) return 'ارسال پیام در این اتاق موقتاً برای حسابت محدود شده است.'
  if (/DIRECT_MESSAGE_NOT_ALLOWED|DIRECT_MESSAGE_BLOCKED/u.test(message)) return 'این کاربر دریافت پیام خصوصی را نپذیرفته یا ارتباط را بسته است.'
  if (/MESSAGE_TOO_LONG/u.test(message)) return 'پیام بیشتر از ۵۰۰۰ نویسه است.'
  if (/MESSAGE_RATE_LIMIT/u.test(message)) return 'در چند دقیقهٔ اخیر پیام‌های زیادی فرستاده‌ای؛ کمی بعد دوباره تلاش کن.'
  return fallback
}

export function CommunityPage() {
  const [searchParams, setSearchParams] = useSearchParams()
  const requestedRoom = searchParams.get('room')
  const requestedCourse = searchParams.get('course')
  const [userId, setUserId] = useState<string | null>(null)
  const [rooms, setRooms] = useState<Room[]>([])
  const [messages, setMessages] = useState<Message[]>([])
  const [reports, setReports] = useState<Report[]>([])
  const [directory, setDirectory] = useState<DirectoryUser[]>([])
  const [directoryQuery, setDirectoryQuery] = useState('')
  const [tab, setTab] = useState<Tab>('topics')
  const [loadingRooms, setLoadingRooms] = useState(false)
  const [loadingMessages, setLoadingMessages] = useState(false)
  const [loadingOlder, setLoadingOlder] = useState(false)
  const [notice, setNotice] = useState('')
  const [error, setError] = useState('')
  const [moderator, setModerator] = useState(false)
  const [draft, setDraft] = useState('')
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [pending, setPending] = useState<Attempt | null>(null)
  const [sending, setSending] = useState(false)
  const [questionDraft, setQuestionDraft] = useState('')
  const [asking, setAsking] = useState(false)

  const selectedRoom = useMemo(() => rooms.find((room) => room.id === requestedRoom) ?? null, [rooms, requestedRoom])
  const visibleRooms = rooms.filter((room) => tab === 'topics' ? room.room_type === 'topic' : tab === 'direct' ? room.room_type === 'direct' : room.room_type === 'course_qa')

  useEffect(() => {
    if (!supabase) return
    let alive = true
    supabase.auth.getSession().then(({ data }) => { if (alive) setUserId(data.session?.user.id ?? null) })
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setUserId(session?.user.id ?? null); setRooms([]); setMessages([]); setDirectory([]); setReports([]); setNotice(''); setError('')
    })
    return () => { alive = false; listener.subscription.unsubscribe() }
  }, [])

  useEffect(() => {
    let active = true
    if (!supabase || !userId) { setRooms([]); setModerator(false); setLoadingRooms(false); return () => { active = false } }
    setLoadingRooms(true); setError('')
    Promise.all([
      supabase.rpc('qnr_chat_list_rooms'),
      supabase.rpc('qnr_chat_my_capabilities'),
    ]).then(([roomResult, capabilityResult]) => {
      if (!active) return
      if (roomResult.error) { setError(friendlyError(roomResult.error, 'فهرست گفت‌وگوها دریافت نشد؛ اتصال را بررسی کن.')); setLoadingRooms(false); return }
      setRooms((roomResult.data ?? []) as Room[])
      const capability = Array.isArray(capabilityResult.data) ? capabilityResult.data[0] : capabilityResult.data
      setModerator(Boolean((capability as { is_moderator?: boolean } | null)?.is_moderator))
      setLoadingRooms(false)
    }).catch(() => { if (active) { setError('اتصال به گفت‌وگوها برقرار نشد.'); setLoadingRooms(false) } })
    return () => { active = false }
  }, [userId])

  useEffect(() => {
    if (!requestedCourse) return
    setTab('courses'); setQuestionDraft('')
  }, [requestedCourse])

  useEffect(() => {
    let active = true
    if (!supabase || !userId || !requestedRoom) { setMessages([]); setLoadingMessages(false); return () => { active = false } }
    setMessages([]); setLoadingMessages(true); setError('')
    async function load(before?: Message) {
      if (!supabase) return
      if (before) setLoadingOlder(true)
      const { data, error: historyError } = await supabase.rpc('qnr_chat_history', {
        p_room_id: requestedRoom,
        p_before_at: before?.created_at ?? null,
        p_before_id: before?.id ?? null,
        p_limit: 30,
      })
      if (!active) return
      if (historyError) {
        setError(friendlyError(historyError, 'پیام‌ها دریافت نشدند؛ ممکن است عضو این اتاق نباشی.'))
        setLoadingMessages(false); setLoadingOlder(false); return
      }
      const mapped = await Promise.all(((data ?? []) as Message[]).map(async (message) => {
        if (!message.image_path) return message
        const { data: signed } = await supabase!.storage.from('qnr-chat').createSignedUrl(message.image_path, 300)
        return { ...message, image_url: signed?.signedUrl }
      }))
      if (!active) return
      setMessages((previous) => before ? [...mapped, ...previous] : mapped)
      setLoadingMessages(false); setLoadingOlder(false)
    }
    void load()
    void supabase.rpc('qnr_chat_mark_read', { p_room_id: requestedRoom }).then(() => refreshRooms())
    const channel = supabase.channel(`qnr-chat-${requestedRoom}`).on('postgres_changes', {
      event: 'INSERT', schema: 'public', table: 'qnr_chat_messages', filter: `room_id=eq.${requestedRoom}`,
    }, () => { void load() }).subscribe()
    return () => { active = false; void supabase?.removeChannel(channel) }
  }, [requestedRoom, userId])

  useEffect(() => {
    if (!moderator || !supabase || tab !== 'reports') return
    supabase.rpc('qnr_chat_admin_reports').then(({ data, error: reportError }) => {
      if (reportError) setError('گزارش‌ها دریافت نشدند؛ سطح دسترسی را بررسی کن.')
      else setReports((data ?? []) as Report[])
    })
  }, [moderator, tab])

  async function refreshRooms() {
    if (!supabase || !userId) return
    const { data, error: refreshError } = await supabase.rpc('qnr_chat_list_rooms')
    if (!refreshError) setRooms((data ?? []) as Room[])
  }

  function openRoom(id: string) {
    setSearchParams({ room: id })
    setError(''); setNotice('')
  }

  async function joinTopic(room: Room) {
    if (!supabase) return
    setError(''); setNotice('')
    const { error: joinError } = await supabase.rpc('qnr_chat_join_room', { p_room_id: room.id })
    if (joinError) { setError(friendlyError(joinError, 'پیوستن به اتاق انجام نشد.')); return }
    await refreshRooms(); openRoom(room.id)
  }

  async function searchDirectory(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase) return
    setError(''); setDirectory([])
    const query = directoryQuery.trim()
    if (query.length < 2) { setError('برای جست‌وجو دست‌کم دو نویسه بنویس.'); return }
    const { data, error: searchError } = await supabase.rpc('qnr_chat_directory', { p_query: query })
    if (searchError) setError(friendlyError(searchError, 'جست‌وجوی کاربران انجام نشد.'))
    else setDirectory((data ?? []) as DirectoryUser[])
  }

  async function startDirect(person: DirectoryUser) {
    if (!supabase) return
    setError(''); setNotice('')
    const { data, error: startError } = await supabase.rpc('qnr_chat_start_direct', { p_recipient_id: person.user_id })
    if (startError || !data) { setError(friendlyError(startError, 'گفت‌وگوی خصوصی شروع نشد.')); return }
    await refreshRooms(); setTab('direct'); openRoom(data as string)
  }

  async function askCourseQuestion(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !requestedCourse) return
    const normalized = normalizeChatMessage(questionDraft)
    if (!normalized.ok) { setError(normalized.error === 'too_long' ? 'پرسش بیشتر از ۵۰۰۰ نویسه است.' : 'متن پرسش را بنویس.'); return }
    setAsking(true); setError('')
    const { data, error: askError } = await supabase.rpc('qnr_chat_ask_course_question', {
      p_course_id: requestedCourse, p_body: normalized.body, p_client_nonce: crypto.randomUUID(),
    })
    setAsking(false)
    if (askError || !data) { setError(friendlyError(askError, 'پرسش ثبت نشد.')); return }
    setQuestionDraft(''); setSearchParams({ room: data as string }); await refreshRooms()
  }

  async function reportMessage(message: Message) {
    if (!supabase || message.is_mine || !window.confirm('این پیام را برای بررسی مدیر گزارش می‌کنی؟')) return
    const { error: reportError } = await supabase.rpc('qnr_chat_report_message', { p_message_id: message.id, p_reason: 'other', p_description: '' })
    setNotice(reportError ? friendlyError(reportError, 'گزارش ثبت نشد.') : 'گزارش برای رسیدگی ارسال شد.')
  }

  async function moderateReport(report: Report, action: 'resolve' | 'mute' | 'ban') {
    if (!supabase) return
    if (action === 'mute' || action === 'ban') {
      const { error: moderateError } = await supabase.rpc('qnr_chat_moderate_member', {
        p_room_id: report.room_id, p_user_id: report.sender_id, p_action: action,
        p_duration_minutes: action === 'mute' ? 60 : 1440, p_reason: `گزارش ${report.report_id}`,
      })
      if (moderateError) { setError(friendlyError(moderateError, 'محدودیت اعمال نشد.')); return }
    }
    const { error: resolveError } = await supabase.rpc('qnr_chat_resolve_report', {
      p_report_id: report.report_id, p_status: 'resolved', p_note: action, p_hide_message: action === 'resolve',
    })
    if (resolveError) { setError('گزارش به‌روز نشد.'); return }
    setReports((current) => current.filter((item) => item.report_id !== report.report_id))
    setNotice('رسیدگی ثبت شد و در تاریخچهٔ مدیریت باقی می‌ماند.')
  }

  async function sendAttempt(attempt: Attempt) {
    if (!supabase || !selectedRoom) return
    setSending(true); setError(''); setPending(attempt)
    let current = attempt
    try {
      if (current.file && !current.prepared) {
        let path = current.imagePath
        if (!path) {
          const extension = current.file.type === 'image/jpeg' ? 'jpg' : current.file.type === 'image/png' ? 'png' : 'webp'
          path = `${selectedRoom.id}/${crypto.randomUUID()}.${extension}`
          current = { ...current, imagePath: path }
          setPending(current)
        }
        const upload = await supabase.storage.from('qnr-chat').upload(path, current.file!, { contentType: current.file!.type, cacheControl: '300', upsert: false })
        if (upload.error && !/already exists|resource exists|duplicate/iu.test(upload.error.message)) throw new Error('بارگذاری عکس انجام نشد؛ دوباره تلاش کن.')
        const { data, error: edgeError } = await supabase.functions.invoke('chat-media', {
          body: { action: 'register', room_id: selectedRoom.id, client_nonce: current.nonce, image_path: path },
        })
        if (edgeError || !data?.ok) throw new Error(data?.error ?? 'پاک‌سازی و آماده‌سازی امن عکس انجام نشد.')
        if (data.message_id) {
          setPending(null); setDraft(''); setImageFile(null); setSending(false); await refreshRooms(); return
        }
        current = { ...current, imagePath: path, prepared: true }
        setPending(current)
      }
      const { error: sendError } = await supabase.rpc('qnr_chat_send_message', {
        p_room_id: selectedRoom.id, p_body: current.body, p_client_nonce: current.nonce, p_image_path: current.imagePath,
      })
      if (sendError) throw new Error(friendlyError(sendError, 'پیام ارسال نشد؛ می‌توانی با همان شناسه دوباره تلاش کنی.'))
      setDraft(''); setImageFile(null); setPending(null); setNotice('پیامت ارسال شد.')
      await refreshRooms()
      const { data: rows } = await supabase.rpc('qnr_chat_history', { p_room_id: selectedRoom.id, p_before_at: null, p_before_id: null, p_limit: 30 })
      if (rows) setMessages(rows as Message[])
    } catch (sendError) {
      setPending(current); setError(sendError instanceof Error ? sendError.message : 'ارسال انجام نشد؛ دوباره تلاش کن.')
    } finally { setSending(false) }
  }

  async function chooseImage(file: File | null) {
    setImageFile(null); setError('')
    if (!file) return
    const result = await validateGalleryImage(file)
    if (!result.ok) {
      setError(result.error === 'too_large' ? 'عکس کمی بزرگ است؛ لطفاً نسخه‌ای زیر ۱۰ مگابایت انتخاب کن.' : 'فقط عکس JPEG، PNG یا WebP معتبر پذیرفته می‌شود.')
      return
    }
    setImageFile(file)
  }

  function submitMessage(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (pending) return
    const normalized = normalizeChatMessage(draft)
    if (normalized.ok) { void sendAttempt({ body: normalized.body, nonce: crypto.randomUUID(), file: imageFile, imagePath: null, prepared: false }); return }
    if (imageFile && normalized.error === 'empty') { void sendAttempt({ body: '', nonce: crypto.randomUUID(), file: imageFile, imagePath: null, prepared: false }); return }
    setError(normalized.error === 'too_long' ? 'پیام بیشتر از ۵۰۰۰ نویسه است.' : 'متن پیام را بنویس یا یک عکس پیوست کن.')
  }

  async function cancelPending() {
    if (!supabase || !pending) return
    if (pending.imagePath && selectedRoom) {
      await supabase.functions.invoke('chat-media', { body: { action: 'discard', room_id: selectedRoom.id, image_path: pending.imagePath } })
    }
    setPending(null); setError('ارسال لغو شد؛ متن برای ویرایش باقی ماند.')
  }

  async function loadOlder() {
    if (!supabase || !selectedRoom || !messages.length || loadingOlder) return
    setLoadingOlder(true)
    const oldest = messages[0]
    const { data, error: olderError } = await supabase.rpc('qnr_chat_history', {
      p_room_id: selectedRoom.id, p_before_at: oldest.created_at, p_before_id: oldest.id, p_limit: 30,
    })
    setLoadingOlder(false)
    if (olderError) setError('پیام‌های پیشین دریافت نشدند.')
    else if (data?.length) setMessages((previous) => [...(data as Message[]), ...previous])
  }

  if (!supabase) return <main className="community-page"><header className="community-heading"><span className="eyebrow">محفل نقش‌نگار</span><h1>گفت‌وگو و هم‌فکری</h1><p>برای دیدن اتاق‌های واقعی، اتصال سرور باید فعال باشد.</p></header><div className="community-empty">اتصال سرور تنظیم نشده است.</div></main>

  return <main className="community-page">
    <header className="community-heading"><span className="eyebrow">محفل نقش‌نگار</span><h1>تکه‌دوزها کنار هم</h1><p>تجربه‌ها، پرسش‌های دوخت و گفت‌وگوهای دوره را در فضایی امن دنبال کن.</p></header>
    {!userId ? <section className="community-signin"><Users size={25} /><h2>برای ورود به گفت‌وگو وارد حساب شو</h2><p>پیام‌ها به حساب واقعی فرستنده وصل‌اند و هیچ گفت‌وگوی نمونه‌ای نمایش داده نمی‌شود.</p><Link className="button button--primary" to="/account">ورود امن <ArrowLeft size={16} /></Link></section> : <>
      <nav className="community-tabs" aria-label="بخش‌های گفت‌وگو">
        {(Object.keys(tabLabels) as Tab[]).filter((item) => item !== 'reports' || moderator).map((item) => <button key={item} className={tab === item ? 'is-active' : ''} type="button" onClick={() => { setTab(item); setError('') }}>{tabLabels[item]}</button>)}
      </nav>
      {requestedCourse && <form className="course-question-card" onSubmit={askCourseQuestion}><div><span className="eyebrow">پرسش خصوصی از مدرس</span><h2>دربارهٔ این دوره چه می‌خواهی بدانی؟</h2><p>دسترسی و مدرس دوره پیش از ثبت پرسش روی سرور بررسی می‌شوند.</p></div><textarea rows={3} maxLength={5000} value={questionDraft} onChange={(event) => setQuestionDraft(event.target.value)} placeholder="پرسشت را روشن و کوتاه بنویس…" /><div className="community-actions"><button className="button button--primary" disabled={asking}>{asking ? 'در حال ثبت…' : 'ارسال پرسش'}</button><button className="text-button" type="button" onClick={() => setSearchParams({})}>بستن</button></div></form>}
      {tab === 'direct' && <section className="directory-card"><form onSubmit={searchDirectory}><label htmlFor="chat-directory">پیدا کردن هنرجو</label><div className="directory-input"><input id="chat-directory" value={directoryQuery} onChange={(event) => setDirectoryQuery(event.target.value)} placeholder="نام یا شناسهٔ کاربری" /><button className="button button--primary" type="submit">جست‌وجو</button></div><small>فقط کسانی نمایش داده می‌شوند که دریافت پیام خصوصی را روشن کرده‌اند؛ شماره و ایمیل آن‌ها پنهان می‌ماند.</small></form>{directory.length > 0 && <ul className="directory-results">{directory.map((person) => <li key={person.user_id}><span><strong>{person.display_name || person.chat_handle}</strong><small dir="ltr">@{person.chat_handle}</small></span><button className="button button--secondary" type="button" onClick={() => void startDirect(person)}>شروع گفت‌وگو</button></li>)}</ul>}{directoryQuery.length >= 2 && directory.length === 0 && <p className="community-muted">اگر نتیجه‌ای نیست، کاربری با این نام پیام خصوصی را فعال نکرده است.</p>}</section>}
      {error && <p className="community-alert" role="alert">{error}</p>}{notice && <p className="community-notice" role="status">{notice}</p>}
      {tab === 'reports' && moderator ? <section className="reports-list"><div className="reports-heading"><ShieldAlert size={20} /><h2>گزارش‌های باز</h2><button type="button" className="text-button" onClick={() => setTab('reports')}><RefreshCw size={15} /> تازه‌سازی</button></div>{reports.length ? reports.map((report) => <article className="report-card" key={report.report_id}><p><strong>{report.sender_display_name}</strong> · {report.reason}</p><blockquote>{report.message_body || 'پیام تصویری'}</blockquote><small>گزارش ثبت‌شده در {new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium', timeStyle: 'short' }).format(new Date(report.created_at))}</small><div className="community-actions"><button className="button button--secondary" onClick={() => void moderateReport(report, 'mute')}>بی‌صدا برای یک ساعت</button><button className="button button--secondary" onClick={() => void moderateReport(report, 'ban')}>محدود برای یک روز</button><button className="button button--primary" onClick={() => void moderateReport(report, 'resolve')}>پنهان‌کردن و بستن گزارش</button></div></article>) : <div className="community-empty">گزارش بازی وجود ندارد.</div>}</section> : <div className="community-layout">
        <aside className="room-list" aria-label={tabLabels[tab]}>{loadingRooms ? <p className="community-muted">در حال دریافت اتاق‌ها…</p> : visibleRooms.length ? visibleRooms.map((room) => <article key={room.id} className={`room-card ${requestedRoom === room.id ? 'is-selected' : ''}`}><button type="button" className="room-card__open" onClick={() => room.room_type === 'topic' && !room.member_status ? void joinTopic(room) : openRoom(room.id)}><span className="room-card__icon"><MessageCircle size={17} /></span><span className="room-card__copy"><strong>{room.title}</strong><small>{room.last_message ?? (room.room_type === 'topic' ? 'اتاق موضوعی؛ برای پیوستن باز کن' : 'هنوز پیامی ثبت نشده است')}</small></span>{room.unread_count > 0 && <b className="room-unread">{new Intl.NumberFormat('fa-IR').format(room.unread_count)}</b>}</button>{room.room_type === 'topic' && !room.member_status && <span className="room-card__join">برای ورود به اتاق بزن</span>}</article>) : <div className="community-empty">هنوز گفت‌وگویی در این بخش نیست.</div>}</aside>
        <section className="chat-panel">{!selectedRoom ? <div className="chat-empty"><MessageCircle size={32} /><h2>یک گفت‌وگو را انتخاب کن</h2><p>اتاق‌های موضوعی از سرور خوانده می‌شوند؛ عضو شو و تجربه‌ات را به اشتراک بگذار.</p></div> : <>
          <header className="chat-panel__header"><div><span className="eyebrow">{selectedRoom.room_type === 'topic' ? 'اتاق موضوعی' : selectedRoom.room_type === 'direct' ? 'گفت‌وگوی خصوصی' : 'پرسش دوره'}</span><h2>{selectedRoom.title}</h2>{selectedRoom.other_chat_handle && <small dir="ltr">@{selectedRoom.other_chat_handle}</small>}</div>{selectedRoom.member_status === 'muted' && <span className="muted-badge">ارسال پیام موقتاً بسته است</span>}</header>
          <div className="chat-history" aria-live="polite">{loadingMessages ? <p className="community-muted">در حال دریافت پیام‌ها…</p> : <>
            {messages.length >= 30 && <button className="load-older" type="button" onClick={() => void loadOlder()} disabled={loadingOlder}>{loadingOlder ? 'در حال دریافت…' : 'پیام‌های پیشین'}</button>}
            {messages.length === 0 && <div className="chat-empty chat-empty--small"><p>این گفت‌وگو هنوز پیامی ندارد. تو شروع کن.</p></div>}
            {messages.map((message) => <article key={message.id} className={`chat-message ${message.is_mine ? 'is-mine' : ''}`}><div className="chat-message__meta"><strong>{message.is_mine ? 'تو' : message.sender_display_name}</strong>{message.sender_chat_handle && !message.is_mine && <small dir="ltr">@{message.sender_chat_handle}</small>}<time dateTime={message.created_at}>{new Intl.DateTimeFormat('fa-IR', { hour: '2-digit', minute: '2-digit' }).format(new Date(message.created_at))}</time></div>{message.body && <p>{message.body}</p>}{message.image_url && <a href={message.image_url} target="_blank" rel="noreferrer"><img src={message.image_url} alt="عکس پیوست پیام" loading="lazy" /></a>}{!message.is_mine && <button type="button" className="message-report" onClick={() => void reportMessage(message)}>گزارش پیام</button>}</article>)}
          </>}</div>
          {selectedRoom.member_status === 'active' || selectedRoom.member_status === 'muted' ? <form className="chat-composer" onSubmit={submitMessage}>
            {imageFile && <div className="image-preview"><span><ImagePlus size={16} />{imageFile.name} · {new Intl.NumberFormat('fa-IR').format(Math.ceil(imageFile.size / 1024))} کیلوبایت</span><button type="button" aria-label="لغو پیوست عکس" onClick={() => setImageFile(null)}><X size={16} /></button></div>}
            <textarea rows={2} maxLength={5000} value={draft} onChange={(event) => setDraft(event.target.value)} placeholder="پیام یا پرسشت را بنویس…" disabled={sending || Boolean(pending) || selectedRoom.member_status === 'muted'} />
            <div className="composer-actions"><label className="attach-image"><ImagePlus size={17} /><span>افزودن عکس</span><input type="file" accept="image/jpeg,image/png,image/webp" capture="environment" onChange={(event) => { void chooseImage(event.target.files?.[0] ?? null); event.currentTarget.value = '' }} disabled={sending || Boolean(pending) || selectedRoom.member_status === 'muted'} /></label><span className="character-count">{new Intl.NumberFormat('fa-IR').format([...draft].length)} / ۵۰۰۰</span><button className="button button--primary" type="submit" disabled={sending || Boolean(pending) || selectedRoom.member_status === 'muted'}>{sending ? 'در حال ارسال…' : 'ارسال'} <Send size={15} /></button></div>
            {pending && <div className="retry-row"><span>ارسال قبلی کامل نشد؛ همان پیام بدون تکرار دوباره فرستاده می‌شود.</span><button type="button" className="text-button" onClick={() => void sendAttempt(pending)} disabled={sending}><RefreshCw size={14} /> تلاش دوباره</button><button type="button" className="text-button" onClick={() => void cancelPending()}>لغو</button></div>}
          </form> : <div className="chat-locked">برای دیدن و فرستادن پیام باید عضو فعال این اتاق باشی.</div>}
        </>}</section>
      </div>}
    </>}
  </main>
}
