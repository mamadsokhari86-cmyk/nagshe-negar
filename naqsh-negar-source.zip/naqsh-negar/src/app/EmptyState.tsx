import { Flower2 } from 'lucide-react'

export function EmptyState({ title, detail }: { title: string; detail: string }) {
  return (
    <section className="empty-state" aria-live="polite">
      <span className="empty-state__icon"><Flower2 size={25} strokeWidth={1.5} /></span>
      <h2>{title}</h2>
      <p>{detail}</p>
    </section>
  )
}
