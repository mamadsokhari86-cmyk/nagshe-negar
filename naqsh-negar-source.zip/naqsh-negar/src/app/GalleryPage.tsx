import { useEffect, useMemo, useState, type FormEvent } from 'react'
import { ArrowLeft, Camera, Check, Flag, ImagePlus, LoaderCircle, LockKeyhole, ShieldCheck, Trash2, UploadCloud } from 'lucide-react'
import { Link } from 'react-router-dom'
import { EmptyState } from './EmptyState'
import { PatchworkMark } from './PatchworkMark'
import './gallery.css'
import { supabase, supabaseConfigured } from '../lib/supabase'
import { GALLERY_IMAGE_LIMIT, normalizeGalleryText, validateGalleryImage } from '../lib/gallery-validation'

type Visibility = 'private' | 'public'
type GalleryPost = {
  id: string
  title: string
  caption: string
  topic: string
  use_case: string
  skill_level: string
  color_family: string[]
  image_path: string
  created_at: string
  image_url?: string
}
type MyPost = GalleryPost & { visibility: Visibility; review_status: string; moderation_note: string | null; updated_at: string }
type AdminPost = GalleryPost & { owner_id: string }
type GalleryReport = { id: string; post_id: string; post_title: string; reason: string; description: string; status: string; created_at: string; resolution_note: string | null }

const topicOptions = [['pattern', 'نقش'], ['color', 'رنگ'], ['materials', 'پارچه و ابزار'], ['technique', 'تکنیک دوخت'], ['project', 'پروژه'], ['other', 'سایر']] as const
const useOptions = [['quilt', 'لحاف'], ['home', 'خانه'], ['accessory', 'اکسسوری'], ['clothing', 'پوشاک'], ['other', 'سایر']] as const
const levelOptions = [['beginner', 'تازه‌کار'], ['intermediate', 'میانه'], ['advanced', 'پیشرفته']] as const
const colorOptions = [['red', 'قرمز'], ['orange', 'نارنجی'], ['yellow', 'زرد'], ['green', 'سبز'], ['blue', 'آبی'], ['purple', 'بنفش'], ['neutral', 'خنثی'], ['mixed', 'ترکیبی']] as const
const reportOptions = [['copyright', 'حق نشر'], ['privacy', 'حریم خصوصی'], ['spam', 'هرزنامه'], ['harassment', 'آزار'], ['other', 'سایر']] as const
const reviewLabels: Record<string, string> = { private: 'پیش‌نویس خصوصی', pending: 'در انتظار بازبینی', approved: 'منتشرشده', rejected: 'پذیرفته نشد', hidden: 'نمایش متوقف شد' }

function labelFor(options: readonly (readonly [string, string])[], value: string) {
  return options.find(([key]) => key === value)?.[1] ?? value
}

async function withImageUrl<T extends { image_path: string }>(post: T): Promise<T & { image_url?: string }> {
  if (!supabase) return post
  const { data } = await supabase.storage.from('qnr-gallery').createSignedUrl(post.image_path, 300)
  return { ...post, image_url: data?.signedUrl }
}

function PageHeading() {
  return <div className="page-intro"><div><span className="eyebrow">نقش‌نگار <span aria-hidden="true">/</span> گالری</span><h1>گالری دست‌سازه‌ها</h1><p>آثاری که سازنده اجازهٔ نمایش داده و مدیر بازبینی کرده است.</p></div><PatchworkMark className="page-intro__mark" /></div>
}

function PostCard({ post, onReport }: { post: GalleryPost; onReport: (post: GalleryPost) => void }) {
  return <article className="gallery-card">
    {post.image_url ? <img className="gallery-card__image" src={post.image_url} alt={`تصویر اثر ${post.title}`} loading="lazy" /> : <div className="gallery-card__image gallery-card__image--empty"><Camera size={31} /><span>تصویر بارگذاری نشد</span></div>}
    <div className="gallery-card__body">
      <div className="gallery-card__eyebrow"><span>{labelFor(topicOptions, post.topic)}</span><span>{labelFor(levelOptions, post.skill_level)}</span></div>
      <h2>{post.title}</h2>
      {post.caption && <p>{post.caption}</p>}
      <div className="gallery-card__tags"><span>{labelFor(useOptions, post.use_case)}</span>{post.color_family.map((color) => <span key={color}>{labelFor(colorOptions, color)}</span>)}</div>
      <div className="gallery-card__footer"><time dateTime={post.created_at}>{new Intl.DateTimeFormat('fa-IR', { dateStyle: 'medium' }).format(new Date(post.created_at))}</time><button type="button" className="text-button gallery-report" onClick={() => onReport(post)}><Flag size={14} /> گزارش</button></div>
    </div>
  </article>
}

function GalleryMineCard({ post, busy, onDelete }: { post: MyPost; busy: boolean; onDelete: (id: string) => void }) {
  return <article className="gallery-mine-card">
    {post.image_url ? <img src={post.image_url} alt={`تصویر اثر ${post.title}`} loading="lazy" /> : <div className="gallery-mine-card__placeholder"><Camera size={23} /></div>}
    <div className="gallery-mine-card__copy"><strong>{post.title}</strong><span className={`gallery-status gallery-status--${post.review_status}`}>{reviewLabels[post.review_status] ?? post.review_status}</span>{post.moderation_note && <small>{post.moderation_note}</small>}</div>
    <button type="button" className="icon-button gallery-delete" aria-label={`حذف ${post.title}`} disabled={busy} onClick={() => onDelete(post.id)}><Trash2 size={17} /></button>
  </article>
}

export function GalleryPage() {
  const [userId, setUserId] = useState<string | null>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const [loading, setLoading] = useState(true)
  const [loadError, setLoadError] = useState(false)
  const [publicPosts, setPublicPosts] = useState<GalleryPost[]>([])
  const [myPosts, setMyPosts] = useState<MyPost[]>([])
  const [adminPosts, setAdminPosts] = useState<AdminPost[]>([])
  const [reports, setReports] = useState<GalleryReport[]>([])
  const [tab, setTab] = useState<'feed' | 'mine' | 'moderation'>('feed')
  const [refresh, setRefresh] = useState(0)
  const [topicFilter, setTopicFilter] = useState('all')
  const [useFilter, setUseFilter] = useState('all')
  const [levelFilter, setLevelFilter] = useState('all')
  const [colorFilter, setColorFilter] = useState('all')
  const [title, setTitle] = useState('')
  const [caption, setCaption] = useState('')
  const [topic, setTopic] = useState('other')
  const [useCase, setUseCase] = useState('other')
  const [level, setLevel] = useState('beginner')
  const [selectedColors, setSelectedColors] = useState<string[]>([])
  const [visibility, setVisibility] = useState<Visibility>('private')
  const [consent, setConsent] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [preview, setPreview] = useState('')
  const [submitting, setSubmitting] = useState(false)
  const [busyId, setBusyId] = useState('')
  const [notice, setNotice] = useState('')
  const [reporting, setReporting] = useState<GalleryPost | null>(null)
  const [reportReason, setReportReason] = useState('privacy')
  const [reportText, setReportText] = useState('')

  useEffect(() => {
    if (!supabase) return
    supabase.auth.getSession().then(({ data }) => setUserId(data.session?.user.id ?? null))
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      const id = session?.user.id ?? null
      setUserId(id)
      if (!id) setTab('feed')
    })
    return () => listener.subscription.unsubscribe()
  }, [])

  useEffect(() => {
    if (!file) { setPreview(''); return }
    const url = URL.createObjectURL(file)
    setPreview(url)
    return () => URL.revokeObjectURL(url)
  }, [file])

  useEffect(() => {
    let active = true
    async function load() {
      if (!supabase) { setLoading(false); return }
      setLoading(true); setLoadError(false)
      const { data: publicData, error: publicError } = await supabase.from('qnr_public_gallery_posts')
        .select('id,title,caption,topic,use_case,skill_level,color_family,image_path,created_at')
        .order('created_at', { ascending: false }).limit(60)
      if (publicError) {
        if (active) { setLoadError(true); setLoading(false) }
        return
      }
      const publicWithImages = await Promise.all(((publicData ?? []) as GalleryPost[]).map(withImageUrl))
      let ownWithImages: MyPost[] = []
      let admin = false
      let queue: AdminPost[] = []
      let reportQueue: GalleryReport[] = []
      if (userId) {
        const [{ data: ownData, error: ownError }, { data: roleData }] = await Promise.all([
          supabase.rpc('qnr_my_gallery_posts'),
          supabase.from('qnr_user_roles').select('role').eq('user_id', userId).eq('role', 'admin').maybeSingle(),
        ])
        if (ownError) {
          if (active) { setLoadError(true); setLoading(false) }
          return
        }
        admin = Boolean(roleData)
        ownWithImages = await Promise.all(((ownData ?? []) as MyPost[]).map(withImageUrl))
        if (admin) {
          const [{ data: queueData, error: queueError }, { data: reportsData, error: reportsError }] = await Promise.all([
            supabase.rpc('qnr_admin_gallery_queue'),
            supabase.rpc('qnr_admin_gallery_reports'),
          ])
          if (queueError || reportsError) {
            if (active) { setLoadError(true); setLoading(false) }
            return
          }
          queue = await Promise.all(((queueData ?? []) as AdminPost[]).map(withImageUrl))
          reportQueue = (reportsData ?? []) as GalleryReport[]
        }
      }
      if (active) {
        setPublicPosts(publicWithImages); setMyPosts(ownWithImages); setIsAdmin(admin)
        setAdminPosts(queue); setReports(reportQueue); setLoading(false)
      }
    }
    void load().catch(() => { if (active) { setLoadError(true); setLoading(false) } })
    return () => { active = false }
  }, [userId, refresh])

  const filteredPosts = useMemo(() => publicPosts.filter((post) =>
    (topicFilter === 'all' || post.topic === topicFilter)
    && (useFilter === 'all' || post.use_case === useFilter)
    && (levelFilter === 'all' || post.skill_level === levelFilter)
    && (colorFilter === 'all' || post.color_family.includes(colorFilter))),
  [publicPosts, topicFilter, useFilter, levelFilter, colorFilter])

  function resetForm() {
    setTitle(''); setCaption(''); setTopic('other'); setUseCase('other'); setLevel('beginner')
    setSelectedColors([]); setVisibility('private'); setConsent(false); setFile(null)
  }

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !userId || !file || submitting) return
    const text = normalizeGalleryText(title, caption)
    if (!text.ok) { setNotice(text.error === 'title_length' ? 'عنوان باید بین ۲ تا ۱۰۰ نویسه باشد.' : 'توضیح بیش از اندازه بلند است.'); return }
    if (visibility === 'public' && !consent) { setNotice('برای درخواست انتشار عمومی باید اجازهٔ نمایش را تأیید کنی.'); return }
    setSubmitting(true); setNotice('')
    let uploadedPath = ''
    try {
      const checked = await validateGalleryImage(file)
      if (!checked.ok) {
        const detail = checked.error === 'too_large' ? 'حجم عکس باید حداکثر ۱۰ مگابایت باشد.' : checked.error === 'unsupported_type' ? 'فقط عکس JPEG، PNG یا WebP پذیرفته می‌شود.' : 'محتوای فایل با نوع عکس هم‌خوانی ندارد.'
        setNotice(detail); return
      }
      uploadedPath = `${crypto.randomUUID()}.${checked.extension}`
      const { error: uploadError } = await supabase.storage.from('qnr-gallery').upload(uploadedPath, file, { contentType: checked.mimeType, cacheControl: '300', upsert: false })
      if (uploadError) throw new Error('بارگذاری عکس انجام نشد؛ حجم و اتصال را بررسی کن.')
      const { data, error } = await supabase.functions.invoke('gallery-manage', { body: {
        action: 'register', image_path: uploadedPath, title: text.title, caption: text.caption,
        topic, use_case: useCase, skill_level: level, color_family: selectedColors,
        visibility, publication_consent: visibility === 'public' && consent,
      } })
      if (error || data?.error) throw new Error(data?.error || 'ثبت اثر انجام نشد؛ دوباره تلاش کن.')
      setNotice(visibility === 'public' ? 'اثر به صف بازبینی رفت؛ پس از تأیید مدیر در گالری دیده می‌شود.' : 'پیش‌نویس خصوصی ذخیره شد و فقط خودت آن را می‌بینی.')
      resetForm(); setRefresh((value) => value + 1)
    } catch (error) {
      if (uploadedPath) await supabase.functions.invoke('gallery-manage', { body: { action: 'discard', image_path: uploadedPath } })
      setNotice(error instanceof Error ? error.message : 'ثبت اثر انجام نشد؛ دوباره تلاش کن.')
    } finally { setSubmitting(false) }
  }

  async function deletePost(id: string) {
    if (!supabase || !window.confirm('این اثر از گالری برداشته و از حساب حذف شود؟')) return
    setBusyId(id); setNotice('')
    const { data, error } = await supabase.functions.invoke('gallery-manage', { body: { action: 'delete', post_id: id } })
    if (error || data?.error) setNotice(data?.error || 'حذف اثر انجام نشد؛ دوباره تلاش کن.')
    else { setNotice('اثر حذف شد.'); setRefresh((value) => value + 1) }
    setBusyId('')
  }

  async function sendReport(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    if (!supabase || !reporting) return
    setBusyId(reporting.id); setNotice('')
    const { error } = await supabase.rpc('qnr_report_gallery_post', { p_post_id: reporting.id, p_reason: reportReason, p_description: reportText.trim() })
    if (error) setNotice(error.code === '23505' ? 'برای این اثر قبلاً گزارش فرستاده‌ای.' : 'گزارش ثبت نشد؛ دوباره تلاش کن.')
    else { setNotice('گزارش برای بررسی ثبت شد.'); setReporting(null); setReportText(''); setRefresh((value) => value + 1) }
    setBusyId('')
  }

  async function moderate(post: AdminPost, action: 'approve' | 'reject' | 'hide') {
    if (!supabase) return
    const note = window.prompt(action === 'approve' ? 'یادداشت مدیر (اختیاری)' : 'دلیل کوتاه برای ثبت در تاریخچه (اختیاری)', '')
    if (note === null) return
    setBusyId(post.id); setNotice('')
    const { error } = await supabase.rpc('qnr_moderate_gallery_post', { p_post_id: post.id, p_action: action, p_note: note.slice(0, 500) })
    if (error) setNotice('تغییر وضعیت ثبت نشد؛ دسترسی مدیر یا وضعیت اثر را بررسی کن.')
    else { setNotice('بررسی ثبت شد.'); setRefresh((value) => value + 1) }
    setBusyId('')
  }

  async function resolveReport(report: GalleryReport, status: 'reviewed' | 'dismissed') {
    if (!supabase) return
    const note = window.prompt(status === 'reviewed' ? 'یادداشت رسیدگی (اختیاری)' : 'یادداشت بستن گزارش (اختیاری)', '')
    if (note === null) return
    setBusyId(report.id)
    const { error } = await supabase.rpc('qnr_admin_resolve_gallery_report', { p_report_id: report.id, p_status: status, p_note: note.slice(0, 500) })
    setNotice(error ? 'رسیدگی به گزارش ثبت نشد.' : 'گزارش به‌روز شد.')
    setBusyId(''); if (!error) setRefresh((value) => value + 1)
  }

  const formatFileError = file ? `${file.name} · ${new Intl.NumberFormat('fa-IR', { maximumFractionDigits: 1 }).format(file.size / (1024 * 1024))} مگابایت` : ''

  return <>
    <PageHeading />
    <section className="gallery-policy"><LockKeyhole size={18} /><p>آثار دیگران را نمی‌بینند مگر پس از رضایت تو و تأیید مدیر. نام و شمارهٔ حسابت نمایش داده نمی‌شود؛ بازدیدکنندگان می‌توانند از تصویر عمومی نسخه بردارند. حذف اثر، نمایش آن در برنامه را متوقف می‌کند.</p></section>
    {!supabaseConfigured ? <EmptyState title="اتصال سرور تنظیم نشده" detail="برای دیدن آثار واقعی و ثبت اثر، اتصال امن سرور باید آماده باشد." /> : loadError ? <section className="gallery-load-error"><EmptyState title="گالری بارگذاری نشد" detail="اتصال را بررسی و دوباره تلاش کن." /><button className="button button--secondary" onClick={() => setRefresh((value) => value + 1)}>تلاش دوباره</button></section> : <>
      {userId && <nav className="gallery-tabs" aria-label="بخش گالری">
        <button className={tab === 'feed' ? 'is-selected' : ''} onClick={() => setTab('feed')}>آثار عمومی</button>
        <button className={tab === 'mine' ? 'is-selected' : ''} onClick={() => setTab('mine')}>آثار من</button>
        {isAdmin && <button className={tab === 'moderation' ? 'is-selected' : ''} onClick={() => setTab('moderation')}><ShieldCheck size={15} /> بازبینی مدیر</button>}
      </nav>}

      {tab === 'feed' && <>
        <section className="gallery-toolbar"><div><span className="eyebrow">پارچه‌ها و قصه‌های واقعی</span><h2>الهام بگیر، با اجازهٔ سازنده</h2></div><span className="gallery-real-count">نمایش {new Intl.NumberFormat('fa-IR').format(filteredPosts.length)} اثر</span></section>
        <div className="gallery-filters" aria-label="فیلتر آثار">
          <label>موضوع<select value={topicFilter} onChange={(event) => setTopicFilter(event.target.value)}><option value="all">همهٔ موضوع‌ها</option>{topicOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label>
          <label>کاربرد<select value={useFilter} onChange={(event) => setUseFilter(event.target.value)}><option value="all">همهٔ کاربردها</option>{useOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label>
          <label>سطح<select value={levelFilter} onChange={(event) => setLevelFilter(event.target.value)}><option value="all">همهٔ سطح‌ها</option>{levelOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label>
          <label>رنگ<select value={colorFilter} onChange={(event) => setColorFilter(event.target.value)}><option value="all">همهٔ رنگ‌ها</option>{colorOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label>
        </div>
        {loading ? <p className="collection-state" role="status">در حال دریافت آثار…</p> : filteredPosts.length ? <div className="gallery-grid">{filteredPosts.map((post) => <PostCard key={post.id} post={post} onReport={(item) => { if (!userId) { setNotice('برای گزارش این اثر ابتدا وارد حساب شو.'); return } setReporting(item); setNotice('') }} />)}</div> : <EmptyState title="هنوز اثری منتشر نشده" detail="وقتی سازنده‌ای اجازه دهد و مدیر اثر را تأیید کند، اینجا نمایش داده می‌شود." />}
        {!userId && <div className="gallery-signin"><p>برای ثبت اثر یا گزارش، وارد حساب شو.</p><Link className="button button--secondary" to="/account">ورود به حساب <ArrowLeft size={16} /></Link></div>}
        {userId && <section className="gallery-submit">
          <div className="gallery-submit__heading"><span className="gallery-submit__icon"><ImagePlus size={20} /></span><div><span className="eyebrow">اثر تازه</span><h2>داستان کارت را ثبت کن</h2><p>پیش‌نویس خصوصی می‌ماند؛ انتشار عمومی به اجازهٔ جداگانه و بازبینی نیاز دارد.</p></div></div>
          <form className="gallery-form" onSubmit={submit}>
            <div className="gallery-form__grid">
              <label>عنوان اثر<input required minLength={2} maxLength={100} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="مثلاً باغچهٔ صبحگاهی" /></label>
              <label>موضوع<select value={topic} onChange={(event) => setTopic(event.target.value)}>{topicOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label>
              <label>کاربرد<select value={useCase} onChange={(event) => setUseCase(event.target.value)}>{useOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label>
              <label>سطح تجربه<select value={level} onChange={(event) => setLevel(event.target.value)}>{levelOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label>
            </div>
            <label>شرح کوتاه<textarea rows={3} maxLength={1000} value={caption} onChange={(event) => setCaption(event.target.value)} placeholder="از انتخاب رنگ یا دوخت این اثر بگو" /></label>
            <fieldset className="gallery-colors"><legend>رنگ‌های اصلی (حداکثر ۴)</legend><div>{colorOptions.map(([key, value]) => <label key={key}><input type="checkbox" checked={selectedColors.includes(key)} disabled={!selectedColors.includes(key) && selectedColors.length >= 4} onChange={(event) => setSelectedColors((current) => event.target.checked ? [...current, key] : current.filter((item) => item !== key))} /><span>{value}</span></label>)}</div></fieldset>
            <label className="gallery-upload">{preview ? <img src={preview} alt="پیش‌نمایش تصویر انتخاب‌شده" /> : <span className="gallery-upload__placeholder"><UploadCloud size={23} /><strong>انتخاب عکس اثر</strong><small>JPEG، PNG یا WebP · حداکثر ۱۰ مگابایت</small></span>}<input type="file" accept="image/jpeg,image/png,image/webp" onChange={(event) => setFile(event.target.files?.[0] ?? null)} />{file && <span className="gallery-upload__filename">{formatFileError}</span>}</label>
            <div className="gallery-visibility"><span>نحوهٔ نگهداری</span><label><input type="radio" name="gallery-visibility" checked={visibility === 'private'} onChange={() => { setVisibility('private'); setConsent(false) }} />پیش‌نویس خصوصی</label><label><input type="radio" name="gallery-visibility" checked={visibility === 'public'} onChange={() => setVisibility('public')} />درخواست انتشار عمومی</label></div>
            {visibility === 'public' && <label className="gallery-consent"><input type="checkbox" checked={consent} onChange={(event) => setConsent(event.target.checked)} /><span>اجازه می‌دهم پس از تأیید مدیر، عنوان، توضیح، دسته‌بندی و عکس این اثر برای همه نمایش داده شود. نام و شمارهٔ تماس من نمایش داده نمی‌شود و می‌دانم دیگران می‌توانند تصویر منتشرشده را ذخیره کنند.</span></label>}
            <div className="gallery-form__footer"><span><LockKeyhole size={15} />فایل تا زمان تأیید خصوصی است.</span><button className="button button--primary" type="submit" disabled={submitting || !file || (visibility === 'public' && !consent)}>{submitting ? <><LoaderCircle className="gallery-spin" size={16} /> در حال ثبت…</> : visibility === 'public' ? 'فرستادن برای بازبینی' : 'ذخیرهٔ خصوصی'} <ArrowLeft size={16} /></button></div>
            {file && <small className="gallery-form__limit">حداکثر حجم مجاز: {new Intl.NumberFormat('fa-IR').format(GALLERY_IMAGE_LIMIT / 1024 / 1024)} مگابایت</small>}
          </form>
        </section>}
      </>}

      {tab === 'mine' && <section className="gallery-own"><div className="gallery-toolbar"><div><span className="eyebrow">خصوصی برای خودت</span><h2>آثار من</h2></div><button className="text-link" onClick={() => setTab('feed')}>ثبت اثر تازه <ArrowLeft size={15} /></button></div>{loading ? <p className="collection-state">در حال دریافت…</p> : myPosts.length ? <div className="gallery-mine-list">{myPosts.map((post) => <GalleryMineCard key={post.id} post={post} busy={busyId === post.id} onDelete={(id) => void deletePost(id)} />)}</div> : <EmptyState title="هنوز اثری ثبت نکرده‌ای" detail="پیش‌نویس خصوصی یا درخواست انتشار را از پایین صفحهٔ آثار عمومی شروع کن." />}</section>}

      {tab === 'moderation' && isAdmin && <section className="gallery-moderation"><div className="gallery-toolbar"><div><span className="eyebrow">مدیریت محتوا</span><h2>صف بازبینی</h2></div><span className="gallery-real-count">{new Intl.NumberFormat('fa-IR').format(adminPosts.length)} در انتظار</span></div>{loading ? <p className="collection-state">در حال دریافت…</p> : adminPosts.length ? <div className="gallery-grid">{adminPosts.map((post) => <article className="gallery-card gallery-card--admin" key={post.id}>{post.image_url && <img className="gallery-card__image" src={post.image_url} alt={`تصویر اثر ${post.title}`} />}<div className="gallery-card__body"><h3>{post.title}</h3><p>{post.caption || 'بدون توضیح'}</p><div className="gallery-admin-actions"><button onClick={() => void moderate(post, 'approve')} disabled={busyId === post.id}><Check size={15} /> تأیید</button><button onClick={() => void moderate(post, 'reject')} disabled={busyId === post.id}>رد</button><button onClick={() => void moderate(post, 'hide')} disabled={busyId === post.id}>پنهان‌کردن</button></div></div></article>)}</div> : <EmptyState title="اثر تازه‌ای در صف نیست" detail="درخواست‌های واقعی انتشار پس از ارسال سازنده اینجا می‌آیند." />}
          <div className="gallery-report-queue"><h3><Flag size={17} /> گزارش‌های دریافت‌شده</h3>{reports.length ? reports.map((report) => <article className="gallery-report-row" key={report.id}><div><strong>{report.post_title}</strong><span>{labelFor(reportOptions, report.reason)}</span><p>{report.description || 'بدون توضیح'}</p><small className={`gallery-status ${report.status === 'open' ? 'gallery-status--pending' : ''}`}>{report.status === 'open' ? 'باز' : report.status === 'reviewed' ? 'بررسی‌شده' : 'بسته‌شده'}</small></div>{report.status === 'open' && <div><button disabled={busyId === report.id} onClick={() => void resolveReport(report, 'reviewed')}>رسیدگی شد</button><button disabled={busyId === report.id} onClick={() => void resolveReport(report, 'dismissed')}>بستن گزارش</button></div>}</article>) : <p className="gallery-no-reports">گزارشی ثبت نشده است.</p>}</div>
        </section>}
      {notice && <p className="gallery-notice" role="status">{notice}</p>}
    </>}

    {reporting && <div className="gallery-modal-backdrop" role="presentation" onMouseDown={(event) => { if (event.target === event.currentTarget) setReporting(null) }}><section className="gallery-modal" role="dialog" aria-modal="true" aria-labelledby="gallery-report-title"><h2 id="gallery-report-title">گزارش این اثر</h2><p>گزارش فقط برای تیم بازبینی نمایش داده می‌شود.</p><form onSubmit={sendReport}><label>دلیل<select value={reportReason} onChange={(event) => setReportReason(event.target.value)}>{reportOptions.map(([key, value]) => <option value={key} key={key}>{value}</option>)}</select></label><label>توضیح (اختیاری)<textarea rows={3} maxLength={500} value={reportText} onChange={(event) => setReportText(event.target.value)} /></label><div><button type="button" className="button button--secondary" onClick={() => setReporting(null)}>انصراف</button><button className="button button--primary" disabled={busyId === reporting.id}>ثبت گزارش</button></div></form></section></div>}
  </>
}
