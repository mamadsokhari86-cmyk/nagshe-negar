export { CHAT_MESSAGE_LIMIT, isChatNonce, normalizeChatMessage } from '../../supabase/functions/_shared/chat-validation.ts'
export type { ChatMessageValidation } from '../../supabase/functions/_shared/chat-validation.ts'
