export { GALLERY_IMAGE_LIMIT, normalizeGalleryText, validateGalleryImage } from '../../supabase/functions/_shared/gallery-validation.ts'
export type { GalleryImageValidation, GalleryTextResult } from '../../supabase/functions/_shared/gallery-validation.ts'
