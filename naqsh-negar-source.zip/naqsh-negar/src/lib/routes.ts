export const routeInfo = {
  '/': { title: 'خانه', description: 'هر تکه قصه‌ای دارد؛ قصهٔ بعدی را با نخ و پارچهٔ خودت بساز.' },
  '/shop': { title: 'فروشگاه', description: 'پارچه‌ها، ابزارها و بسته‌های چهل‌تکه‌دوزی' },
  '/learn': { title: 'یادگیری', description: 'آموزش‌های کوتاه برای قدم‌های کوچک و مطمئن' },
  '/courses': { title: 'دوره‌ها', description: 'مسیرهای یادگیری مرحله‌به‌مرحله' },
  '/guide': { title: 'دانشنامه', description: 'واژه‌ها، ابزارها و نکته‌های کاربردی چهل‌تکه‌دوزی' },
  '/designer': { title: 'طراح بلوک', description: 'ایده‌ات را روی شبکه بچین و مقدار پارچه را برآورد کن' },
  '/projects': { title: 'دفتر پروژه', description: 'یادداشت‌ها و طرح‌های در حال دوخت' },
  '/gallery': { title: 'گالری', description: 'آثار جامعهٔ نقش‌نگار با اجازهٔ انتشار سازندگان' },
  '/community': { title: 'گفت‌وگو', description: 'پرسش، تجربه و چالش‌های چهل‌تکه‌دوزی' },
  '/seller': { title: 'فروشندگی', description: 'آشنایی با شرایط و ثبت درخواست بررسی' },
  '/support': { title: 'پشتیبانی', description: 'راه ارتباط با تیم نقش‌نگار' },
  '/notifications': { title: 'اعلان‌ها', description: 'پاسخ‌ها و به‌روزرسانی‌های مهم حساب' },
  '/account': { title: 'حساب کاربری', description: 'ورود، پروفایل و تنظیمات حساب' },
  '/admin': { title: 'مدیریت', description: 'مدیریت محتوای منتشرشده در نقش‌نگار' },
  '/orders': { title: 'سفارش‌ها', description: 'پیگیری سفارش‌های ثبت‌شده' },
  '/cart': { title: 'سبد خرید', description: 'مرور اقلام انتخاب‌شده' },
  '/checkout': { title: 'ثبت سفارش', description: 'ثبت امن سفارش و پرداخت دستی' },
  '/privacy': { title: 'حریم خصوصی', description: 'نحوهٔ نگهداری و استفاده از داده‌های شما' },
  '/terms': { title: 'شرایط استفاده', description: 'قواعد استفاده از نقش‌نگار' },
  '/about': { title: 'دربارهٔ نقش‌نگار', description: 'خانه‌ای برای هنر چهل‌تکه‌دوزی' },
} as const

export type RoutePath = keyof typeof routeInfo
