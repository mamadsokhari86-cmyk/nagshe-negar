import { createClient } from '@supabase/supabase-js'

const url = import.meta.env.VITE_SUPABASE_URL?.trim()
const publishableKey = import.meta.env.VITE_SUPABASE_PUBLISHABLE_KEY?.trim()

export const supabaseConfigured = Boolean(url && publishableKey)
export const supabase = supabaseConfigured ? createClient(url!, publishableKey!) : null

export function backendMessage() {
  return supabaseConfigured
    ? 'اتصال برقرار است؛ محتوای منتشرشده پس از ثبت اطلاعات واقعی اینجا نمایش داده می‌شود.'
    : 'برای اتصال نقش‌نگار، آدرس سرور و کلید عمومی را در تنظیمات محیطی قرار دهید.'
}
