import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import { VitePWA } from 'vite-plugin-pwa'

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['patchwork.svg'],
      manifest: {
        name: 'نقش‌نگار | چهل‌تکه‌دوزی',
        short_name: 'نقش‌نگار',
        description: 'یادگیری، طراحی و ثبت پروژه‌های چهل‌تکه‌دوزی',
        lang: 'fa',
        dir: 'rtl',
        start_url: '/',
        scope: '/',
        display: 'standalone',
        background_color: '#f6f2e9',
        theme_color: '#f6f2e9',
        icons: [{ src: '/patchwork.svg', sizes: 'any', type: 'image/svg+xml', purpose: 'any maskable' }],
      },
      // Cache only the app shell and static build output. Authenticated API responses are never cached.
      workbox: { navigateFallback: '/index.html', globPatterns: ['**/*.{js,css,html,svg,woff2}'] },
    }),
  ],
})
