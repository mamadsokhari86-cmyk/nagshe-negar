create table public.qnr_projects (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  title text not null check (length(trim(title)) between 1 and 120),
  grid_size smallint not null check (grid_size in (3, 5, 7)),
  unit text not null check (unit in ('cm', 'in')),
  finished_size numeric(8,2) not null check (finished_size > 0),
  seam_allowance numeric(6,3) not null default 0.25 check (seam_allowance >= 0),
  fabric_width numeric(8,2) not null check (fabric_width > 0),
  cells jsonb not null default '{}'::jsonb check (jsonb_typeof(cells) in ('object', 'array')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create index qnr_projects_user_updated_idx on public.qnr_projects (user_id, updated_at desc);
create trigger qnr_projects_touch_updated_at before update on public.qnr_projects
  for each row execute function public.qnr_touch_updated_at();

alter table public.qnr_projects enable row level security;
create policy qnr_projects_select_own on public.qnr_projects for select to authenticated using (user_id = auth.uid());
create policy qnr_projects_insert_own on public.qnr_projects for insert to authenticated with check (user_id = auth.uid());
create policy qnr_projects_update_own on public.qnr_projects for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy qnr_projects_delete_own on public.qnr_projects for delete to authenticated using (user_id = auth.uid());

revoke all on public.qnr_projects from anon, authenticated;
grant select, insert, update, delete on public.qnr_projects to authenticated;
comment on table public.qnr_projects is 'Private quilting designs owned by each signed-in user.';
