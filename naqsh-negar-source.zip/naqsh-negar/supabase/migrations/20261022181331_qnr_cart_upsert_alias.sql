create or replace function public.qnr_add_to_cart(p_product_id uuid, p_quantity integer default 1)
returns integer
language plpgsql
security invoker
set search_path = public
as $$
declare
  final_quantity integer;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED' using errcode = '42501';
  end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 99 then
    raise exception 'INVALID_QUANTITY' using errcode = '22023';
  end if;

  insert into public.qnr_cart_items as cart (user_id, product_id, quantity)
  select auth.uid(), p.id, p_quantity
  from public.qnr_products p
  where p.id = p_product_id and p.is_published and p.inventory_count >= p_quantity
  on conflict (user_id, product_id) do update
    set quantity = cart.quantity + excluded.quantity,
        updated_at = now()
    where cart.quantity + excluded.quantity <= 99
      and cart.quantity + excluded.quantity <= (
        select p.inventory_count from public.qnr_products p where p.id = p_product_id and p.is_published
      )
  returning quantity into final_quantity;

  if final_quantity is null then
    raise exception 'PRODUCT_UNAVAILABLE_OR_INSUFFICIENT_STOCK' using errcode = 'P0001';
  end if;
  return final_quantity;
end;
$$;
