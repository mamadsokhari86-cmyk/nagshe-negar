create table qnr_private.qnr_gallery_upload_events (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
create index qnr_gallery_upload_events_user_recent_idx
  on qnr_private.qnr_gallery_upload_events (user_id, created_at desc);
alter table qnr_private.qnr_gallery_upload_events enable row level security;
revoke all on qnr_private.qnr_gallery_upload_events from public, anon, authenticated;
grant all on qnr_private.qnr_gallery_upload_events to service_role;
create policy qnr_gallery_upload_events_no_direct_access on qnr_private.qnr_gallery_upload_events
  for all to anon, authenticated using (false) with check (false);

create or replace function qnr_private.qnr_gallery_upload_allowed()
returns boolean language plpgsql volatile security definer set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  recent_count integer;
begin
  if actor is null then return false; end if;
  perform pg_advisory_xact_lock(hashtextextended(actor::text || ':gallery-upload', 0));
  delete from qnr_private.qnr_gallery_upload_events e
    where e.user_id = actor and e.created_at <= now() - interval '24 hours';
  select count(*) into recent_count from qnr_private.qnr_gallery_upload_events e
    where e.user_id = actor and e.created_at > now() - interval '24 hours';
  if recent_count >= 20 then return false; end if;
  insert into qnr_private.qnr_gallery_upload_events (user_id) values (actor);
  return true;
end;
$$;
revoke all on function qnr_private.qnr_gallery_upload_allowed() from public, anon;
grant execute on function qnr_private.qnr_gallery_upload_allowed() to authenticated;
