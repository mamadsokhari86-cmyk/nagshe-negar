alter table public.qnr_support_tickets alter column ticket_number set default
  ('SP-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)));

create or replace function qnr_private.qnr_support_ticket_rate_guard()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  recent_count integer;
begin
  perform pg_advisory_xact_lock(hashtextextended(new.user_id::text || ':support-open', 0));
  select count(*) into recent_count from public.qnr_support_tickets
    where user_id = new.user_id and created_at > now() - interval '1 hour';
  if recent_count >= 5 then raise exception 'SUPPORT_RATE_LIMIT' using errcode = 'P0001'; end if;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_support_ticket_rate_guard() from public, anon, authenticated, service_role;
create trigger qnr_support_tickets_rate_guard before insert on public.qnr_support_tickets
  for each row execute function qnr_private.qnr_support_ticket_rate_guard();

drop policy if exists qnr_support_tickets_insert_owner on public.qnr_support_tickets;
create policy qnr_support_tickets_insert_owner on public.qnr_support_tickets for insert to authenticated
  with check (user_id = (select auth.uid()) and status = 'waiting_staff' and priority = 'normal');
drop policy if exists qnr_support_tickets_update_admin on public.qnr_support_tickets;
create policy qnr_support_tickets_update_admin on public.qnr_support_tickets for update to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
drop policy if exists qnr_support_messages_insert_member on public.qnr_support_messages;
create policy qnr_support_messages_insert_member on public.qnr_support_messages for insert to authenticated
  with check (
    sender_id = (select auth.uid())
    and (
      (sender_role = 'customer' and exists (
        select 1 from public.qnr_support_tickets t
        where t.id = ticket_id and t.user_id = (select auth.uid()) and t.status <> 'closed'
      ))
      or (sender_role = 'staff' and qnr_private.qnr_is_admin())
    )
  );

grant insert on public.qnr_support_tickets, public.qnr_support_messages to authenticated;
grant update(status, priority) on public.qnr_support_tickets to authenticated;
grant select on public.qnr_support_tickets, public.qnr_support_messages, public.qnr_notifications to authenticated;

create or replace function qnr_private.qnr_support_message_activity()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  ticket_row public.qnr_support_tickets%rowtype;
begin
  select * into ticket_row from public.qnr_support_tickets where id = new.ticket_id for update;
  if not found then return new; end if;
  update public.qnr_support_tickets
    set status = case when new.sender_role = 'staff' then 'waiting_user' else 'waiting_staff' end,
        last_message_at = new.created_at
    where id = ticket_row.id;
  if new.sender_role = 'staff' then
    insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
      values (ticket_row.user_id, 'support_reply', 'پاسخ پشتیبانی آماده است', 'برای دیدن پاسخ، صندوق پشتیبانی را باز کن.', '/support');
  else
    insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
      select user_id, 'support_reply', 'پاسخ تازه به درخواست پشتیبانی', 'کاربر به درخواست پشتیبانی پاسخ داد.', '/admin'
      from public.qnr_user_roles where role = 'admin';
  end if;
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
    values (new.sender_id, 'reply', 'qnr_support_tickets', ticket_row.id::text, jsonb_build_object('ticket_number', ticket_row.ticket_number, 'sender_role', new.sender_role));
  return new;
end;
$$;
revoke all on function qnr_private.qnr_support_message_activity() from public, anon, authenticated, service_role;
create trigger qnr_support_messages_activity after insert on public.qnr_support_messages
  for each row execute function qnr_private.qnr_support_message_activity();

create or replace function qnr_private.qnr_support_ticket_audit()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  if old.status is distinct from new.status or old.priority is distinct from new.priority then
    insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
      values (auth.uid(), 'update', 'qnr_support_tickets', new.id::text,
        jsonb_build_object('ticket_number', new.ticket_number, 'status', new.status, 'priority', new.priority));
  end if;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_support_ticket_audit() from public, anon, authenticated, service_role;
create trigger qnr_support_tickets_audit after update on public.qnr_support_tickets
  for each row execute function qnr_private.qnr_support_ticket_audit();

create or replace function public.qnr_open_support_ticket(p_subject text, p_body text)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  actor uuid := auth.uid();
  ticket_row public.qnr_support_tickets%rowtype;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if length(trim(coalesce(p_subject, ''))) not between 5 and 120
    or length(trim(coalesce(p_body, ''))) not between 1 and 5000 then
    raise exception 'INVALID_SUPPORT_MESSAGE' using errcode = '22023';
  end if;
  insert into public.qnr_support_tickets (user_id, subject) values (actor, trim(p_subject)) returning * into ticket_row;
  insert into public.qnr_support_messages (ticket_id, sender_id, sender_role, body)
    values (ticket_row.id, actor, 'customer', trim(p_body));
  return jsonb_build_object('id', ticket_row.id, 'ticket_number', ticket_row.ticket_number, 'status', ticket_row.status);
end;
$$;
revoke all on function public.qnr_open_support_ticket(text, text) from public, anon, authenticated;
grant execute on function public.qnr_open_support_ticket(text, text) to authenticated;

create or replace function public.qnr_reply_support_ticket(p_ticket_id uuid, p_body text)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  actor uuid := auth.uid();
  ticket_row public.qnr_support_tickets%rowtype;
  actor_is_staff boolean;
  role_value text;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if length(trim(coalesce(p_body, ''))) not between 1 and 5000 then
    raise exception 'INVALID_SUPPORT_MESSAGE' using errcode = '22023';
  end if;
  select * into ticket_row from public.qnr_support_tickets where id = p_ticket_id;
  if not found then raise exception 'TICKET_NOT_FOUND' using errcode = 'P0002'; end if;
  actor_is_staff := qnr_private.qnr_is_admin();
  if ticket_row.user_id <> actor and not actor_is_staff then raise exception 'TICKET_ACCESS_DENIED' using errcode = '42501'; end if;
  role_value := case when actor_is_staff then 'staff' else 'customer' end;
  insert into public.qnr_support_messages (ticket_id, sender_id, sender_role, body)
    values (ticket_row.id, actor, role_value, trim(p_body));
  return jsonb_build_object('ticket_id', ticket_row.id, 'status', case when actor_is_staff then 'waiting_user' else 'waiting_staff' end);
end;
$$;
revoke all on function public.qnr_reply_support_ticket(uuid, text) from public, anon, authenticated;
grant execute on function public.qnr_reply_support_ticket(uuid, text) to authenticated;

create or replace function public.qnr_update_support_ticket(p_ticket_id uuid, p_status text, p_priority text)
returns jsonb
language plpgsql
security invoker
set search_path = public
as $$
declare
  ticket_row public.qnr_support_tickets%rowtype;
begin
  if p_status not in ('waiting_staff', 'waiting_user', 'closed') or p_priority not in ('normal', 'high') then
    raise exception 'INVALID_TICKET_STATUS' using errcode = '22023';
  end if;
  update public.qnr_support_tickets set status = p_status, priority = p_priority where id = p_ticket_id returning * into ticket_row;
  if not found then raise exception 'TICKET_NOT_FOUND_OR_FORBIDDEN' using errcode = '42501'; end if;
  return jsonb_build_object('id', ticket_row.id, 'status', ticket_row.status, 'priority', ticket_row.priority);
end;
$$;
revoke all on function public.qnr_update_support_ticket(uuid, text, text) from public, anon, authenticated;
grant execute on function public.qnr_update_support_ticket(uuid, text, text) to authenticated;
