-- نقش‌نگار: هویت و محتوای پایه
-- Migration is additive and isolated to qnr_-prefixed objects.

alter default privileges for role postgres in schema public
  revoke select, insert, update, delete on tables from anon, authenticated, service_role;
alter default privileges for role postgres in schema public
  revoke execute on functions from anon, authenticated, service_role, public;
alter default privileges for role postgres in schema public
  revoke usage, select on sequences from anon, authenticated, service_role;

create table public.qnr_profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  avatar_path text,
  locale text not null default 'fa-IR',
  preferences jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.qnr_user_roles (
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('admin', 'editor', 'teacher', 'moderator', 'seller')),
  granted_by uuid references auth.users(id) on delete set null,
  granted_at timestamptz not null default now(),
  primary key (user_id, role)
);

create table public.qnr_audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  subject_type text not null,
  subject_id text,
  reason text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create or replace function public.qnr_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.qnr_user_roles
    where user_id = auth.uid() and role = 'admin'
  );
$$;

create or replace function public.qnr_touch_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at := now();
  return new;
end;
$$;

create or replace function public.qnr_create_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.qnr_profiles (id, display_name)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;

create trigger qnr_auth_user_profile
after insert on auth.users
for each row execute function public.qnr_create_profile();

create trigger qnr_profiles_touch_updated_at
before update on public.qnr_profiles
for each row execute function public.qnr_touch_updated_at();

create table public.qnr_categories (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  name text not null,
  description text not null default '',
  sort_order integer not null default 0,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.qnr_products (
  id uuid primary key default gen_random_uuid(),
  category_id uuid references public.qnr_categories(id) on delete set null,
  slug text not null unique check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  name text not null,
  description text not null default '',
  price_amount bigint check (price_amount is null or price_amount >= 0),
  currency text not null default 'IRR',
  inventory_count integer not null default 0 check (inventory_count >= 0),
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.qnr_tutorials (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  title text not null,
  summary text not null default '',
  body jsonb not null default '[]'::jsonb,
  level text not null default 'beginner' check (level in ('beginner', 'intermediate', 'advanced')),
  duration_minutes integer check (duration_minutes is null or duration_minutes > 0),
  is_published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.qnr_courses (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  title text not null,
  summary text not null default '',
  price_amount bigint check (price_amount is null or price_amount >= 0),
  currency text not null default 'IRR',
  is_published boolean not null default false,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.qnr_course_entitlements (
  user_id uuid not null references auth.users(id) on delete cascade,
  course_id uuid not null references public.qnr_courses(id) on delete cascade,
  source text not null check (source in ('purchase', 'grant', 'scholarship')),
  granted_at timestamptz not null default now(),
  expires_at timestamptz,
  primary key (user_id, course_id)
);

create table public.qnr_course_lessons (
  id uuid primary key default gen_random_uuid(),
  course_id uuid not null references public.qnr_courses(id) on delete cascade,
  slug text not null,
  title text not null,
  summary text not null default '',
  body jsonb not null default '[]'::jsonb,
  video_storage_path text,
  access_type text not null default 'paid' check (access_type in ('free', 'paid')),
  sort_order integer not null default 0,
  is_published boolean not null default false,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (course_id, slug)
);

create table public.qnr_site_pages (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9]+(?:-[a-z0-9]+)*$'),
  title text not null,
  body jsonb not null default '[]'::jsonb,
  is_published boolean not null default false,
  published_at timestamptz,
  updated_at timestamptz not null default now()
);

create trigger qnr_categories_touch_updated_at before update on public.qnr_categories for each row execute function public.qnr_touch_updated_at();
create trigger qnr_products_touch_updated_at before update on public.qnr_products for each row execute function public.qnr_touch_updated_at();
create trigger qnr_tutorials_touch_updated_at before update on public.qnr_tutorials for each row execute function public.qnr_touch_updated_at();
create trigger qnr_courses_touch_updated_at before update on public.qnr_courses for each row execute function public.qnr_touch_updated_at();
create trigger qnr_course_lessons_touch_updated_at before update on public.qnr_course_lessons for each row execute function public.qnr_touch_updated_at();
create trigger qnr_site_pages_touch_updated_at before update on public.qnr_site_pages for each row execute function public.qnr_touch_updated_at();

alter table public.qnr_profiles enable row level security;
alter table public.qnr_user_roles enable row level security;
alter table public.qnr_audit_log enable row level security;
alter table public.qnr_categories enable row level security;
alter table public.qnr_products enable row level security;
alter table public.qnr_tutorials enable row level security;
alter table public.qnr_courses enable row level security;
alter table public.qnr_course_entitlements enable row level security;
alter table public.qnr_course_lessons enable row level security;
alter table public.qnr_site_pages enable row level security;

create policy "profiles_read_self_or_admin" on public.qnr_profiles for select to authenticated using (id = auth.uid() or public.qnr_is_admin());
create policy "profiles_update_self" on public.qnr_profiles for update to authenticated using (id = auth.uid()) with check (id = auth.uid());
create policy "roles_read_self_or_admin" on public.qnr_user_roles for select to authenticated using (user_id = auth.uid() or public.qnr_is_admin());
create policy "audit_read_admin" on public.qnr_audit_log for select to authenticated using (public.qnr_is_admin());

create policy "categories_read_published" on public.qnr_categories for select to anon, authenticated using (is_published or public.qnr_is_admin());
create policy "categories_admin_manage" on public.qnr_categories for all to authenticated using (public.qnr_is_admin()) with check (public.qnr_is_admin());
create policy "products_read_published" on public.qnr_products for select to anon, authenticated using (is_published or public.qnr_is_admin());
create policy "products_admin_manage" on public.qnr_products for all to authenticated using (public.qnr_is_admin()) with check (public.qnr_is_admin());
create policy "tutorials_read_published" on public.qnr_tutorials for select to anon, authenticated using (is_published or public.qnr_is_admin());
create policy "tutorials_admin_manage" on public.qnr_tutorials for all to authenticated using (public.qnr_is_admin()) with check (public.qnr_is_admin());
create policy "courses_read_published" on public.qnr_courses for select to anon, authenticated using (is_published or public.qnr_is_admin());
create policy "courses_admin_manage" on public.qnr_courses for all to authenticated using (public.qnr_is_admin()) with check (public.qnr_is_admin());
create policy "entitlements_read_self_or_admin" on public.qnr_course_entitlements for select to authenticated using (user_id = auth.uid() or public.qnr_is_admin());
create policy "lessons_read_by_access" on public.qnr_course_lessons for select to authenticated using (
  is_published and (
    access_type = 'free'
    or public.qnr_is_admin()
    or exists (
      select 1 from public.qnr_course_entitlements e
      where e.user_id = auth.uid()
        and e.course_id = qnr_course_lessons.course_id
        and (e.expires_at is null or e.expires_at > now())
    )
  )
);
create policy "lessons_read_free" on public.qnr_course_lessons for select to anon using (is_published and access_type = 'free');
create policy "lessons_admin_manage" on public.qnr_course_lessons for all to authenticated using (public.qnr_is_admin()) with check (public.qnr_is_admin());
create policy "site_pages_read_published" on public.qnr_site_pages for select to anon, authenticated using (is_published or public.qnr_is_admin());
create policy "site_pages_admin_manage" on public.qnr_site_pages for all to authenticated using (public.qnr_is_admin()) with check (public.qnr_is_admin());

grant usage on schema public to anon, authenticated;
revoke all on public.qnr_profiles, public.qnr_user_roles, public.qnr_audit_log,
  public.qnr_categories, public.qnr_products, public.qnr_tutorials, public.qnr_courses,
  public.qnr_course_entitlements, public.qnr_course_lessons, public.qnr_site_pages
  from anon, authenticated;

grant select, update(display_name, avatar_path, locale, preferences) on public.qnr_profiles to authenticated;
grant select on public.qnr_user_roles to authenticated;
grant select on public.qnr_audit_log to authenticated;
grant select on public.qnr_categories, public.qnr_products, public.qnr_tutorials, public.qnr_courses, public.qnr_site_pages to anon, authenticated;
grant insert, update, delete on public.qnr_categories, public.qnr_products, public.qnr_tutorials, public.qnr_courses, public.qnr_site_pages to authenticated;
grant select on public.qnr_course_entitlements to authenticated;
grant select on public.qnr_course_lessons to anon, authenticated;
grant insert, update, delete on public.qnr_course_lessons to authenticated;
grant execute on function public.qnr_is_admin() to anon, authenticated;

comment on table public.qnr_profiles is 'Private profile information for نقش‌نگار users.';
comment on table public.qnr_user_roles is 'Server-managed roles; clients have read-only access to their own roles.';
comment on table public.qnr_audit_log is 'Administrative audit history; only server functions may write.';
