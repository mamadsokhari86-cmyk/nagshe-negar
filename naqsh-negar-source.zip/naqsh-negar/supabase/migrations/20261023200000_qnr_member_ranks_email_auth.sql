-- Add non-privileged community ranks for نقش‌نگار members.
-- The member rank is separate from security roles in qnr_user_roles.
alter table public.qnr_profiles
  add column if not exists member_rank text not null default 'apprentice';

update public.qnr_profiles
set member_rank = 'apprentice'
where member_rank is null
   or member_rank not in ('apprentice', 'helper', 'master');

do $$
begin
  if not exists (
    select 1 from pg_constraint
    where conname = 'qnr_profiles_member_rank_check'
      and conrelid = 'public.qnr_profiles'::regclass
  ) then
    alter table public.qnr_profiles
      add constraint qnr_profiles_member_rank_check
      check (member_rank in ('apprentice', 'helper', 'master'));
  end if;
end $$;

comment on column public.qnr_profiles.member_rank is
  'Community rank only: apprentice=کارآموز (default), helper=کمک‌یار, master=استاد. Not an authorization role.';
