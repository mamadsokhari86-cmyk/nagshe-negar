create index qnr_course_lesson_progress_lesson_idx
  on public.qnr_course_lesson_progress (lesson_id);

create index qnr_support_messages_sender_idx
  on public.qnr_support_messages (sender_id);
