alter table public.qnr_products
  add constraint qnr_products_published_price_required
  check (not is_published or price_amount is not null);

alter table public.qnr_courses
  add constraint qnr_courses_published_price_required
  check (not is_published or price_amount is not null);
