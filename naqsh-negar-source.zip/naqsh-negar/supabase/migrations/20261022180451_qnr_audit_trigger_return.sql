create or replace function qnr_private.qnr_audit_content_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  old_row jsonb := case when tg_op = 'INSERT' then null else to_jsonb(old) end;
  new_row jsonb := case when tg_op = 'DELETE' then null else to_jsonb(new) end;
  subject_id text := coalesce(new_row ->> 'id', old_row ->> 'id');
begin
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
  values (
    auth.uid(),
    lower(tg_op),
    tg_table_name,
    subject_id,
    jsonb_build_object(
      'old_slug', old_row ->> 'slug',
      'new_slug', new_row ->> 'slug',
      'old_published', old_row ->> 'is_published',
      'new_published', new_row ->> 'is_published'
    )
  );
  if tg_op = 'DELETE' then
    return old;
  end if;
  return new;
end;
$$;
