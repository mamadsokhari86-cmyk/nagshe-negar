-- Keep gallery data RPC-only and make its user-callable security-definer work internal.
drop policy if exists qnr_gallery_posts_public_read on public.qnr_gallery_posts;
drop policy if exists qnr_gallery_posts_owner_read on public.qnr_gallery_posts;
drop policy if exists qnr_gallery_posts_admin_read on public.qnr_gallery_posts;
create policy qnr_gallery_posts_anon_read on public.qnr_gallery_posts for select to anon
  using (visibility = 'public' and review_status = 'approved' and consented_at is not null);
create policy qnr_gallery_posts_authenticated_read on public.qnr_gallery_posts for select to authenticated
  using (
    (visibility = 'public' and review_status = 'approved' and consented_at is not null)
    or owner_id = (select auth.uid())
    or qnr_private.qnr_is_admin()
  );

create policy qnr_gallery_reports_no_direct_access on public.qnr_gallery_reports for all to anon, authenticated
  using (false) with check (false);

create index if not exists qnr_gallery_posts_reviewed_by_idx on public.qnr_gallery_posts (reviewed_by);
create index if not exists qnr_gallery_reports_reporter_idx on public.qnr_gallery_reports (reporter_id);
create index if not exists qnr_gallery_reports_reviewed_by_idx on public.qnr_gallery_reports (reviewed_by);

create or replace function qnr_private.qnr_my_gallery_posts_secure()
returns table (
  id uuid, title text, caption text, topic text, use_case text, skill_level text,
  color_family text[], image_path text, visibility text, review_status text,
  moderation_note text, created_at timestamptz, updated_at timestamptz
)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if (select auth.uid()) is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  return query
    select p.id, p.title, p.caption, p.topic, p.use_case, p.skill_level, p.color_family,
           p.image_path, p.visibility, p.review_status, p.moderation_note, p.created_at, p.updated_at
    from public.qnr_gallery_posts p
    where p.owner_id = (select auth.uid())
    order by p.created_at desc;
end;
$$;
revoke all on function qnr_private.qnr_my_gallery_posts_secure() from public, anon;
grant execute on function qnr_private.qnr_my_gallery_posts_secure() to authenticated;
create or replace function public.qnr_my_gallery_posts()
returns table (
  id uuid, title text, caption text, topic text, use_case text, skill_level text,
  color_family text[], image_path text, visibility text, review_status text,
  moderation_note text, created_at timestamptz, updated_at timestamptz
)
language sql stable security invoker set search_path = ''
as $$ select * from qnr_private.qnr_my_gallery_posts_secure() $$;
revoke all on function public.qnr_my_gallery_posts() from public, anon;
grant execute on function public.qnr_my_gallery_posts() to authenticated;

create or replace function qnr_private.qnr_admin_gallery_queue_secure()
returns table (
  id uuid, owner_id uuid, title text, caption text, topic text, use_case text,
  skill_level text, color_family text[], image_path text, created_at timestamptz
)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if (select auth.uid()) is null or not qnr_private.qnr_is_admin() then
    raise exception 'ADMIN_REQUIRED' using errcode = '42501';
  end if;
  return query
    select p.id, p.owner_id, p.title, p.caption, p.topic, p.use_case, p.skill_level,
           p.color_family, p.image_path, p.created_at
    from public.qnr_gallery_posts p
    where p.visibility = 'public' and p.review_status = 'pending'
    order by p.created_at asc;
end;
$$;
revoke all on function qnr_private.qnr_admin_gallery_queue_secure() from public, anon;
grant execute on function qnr_private.qnr_admin_gallery_queue_secure() to authenticated;
create or replace function public.qnr_admin_gallery_queue()
returns table (
  id uuid, owner_id uuid, title text, caption text, topic text, use_case text,
  skill_level text, color_family text[], image_path text, created_at timestamptz
)
language sql stable security invoker set search_path = ''
as $$ select * from qnr_private.qnr_admin_gallery_queue_secure() $$;
revoke all on function public.qnr_admin_gallery_queue() from public, anon;
grant execute on function public.qnr_admin_gallery_queue() to authenticated;

create or replace function qnr_private.qnr_admin_gallery_reports_secure()
returns table (
  id uuid, post_id uuid, post_title text, reason text, description text,
  status text, created_at timestamptz, resolution_note text
)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if (select auth.uid()) is null or not qnr_private.qnr_is_admin() then
    raise exception 'ADMIN_REQUIRED' using errcode = '42501';
  end if;
  return query
    select r.id, r.post_id, p.title, r.reason, r.description, r.status, r.created_at, r.resolution_note
    from public.qnr_gallery_reports r
    join public.qnr_gallery_posts p on p.id = r.post_id
    order by (r.status = 'open') desc, r.created_at desc;
end;
$$;
revoke all on function qnr_private.qnr_admin_gallery_reports_secure() from public, anon;
grant execute on function qnr_private.qnr_admin_gallery_reports_secure() to authenticated;
create or replace function public.qnr_admin_gallery_reports()
returns table (
  id uuid, post_id uuid, post_title text, reason text, description text,
  status text, created_at timestamptz, resolution_note text
)
language sql stable security invoker set search_path = ''
as $$ select * from qnr_private.qnr_admin_gallery_reports_secure() $$;
revoke all on function public.qnr_admin_gallery_reports() from public, anon;
grant execute on function public.qnr_admin_gallery_reports() to authenticated;

create or replace function qnr_private.qnr_report_gallery_post_secure(p_post_id uuid, p_reason text, p_description text default '')
returns uuid
language plpgsql security definer set search_path = ''
as $$
declare
  report_id uuid;
  report_text text := coalesce(trim(p_description), '');
begin
  if (select auth.uid()) is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if p_reason is null or p_reason not in ('copyright', 'privacy', 'spam', 'harassment', 'other') then
    raise exception 'INVALID_REPORT_REASON' using errcode = '22023';
  end if;
  if char_length(report_text) > 500 then raise exception 'REPORT_TOO_LONG' using errcode = '22023'; end if;
  if not exists (
    select 1 from public.qnr_gallery_posts p
    where p.id = p_post_id and p.visibility = 'public' and p.review_status = 'approved' and p.consented_at is not null
  ) then raise exception 'POST_NOT_REPORTABLE' using errcode = '22023'; end if;
  insert into public.qnr_gallery_reports (post_id, reporter_id, reason, description)
    values (p_post_id, (select auth.uid()), p_reason, report_text)
    returning id into report_id;
  return report_id;
exception when unique_violation then
  raise exception 'DUPLICATE_GALLERY_REPORT' using errcode = '23505';
end;
$$;
revoke all on function qnr_private.qnr_report_gallery_post_secure(uuid, text, text) from public, anon;
grant execute on function qnr_private.qnr_report_gallery_post_secure(uuid, text, text) to authenticated;
create or replace function public.qnr_report_gallery_post(p_post_id uuid, p_reason text, p_description text default '')
returns uuid
language sql security invoker set search_path = ''
as $$ select qnr_private.qnr_report_gallery_post_secure(p_post_id, p_reason, p_description) $$;
revoke all on function public.qnr_report_gallery_post(uuid, text, text) from public, anon;
grant execute on function public.qnr_report_gallery_post(uuid, text, text) to authenticated;

create or replace function qnr_private.qnr_moderate_gallery_post_secure(p_post_id uuid, p_action text, p_note text default '')
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_status text;
  next_status text;
  owner uuid;
  clean_note text := left(nullif(trim(coalesce(p_note, '')), ''), 500);
begin
  if actor is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  if p_action is null or p_action not in ('approve', 'reject', 'hide') then raise exception 'INVALID_MODERATION_ACTION' using errcode = '22023'; end if;
  select p.review_status, p.owner_id into current_status, owner
    from public.qnr_gallery_posts p where p.id = p_post_id and p.visibility = 'public' for update;
  if not found then raise exception 'POST_NOT_FOUND' using errcode = 'P0002'; end if;
  if p_action in ('approve', 'reject') and current_status <> 'pending' then raise exception 'POST_NOT_PENDING' using errcode = '22023'; end if;
  if p_action = 'hide' and current_status not in ('approved', 'pending') then raise exception 'POST_NOT_VISIBLE' using errcode = '22023'; end if;
  next_status := case p_action when 'approve' then 'approved' when 'reject' then 'rejected' else 'hidden' end;
  update public.qnr_gallery_posts
    set review_status = next_status, moderation_note = clean_note, reviewed_by = actor, reviewed_at = now(), updated_at = now()
    where id = p_post_id;
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
    values (actor, p_action, 'qnr_gallery_posts', p_post_id::text, jsonb_build_object('status', next_status, 'note', clean_note));
  insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
    values (owner, 'gallery_review', 'وضعیت اثر گالری به‌روز شد',
      case next_status when 'approved' then 'اثر تو پس از بازبینی در گالری منتشر شد.'
        when 'rejected' then 'اثر تو برای انتشار در گالری پذیرفته نشد؛ توضیح را در آثار من ببین.'
        else 'نمایش اثر تو از گالری متوقف شد.' end,
      '/gallery');
end;
$$;
revoke all on function qnr_private.qnr_moderate_gallery_post_secure(uuid, text, text) from public, anon;
grant execute on function qnr_private.qnr_moderate_gallery_post_secure(uuid, text, text) to authenticated;
create or replace function public.qnr_moderate_gallery_post(p_post_id uuid, p_action text, p_note text default '')
returns void
language sql security invoker set search_path = ''
as $$ select qnr_private.qnr_moderate_gallery_post_secure(p_post_id, p_action, p_note) $$;
revoke all on function public.qnr_moderate_gallery_post(uuid, text, text) from public, anon;
grant execute on function public.qnr_moderate_gallery_post(uuid, text, text) to authenticated;

create or replace function qnr_private.qnr_admin_resolve_gallery_report_secure(p_report_id uuid, p_status text, p_note text default '')
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  clean_note text := left(nullif(trim(coalesce(p_note, '')), ''), 500);
begin
  if actor is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  if p_status is null or p_status not in ('reviewed', 'dismissed') then raise exception 'INVALID_REPORT_STATUS' using errcode = '22023'; end if;
  update public.qnr_gallery_reports
    set status = p_status, reviewed_by = actor, reviewed_at = now(), resolution_note = clean_note
    where id = p_report_id and status = 'open';
  if not found then raise exception 'REPORT_NOT_OPEN' using errcode = '22023'; end if;
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
    values (actor, 'resolve', 'qnr_gallery_reports', p_report_id::text, jsonb_build_object('status', p_status, 'note', clean_note));
end;
$$;
revoke all on function qnr_private.qnr_admin_resolve_gallery_report_secure(uuid, text, text) from public, anon;
grant execute on function qnr_private.qnr_admin_resolve_gallery_report_secure(uuid, text, text) to authenticated;
create or replace function public.qnr_admin_resolve_gallery_report(p_report_id uuid, p_status text, p_note text default '')
returns void
language sql security invoker set search_path = ''
as $$ select qnr_private.qnr_admin_resolve_gallery_report_secure(p_report_id, p_status, p_note) $$;
revoke all on function public.qnr_admin_resolve_gallery_report(uuid, text, text) from public, anon;
grant execute on function public.qnr_admin_resolve_gallery_report(uuid, text, text) to authenticated;
