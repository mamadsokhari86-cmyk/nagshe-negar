-- Keep user identity checks stable for each query and index foreign keys used in lookups.
create index if not exists qnr_audit_log_actor_idx on public.qnr_audit_log (actor_id);
create index if not exists qnr_cart_items_product_idx on public.qnr_cart_items (product_id);
create index if not exists qnr_course_entitlements_course_idx on public.qnr_course_entitlements (course_id);
create index if not exists qnr_manual_payments_user_idx on public.qnr_manual_payments (user_id);
create index if not exists qnr_manual_payments_reviewed_by_idx on public.qnr_manual_payments (reviewed_by);
create index if not exists qnr_order_events_actor_idx on public.qnr_order_events (actor_id);
create index if not exists qnr_order_items_product_idx on public.qnr_order_items (product_id);
create index if not exists qnr_products_category_idx on public.qnr_products (category_id);
create index if not exists qnr_store_settings_updated_by_idx on public.qnr_store_settings (updated_by);
create index if not exists qnr_user_roles_granted_by_idx on public.qnr_user_roles (granted_by);

create or replace function qnr_private.qnr_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.qnr_user_roles
    where user_id = (select auth.uid()) and role = 'admin'
  );
$$;

drop policy if exists profiles_read_self_or_admin on public.qnr_profiles;
create policy profiles_read_self_or_admin on public.qnr_profiles for select to authenticated
  using (id = (select auth.uid()) or qnr_private.qnr_is_admin());
drop policy if exists profiles_update_self on public.qnr_profiles;
create policy profiles_update_self on public.qnr_profiles for update to authenticated
  using (id = (select auth.uid())) with check (id = (select auth.uid()));
drop policy if exists roles_read_self_or_admin on public.qnr_user_roles;
create policy roles_read_self_or_admin on public.qnr_user_roles for select to authenticated
  using (user_id = (select auth.uid()) or qnr_private.qnr_is_admin());
drop policy if exists entitlements_read_self_or_admin on public.qnr_course_entitlements;
create policy entitlements_read_self_or_admin on public.qnr_course_entitlements for select to authenticated
  using (user_id = (select auth.uid()) or qnr_private.qnr_is_admin());
drop policy if exists lessons_read_by_access on public.qnr_course_lessons;
create policy lessons_read_by_access on public.qnr_course_lessons for select to authenticated using (
  is_published and (
    access_type = 'free'
    or qnr_private.qnr_is_admin()
    or exists (
      select 1 from public.qnr_course_entitlements e
      where e.user_id = (select auth.uid())
        and e.course_id = qnr_course_lessons.course_id
        and (e.expires_at is null or e.expires_at > now())
    )
  )
);

drop policy if exists qnr_projects_select_own on public.qnr_projects;
create policy qnr_projects_select_own on public.qnr_projects for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists qnr_projects_insert_own on public.qnr_projects;
create policy qnr_projects_insert_own on public.qnr_projects for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists qnr_projects_update_own on public.qnr_projects;
create policy qnr_projects_update_own on public.qnr_projects for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists qnr_projects_delete_own on public.qnr_projects;
create policy qnr_projects_delete_own on public.qnr_projects for delete to authenticated using (user_id = (select auth.uid()));

drop policy if exists qnr_cart_items_select_own on public.qnr_cart_items;
create policy qnr_cart_items_select_own on public.qnr_cart_items for select to authenticated using (user_id = (select auth.uid()));
drop policy if exists qnr_cart_items_insert_own on public.qnr_cart_items;
create policy qnr_cart_items_insert_own on public.qnr_cart_items for insert to authenticated with check (user_id = (select auth.uid()));
drop policy if exists qnr_cart_items_update_own on public.qnr_cart_items;
create policy qnr_cart_items_update_own on public.qnr_cart_items for update to authenticated
  using (user_id = (select auth.uid())) with check (user_id = (select auth.uid()));
drop policy if exists qnr_cart_items_delete_own on public.qnr_cart_items;
create policy qnr_cart_items_delete_own on public.qnr_cart_items for delete to authenticated using (user_id = (select auth.uid()));

drop policy if exists qnr_orders_read_own_or_admin on public.qnr_orders;
create policy qnr_orders_read_own_or_admin on public.qnr_orders for select to authenticated
  using (user_id = (select auth.uid()) or qnr_private.qnr_is_admin());
drop policy if exists qnr_order_items_read_own_or_admin on public.qnr_order_items;
create policy qnr_order_items_read_own_or_admin on public.qnr_order_items for select to authenticated
  using (exists (select 1 from public.qnr_orders o where o.id = order_id and (o.user_id = (select auth.uid()) or qnr_private.qnr_is_admin())));
drop policy if exists qnr_order_events_read_own_or_admin on public.qnr_order_events;
create policy qnr_order_events_read_own_or_admin on public.qnr_order_events for select to authenticated
  using (exists (select 1 from public.qnr_orders o where o.id = order_id and (o.user_id = (select auth.uid()) or qnr_private.qnr_is_admin())));
drop policy if exists qnr_manual_payments_read_own_or_admin on public.qnr_manual_payments;
create policy qnr_manual_payments_read_own_or_admin on public.qnr_manual_payments for select to authenticated
  using (user_id = (select auth.uid()) or qnr_private.qnr_is_admin());
drop policy if exists qnr_manual_payments_submit_own on public.qnr_manual_payments;
create policy qnr_manual_payments_submit_own on public.qnr_manual_payments for insert to authenticated
  with check (user_id = (select auth.uid()) and status = 'pending' and reviewed_by is null and reviewed_at is null);
