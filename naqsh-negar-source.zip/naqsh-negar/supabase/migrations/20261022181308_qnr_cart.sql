create table public.qnr_cart_items (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  product_id uuid not null references public.qnr_products(id) on delete cascade,
  quantity integer not null check (quantity between 1 and 99),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, product_id)
);

create index qnr_cart_items_user_idx on public.qnr_cart_items (user_id, updated_at desc);
create trigger qnr_cart_items_touch_updated_at before update on public.qnr_cart_items
  for each row execute function public.qnr_touch_updated_at();
alter table public.qnr_cart_items enable row level security;
create policy qnr_cart_items_select_own on public.qnr_cart_items for select to authenticated using (user_id = auth.uid());
create policy qnr_cart_items_insert_own on public.qnr_cart_items for insert to authenticated with check (user_id = auth.uid());
create policy qnr_cart_items_update_own on public.qnr_cart_items for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy qnr_cart_items_delete_own on public.qnr_cart_items for delete to authenticated using (user_id = auth.uid());

revoke all on public.qnr_cart_items from anon, authenticated;
grant select, insert, update, delete on public.qnr_cart_items to authenticated;

create or replace function public.qnr_add_to_cart(p_product_id uuid, p_quantity integer default 1)
returns integer
language plpgsql
security invoker
set search_path = public
as $$
declare
  final_quantity integer;
begin
  if auth.uid() is null then
    raise exception 'AUTH_REQUIRED' using errcode = '42501';
  end if;
  if p_quantity is null or p_quantity < 1 or p_quantity > 99 then
    raise exception 'INVALID_QUANTITY' using errcode = '22023';
  end if;

  insert into public.qnr_cart_items (user_id, product_id, quantity)
  select auth.uid(), p.id, p_quantity
  from public.qnr_products p
  where p.id = p_product_id and p.is_published and p.inventory_count >= p_quantity
  on conflict (user_id, product_id) do update
    set quantity = public.qnr_cart_items.quantity + excluded.quantity,
        updated_at = now()
    where public.qnr_cart_items.quantity + excluded.quantity <= 99
      and public.qnr_cart_items.quantity + excluded.quantity <= (
        select p.inventory_count from public.qnr_products p where p.id = p_product_id and p.is_published
      )
  returning quantity into final_quantity;

  if final_quantity is null then
    raise exception 'PRODUCT_UNAVAILABLE_OR_INSUFFICIENT_STOCK' using errcode = 'P0001';
  end if;
  return final_quantity;
end;
$$;
revoke all on function public.qnr_add_to_cart(uuid, integer) from public, anon;
grant execute on function public.qnr_add_to_cart(uuid, integer) to authenticated;
