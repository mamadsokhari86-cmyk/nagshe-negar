begin;

create policy qnr_chat_rooms_deny_direct_access on public.qnr_chat_rooms
  for all to anon,authenticated using (false) with check (false);
create policy qnr_chat_room_members_deny_direct_access on public.qnr_chat_room_members
  for all to anon,authenticated using (false) with check (false);
create policy qnr_course_teachers_deny_direct_access on public.qnr_course_teachers
  for all to anon,authenticated using (false) with check (false);
create policy qnr_chat_blocks_deny_direct_access on qnr_private.qnr_chat_blocks
  for all to anon,authenticated using (false) with check (false);
create policy qnr_chat_reports_deny_direct_access on qnr_private.qnr_chat_reports
  for all to anon,authenticated using (false) with check (false);
create policy qnr_chat_upload_events_deny_direct_access on qnr_private.qnr_chat_upload_events
  for all to anon,authenticated using (false) with check (false);
create policy qnr_chat_upload_tickets_deny_direct_access on qnr_private.qnr_chat_upload_tickets
  for all to anon,authenticated using (false) with check (false);

create index qnr_chat_messages_hidden_by_idx on public.qnr_chat_messages(hidden_by);
create index qnr_chat_rooms_direct_user_b_idx on public.qnr_chat_rooms(direct_user_b) where room_type='direct';
create index qnr_course_teachers_assigned_by_idx on public.qnr_course_teachers(assigned_by);
create index qnr_chat_blocks_blocked_user_idx on qnr_private.qnr_chat_blocks(blocked_user_id);
create index qnr_chat_reports_message_idx on qnr_private.qnr_chat_reports(message_id);
create index qnr_chat_reports_reviewed_by_idx on qnr_private.qnr_chat_reports(reviewed_by);
create index qnr_chat_reports_room_idx on qnr_private.qnr_chat_reports(room_id);
create index qnr_chat_upload_tickets_consumed_message_idx on qnr_private.qnr_chat_upload_tickets(consumed_message_id);
create index qnr_chat_upload_tickets_room_idx on qnr_private.qnr_chat_upload_tickets(room_id);

revoke all on public.qnr_chat_messages from anon,authenticated,service_role;
grant select (id,room_id,sender_id,body,image_path,created_at) on public.qnr_chat_messages to authenticated;

create or replace function qnr_private.qnr_chat_send_message_secure(p_room_id uuid,p_body text,p_client_nonce uuid,p_image_path text default null)
returns uuid language plpgsql security definer set search_path = '' as $function$
declare
  actor uuid := (select auth.uid());
  clean_body text := trim(replace(coalesce(p_body,''), E'\\r\\n', E'\\n'));
  room_kind text; member_status text; existing public.qnr_chat_messages%rowtype;
  message_id uuid; recipient_id uuid; recent_count integer;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode='42501'; end if;
  if p_client_nonce is null then raise exception 'INVALID_NONCE' using errcode='22023'; end if;
  if length(clean_body)>5000 then raise exception 'MESSAGE_TOO_LONG' using errcode='22023'; end if;
  if replace(replace(clean_body,E'\\n',''),E'\\t','') ~ '[[:cntrl:]]' then raise exception 'INVALID_MESSAGE_CHARACTERS' using errcode='22023'; end if;
  if clean_body='' and p_image_path is null then raise exception 'EMPTY_MESSAGE' using errcode='22023'; end if;
  select * into existing from public.qnr_chat_messages m where m.sender_id=actor and m.client_nonce=p_client_nonce;
  if found then
    if existing.room_id=p_room_id and existing.body=clean_body and existing.image_path is not distinct from p_image_path then return existing.id; end if;
    raise exception 'IDEMPOTENCY_CONFLICT' using errcode='23505';
  end if;
  select r.room_type,m.status into room_kind,member_status from public.qnr_chat_rooms r
    join public.qnr_chat_room_members m on m.room_id=r.id
    where r.id=p_room_id and r.is_active and m.user_id=actor;
  if not found or member_status='removed' then raise exception 'ROOM_ACCESS_DENIED' using errcode='42501'; end if;
  if member_status='banned' then
    if exists(select 1 from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id=actor and (m.banned_until is null or m.banned_until>now())) then
      raise exception 'MEMBER_BANNED' using errcode='42501';
    end if;
    update public.qnr_chat_room_members set status='active',banned_until=null,moderation_reason=null where room_id=p_room_id and user_id=actor;
    member_status:='active';
  end if;
  if member_status='muted' and exists(select 1 from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id=actor and m.muted_until>now()) then
    raise exception 'MEMBER_MUTED' using errcode='42501';
  end if;
  if room_kind='direct' and exists(
    select 1 from public.qnr_chat_room_members other join qnr_private.qnr_chat_blocks b on
      ((b.user_id=other.user_id and b.blocked_user_id=actor) or (b.user_id=actor and b.blocked_user_id=other.user_id))
    where other.room_id=p_room_id and other.user_id<>actor
  ) then raise exception 'DIRECT_MESSAGE_BLOCKED' using errcode='42501'; end if;
  if p_image_path is not null then
    if p_image_path !~ ('^'||p_room_id::text||'/[0-9a-f-]{36}[.](jpg|jpeg|png|webp)$') then raise exception 'INVALID_IMAGE_PATH' using errcode='22023'; end if;
    perform 1 from qnr_private.qnr_chat_upload_tickets t where t.object_path=p_image_path and t.user_id=actor and t.room_id=p_room_id and t.client_nonce=p_client_nonce for update;
    if not found then raise exception 'UPLOAD_NOT_REGISTERED' using errcode='42501'; end if;
  end if;
  perform pg_advisory_xact_lock(hashtextextended(actor::text||':chat-message',0));
  select count(*) into recent_count from public.qnr_chat_messages m where m.sender_id=actor and m.created_at>now()-interval '5 minutes';
  if recent_count>=30 then raise exception 'MESSAGE_RATE_LIMIT' using errcode='P0001'; end if;
  insert into public.qnr_chat_messages(room_id,sender_id,body,image_path,client_nonce)
    values(p_room_id,actor,clean_body,p_image_path,p_client_nonce) returning id into message_id;
  update public.qnr_chat_room_members set last_read_at=now() where room_id=p_room_id and user_id=actor;
  update public.qnr_chat_rooms set updated_at=now() where id=p_room_id;
  if p_image_path is not null then update qnr_private.qnr_chat_upload_tickets set consumed_message_id=message_id where object_path=p_image_path and user_id=actor; end if;
  begin
    if room_kind='direct' then
      insert into public.qnr_notifications(recipient_id,notification_type,title,body,target_path)
      select m.user_id,'chat_message','پیام تازه‌ای داری','یک پیام خصوصی تازه برایت رسیده است.','/community?room='||p_room_id::text
        from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id<>actor and m.status in ('active','muted');
    elsif room_kind='course_qa' then
      select m.user_id into recipient_id from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id<>actor and m.member_role in ('teacher','student') and m.status='active' limit 1;
      if recipient_id is not null then
        insert into public.qnr_notifications(recipient_id,notification_type,title,body,target_path)
        values(recipient_id,'course_question','پیام تازه دربارهٔ دوره','یک پیام تازه در گفت‌وگوی دوره ثبت شده است.','/community?room='||p_room_id::text);
      end if;
    end if;
  exception when others then null;
  end;
  return message_id;
end;
$function$;

create or replace function qnr_private.qnr_chat_register_upload_ticket_secure(p_user_id uuid,p_room_id uuid,p_client_nonce uuid,p_object_path text)
returns uuid language plpgsql security definer set search_path = '' as $function$
declare linked_message uuid; object_owner text;
begin
  if auth.role()<>'service_role' then raise exception 'SERVICE_ROLE_REQUIRED' using errcode='42501'; end if;
  if p_user_id is null or p_client_nonce is null or p_object_path !~ ('^'||p_room_id::text||'/[0-9a-f-]{36}[.](jpg|jpeg|png|webp)$') then raise exception 'INVALID_UPLOAD_TICKET' using errcode='22023'; end if;
  select m.id into linked_message from public.qnr_chat_messages m where m.sender_id=p_user_id and m.client_nonce=p_client_nonce;
  if linked_message is not null then
    if exists(select 1 from public.qnr_chat_messages m where m.id=linked_message and m.room_id=p_room_id and m.image_path=p_object_path) then return linked_message; end if;
    raise exception 'IDEMPOTENCY_CONFLICT' using errcode='23505';
  end if;
  if not exists(select 1 from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id=p_user_id and m.status='active') then raise exception 'ROOM_ACCESS_DENIED' using errcode='42501'; end if;
  select o.owner_id into object_owner from storage.objects o where o.bucket_id='qnr-chat' and o.name=p_object_path;
  if object_owner is null or object_owner<>p_user_id::text then raise exception 'UPLOAD_OBJECT_NOT_OWNED' using errcode='42501'; end if;
  insert into qnr_private.qnr_chat_upload_tickets(object_path,user_id,room_id,client_nonce)
    values(p_object_path,p_user_id,p_room_id,p_client_nonce)
    on conflict(object_path) do update set client_nonce=excluded.client_nonce
      where qnr_private.qnr_chat_upload_tickets.user_id=excluded.user_id
        and qnr_private.qnr_chat_upload_tickets.room_id=excluded.room_id
        and qnr_private.qnr_chat_upload_tickets.client_nonce=excluded.client_nonce
        and qnr_private.qnr_chat_upload_tickets.consumed_message_id is null;
  if not found then raise exception 'UPLOAD_TICKET_CONFLICT' using errcode='23505'; end if;
  return null;
end;
$function$;

create or replace function qnr_private.qnr_chat_delete_upload_ticket_secure(p_user_id uuid,p_object_path text)
returns boolean language plpgsql security definer set search_path = '' as $function$
declare ticket_path text;
begin
  if auth.role()<>'service_role' then raise exception 'SERVICE_ROLE_REQUIRED' using errcode='42501'; end if;
  select t.object_path into ticket_path from qnr_private.qnr_chat_upload_tickets t
    where t.object_path=p_object_path and t.user_id=p_user_id for update;
  if not found then return true; end if;
  if exists(select 1 from public.qnr_chat_messages m where m.image_path=p_object_path) then return false; end if;
  delete from qnr_private.qnr_chat_upload_tickets where object_path=ticket_path and user_id=p_user_id;
  return true;
end;
$function$;

commit;
