create or replace function qnr_private.qnr_validate_payment_submission()
returns trigger
language plpgsql
security definer
set search_path = public, storage
as $$
declare
  order_row public.qnr_orders%rowtype;
begin
  select * into order_row from public.qnr_orders where id = new.order_id and user_id = new.user_id for update;
  if not found or order_row.status <> 'awaiting_payment' or order_row.reservation_expires_at <= now() then
    raise exception 'ORDER_NOT_PAYABLE' using errcode = '42501';
  end if;
  if new.amount <> order_row.total_amount then
    raise exception 'PAYMENT_AMOUNT_MISMATCH' using errcode = '22023';
  end if;
  if (storage.foldername(new.receipt_path))[1] <> new.user_id::text
    or (storage.foldername(new.receipt_path))[2] <> new.order_id::text
    or not exists (
      select 1 from storage.objects o
      where o.bucket_id = 'qnr-payment-receipts' and o.name = new.receipt_path
    ) then
    raise exception 'INVALID_RECEIPT_OBJECT' using errcode = '42501';
  end if;
  update public.qnr_orders set status = 'payment_review' where id = new.order_id;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_validate_payment_submission() from public, anon, authenticated, service_role;

update public.qnr_orders o
set status = 'payment_review'
where o.status = 'awaiting_payment'
  and exists (select 1 from public.qnr_manual_payments p where p.order_id = o.id and p.status = 'pending');

create or replace function public.qnr_expire_orders()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  expired_order record;
  order_line record;
  expired_count integer := 0;
begin
  for expired_order in
    select id from public.qnr_orders
    where status in ('awaiting_payment', 'payment_review') and reservation_expires_at <= now()
    order by reservation_expires_at
    for update skip locked
  loop
    for order_line in select product_id, quantity from public.qnr_order_items where order_id = expired_order.id loop
      update public.qnr_products set inventory_count = inventory_count + order_line.quantity where id = order_line.product_id;
    end loop;
    update public.qnr_orders set status = 'expired' where id = expired_order.id;
    update public.qnr_manual_payments set status = 'expired', reviewed_at = now(), review_reason = 'مهلت پرداخت سفارش پایان یافت.'
      where order_id = expired_order.id and status = 'pending';
    insert into public.qnr_order_events (order_id, event_type, reason)
      values (expired_order.id, 'expired', 'مهلت پرداخت سفارش پایان یافت.');
    expired_count := expired_count + 1;
  end loop;
  return expired_count;
end;
$$;
revoke all on function public.qnr_expire_orders() from public, anon, authenticated;
grant execute on function public.qnr_expire_orders() to service_role;

create or replace function public.qnr_review_payment(p_actor_id uuid, p_payment_id uuid, p_decision text, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  payment_row public.qnr_manual_payments%rowtype;
  order_row public.qnr_orders%rowtype;
  order_line record;
begin
  if not exists (select 1 from public.qnr_user_roles where user_id = p_actor_id and role = 'admin') then
    raise exception 'ADMIN_REQUIRED' using errcode = '42501';
  end if;
  if p_decision not in ('approved', 'rejected') or (p_decision = 'rejected' and length(trim(coalesce(p_reason, ''))) < 4) then
    raise exception 'INVALID_REVIEW_DECISION' using errcode = '22023';
  end if;

  perform public.qnr_expire_orders();
  select * into payment_row from public.qnr_manual_payments where id = p_payment_id for update;
  if not found or payment_row.status <> 'pending' then
    return jsonb_build_object('status', coalesce(payment_row.status, 'not_found'));
  end if;
  select * into order_row from public.qnr_orders where id = payment_row.order_id for update;
  if order_row.status not in ('awaiting_payment', 'payment_review') then
    return jsonb_build_object('status', order_row.status, 'order_id', order_row.id);
  end if;

  update public.qnr_manual_payments
    set status = p_decision, review_reason = nullif(trim(p_reason), ''), reviewed_by = p_actor_id, reviewed_at = now()
    where id = p_payment_id;
  if p_decision = 'approved' then
    update public.qnr_orders set status = 'paid' where id = order_row.id;
  else
    update public.qnr_orders set status = 'payment_rejected' where id = order_row.id;
    for order_line in select product_id, quantity from public.qnr_order_items where order_id = order_row.id loop
      update public.qnr_products set inventory_count = inventory_count + order_line.quantity where id = order_line.product_id;
    end loop;
  end if;
  insert into public.qnr_order_events (order_id, actor_id, event_type, reason, details)
    values (order_row.id, p_actor_id, p_decision, nullif(trim(p_reason), ''), jsonb_build_object('payment_id', p_payment_id));
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, reason, details)
    values (p_actor_id, 'review_' || p_decision, 'qnr_manual_payments', p_payment_id::text, nullif(trim(p_reason), ''), jsonb_build_object('order_id', order_row.id));
  return jsonb_build_object('status', p_decision, 'order_id', order_row.id);
end;
$$;
revoke all on function public.qnr_review_payment(uuid, uuid, text, text) from public, anon, authenticated;
grant execute on function public.qnr_review_payment(uuid, uuid, text, text) to service_role;
