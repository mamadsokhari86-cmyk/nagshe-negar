create table public.qnr_course_lesson_progress (
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id uuid not null references public.qnr_course_lessons(id) on delete cascade,
  bookmarked boolean not null default false,
  note text not null default '' check (length(note) <= 2000),
  last_position_seconds integer not null default 0 check (last_position_seconds between 0 and 7200),
  completed_at timestamptz,
  updated_at timestamptz not null default now(),
  primary key (user_id, lesson_id)
);

create index qnr_course_lesson_progress_user_recent_idx
  on public.qnr_course_lesson_progress (user_id, updated_at desc);

create trigger qnr_course_lesson_progress_touch_updated_at
  before update on public.qnr_course_lesson_progress
  for each row execute function public.qnr_touch_updated_at();

alter table public.qnr_course_lesson_progress enable row level security;

create policy qnr_course_lesson_progress_read_own
  on public.qnr_course_lesson_progress for select to authenticated
  using (user_id = (select auth.uid()));

create policy qnr_course_lesson_progress_insert_accessible
  on public.qnr_course_lesson_progress for insert to authenticated
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.qnr_course_lessons lesson
      where lesson.id = lesson_id and lesson.is_published
    )
  );

create policy qnr_course_lesson_progress_update_accessible
  on public.qnr_course_lesson_progress for update to authenticated
  using (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.qnr_course_lessons lesson
      where lesson.id = lesson_id and lesson.is_published
    )
  )
  with check (
    user_id = (select auth.uid())
    and exists (
      select 1 from public.qnr_course_lessons lesson
      where lesson.id = lesson_id and lesson.is_published
    )
  );

create policy qnr_course_lesson_progress_delete_own
  on public.qnr_course_lesson_progress for delete to authenticated
  using (user_id = (select auth.uid()));

revoke all on public.qnr_course_lesson_progress from anon, authenticated;
grant select, insert, delete on public.qnr_course_lesson_progress to authenticated;
grant update(bookmarked, note, last_position_seconds, completed_at)
  on public.qnr_course_lesson_progress to authenticated;

comment on table public.qnr_course_lesson_progress is
  'Private per-user course lesson progress, bookmarks, and notes.';
