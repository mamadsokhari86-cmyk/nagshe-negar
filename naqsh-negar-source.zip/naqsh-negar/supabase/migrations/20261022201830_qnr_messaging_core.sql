begin;

alter table public.qnr_profiles
  add column chat_handle text,
  add column allow_direct_messages boolean not null default false,
  add constraint qnr_profiles_chat_handle_check
    check (chat_handle is null or chat_handle ~ '^[a-z0-9_]{3,24}$');
create unique index qnr_profiles_chat_handle_unique
  on public.qnr_profiles (lower(chat_handle)) where chat_handle is not null;
grant update (chat_handle, allow_direct_messages) on public.qnr_profiles to authenticated;

create table public.qnr_chat_rooms (
  id uuid primary key default gen_random_uuid(),
  room_type text not null check (room_type in ('topic', 'direct', 'course_qa')),
  slug text,
  title text not null check (length(trim(title)) between 1 and 160),
  course_id uuid references public.qnr_courses(id) on delete cascade,
  owner_id uuid references auth.users(id) on delete cascade,
  teacher_id uuid references auth.users(id) on delete set null,
  direct_user_a uuid references auth.users(id) on delete cascade,
  direct_user_b uuid references auth.users(id) on delete cascade,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (direct_user_a, direct_user_b),
  unique (course_id, owner_id),
  check (
    (room_type = 'topic' and slug is not null and course_id is null and owner_id is null and teacher_id is null and direct_user_a is null and direct_user_b is null)
    or (room_type = 'direct' and slug is null and course_id is null and owner_id is null and teacher_id is null and direct_user_a is not null and direct_user_b is not null and direct_user_a < direct_user_b)
    or (room_type = 'course_qa' and slug is null and course_id is not null and owner_id is not null and direct_user_a is null and direct_user_b is null)
  )
);
create unique index qnr_chat_rooms_topic_slug_unique on public.qnr_chat_rooms (slug) where room_type = 'topic';
create index qnr_chat_rooms_owner_recent_idx on public.qnr_chat_rooms (owner_id, updated_at desc) where room_type = 'course_qa';
create index qnr_chat_rooms_teacher_recent_idx on public.qnr_chat_rooms (teacher_id, updated_at desc) where room_type = 'course_qa';

create table public.qnr_chat_room_members (
  room_id uuid not null references public.qnr_chat_rooms(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  member_role text not null default 'member' check (member_role in ('owner', 'teacher', 'student', 'member')),
  status text not null default 'active' check (status in ('active', 'muted', 'banned', 'removed')),
  muted_until timestamptz,
  banned_until timestamptz,
  moderation_reason text,
  joined_at timestamptz not null default now(),
  last_read_at timestamptz,
  primary key (room_id, user_id),
  check (moderation_reason is null or length(moderation_reason) <= 500)
);
create index qnr_chat_room_members_user_idx on public.qnr_chat_room_members (user_id, status, room_id);

create table public.qnr_chat_messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.qnr_chat_rooms(id) on delete cascade,
  sender_id uuid not null references auth.users(id) on delete cascade,
  body text not null default '',
  image_path text,
  client_nonce uuid not null,
  is_hidden boolean not null default false,
  hidden_at timestamptz,
  hidden_by uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (sender_id, client_nonce),
  check (length(body) <= 5000),
  check (body !~ '[[:cntrl:]]' or replace(replace(body, E'\\n', ''), E'\\t', '') !~ '[[:cntrl:]]'),
  check (nullif(trim(body), '') is not null or image_path is not null),
  check (image_path is null or image_path ~ '^[0-9a-f-]{36}/[0-9a-f-]{36}[.](jpg|jpeg|png|webp)$')
);
create index qnr_chat_messages_room_recent_idx on public.qnr_chat_messages (room_id, created_at desc, id desc);
create index qnr_chat_messages_sender_recent_idx on public.qnr_chat_messages (sender_id, created_at desc);

create table public.qnr_course_teachers (
  course_id uuid primary key references public.qnr_courses(id) on delete cascade,
  teacher_id uuid not null references auth.users(id) on delete cascade,
  assigned_by uuid references auth.users(id) on delete set null,
  assigned_at timestamptz not null default now()
);
create index qnr_course_teachers_teacher_idx on public.qnr_course_teachers (teacher_id, course_id);

create table qnr_private.qnr_chat_blocks (
  user_id uuid not null references auth.users(id) on delete cascade,
  blocked_user_id uuid not null references auth.users(id) on delete cascade,
  created_at timestamptz not null default now(),
  primary key (user_id, blocked_user_id),
  check (user_id <> blocked_user_id)
);

create table qnr_private.qnr_chat_reports (
  id uuid primary key default gen_random_uuid(),
  message_id uuid not null references public.qnr_chat_messages(id) on delete cascade,
  room_id uuid not null references public.qnr_chat_rooms(id) on delete cascade,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reason text not null check (reason in ('harassment', 'spam', 'privacy', 'unsafe', 'other')),
  description text not null default '' check (length(description) <= 500),
  status text not null default 'open' check (status in ('open', 'resolved', 'dismissed')),
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  resolution_note text,
  created_at timestamptz not null default now(),
  unique (reporter_id, message_id)
);
create index qnr_chat_reports_open_recent_idx on qnr_private.qnr_chat_reports (created_at desc) where status = 'open';

create table qnr_private.qnr_chat_upload_events (
  user_id uuid not null references auth.users(id) on delete cascade,
  object_path text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, object_path)
);
create index qnr_chat_upload_events_recent_idx on qnr_private.qnr_chat_upload_events (user_id, created_at desc);

create table qnr_private.qnr_chat_upload_tickets (
  object_path text primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  room_id uuid not null references public.qnr_chat_rooms(id) on delete cascade,
  client_nonce uuid not null,
  consumed_message_id uuid references public.qnr_chat_messages(id) on delete set null,
  created_at timestamptz not null default now(),
  unique (user_id, client_nonce)
);
alter table qnr_private.qnr_chat_blocks enable row level security;
alter table qnr_private.qnr_chat_reports enable row level security;
alter table qnr_private.qnr_chat_upload_events enable row level security;
alter table qnr_private.qnr_chat_upload_tickets enable row level security;

alter table public.qnr_chat_rooms enable row level security;
alter table public.qnr_chat_room_members enable row level security;
alter table public.qnr_chat_messages enable row level security;
alter table public.qnr_course_teachers enable row level security;
insert into public.qnr_chat_rooms (room_type, slug, title)
values
  ('topic', 'starting-together', 'شروع و دورهمی'),
  ('topic', 'design-and-cutting', 'طرح و برش'),
  ('topic', 'stitching-and-finishing', 'دوخت و تجربه');

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('qnr-chat', 'qnr-chat', false, 10485760, array['image/jpeg','image/png','image/webp']::text[])
on conflict (id) do update set public = false, file_size_limit = 10485760,
  allowed_mime_types = array['image/jpeg','image/png','image/webp']::text[];

alter table public.qnr_notifications drop constraint qnr_notifications_notification_type_check;
alter table public.qnr_notifications add constraint qnr_notifications_notification_type_check
  check (notification_type = any (array['support_new','support_reply','order_update','payment_update','learning_update','gallery_review','chat_message','course_question','system']::text[]));

create or replace function qnr_private.qnr_chat_is_moderator()
returns boolean language sql stable security definer set search_path = '' as $function$
  select exists (
    select 1 from public.qnr_user_roles r
    where r.user_id = (select auth.uid()) and r.role in ('admin','moderator')
  );
$function$;

create or replace function qnr_private.qnr_chat_can_read(p_room_id uuid)
returns boolean language sql stable security definer set search_path = '' as $function$
  select exists (
    select 1 from public.qnr_chat_room_members m
    where m.room_id = p_room_id and m.user_id = (select auth.uid())
      and (m.status in ('active','muted') or (m.status = 'banned' and m.banned_until <= now()))
  );
$function$;

create policy qnr_chat_messages_select_member on public.qnr_chat_messages
  for select to authenticated
  using (not is_hidden and qnr_private.qnr_chat_can_read(room_id));

create or replace function qnr_private.qnr_chat_can_read_object(p_bucket_id text, p_object_name text)
returns boolean language sql stable security definer set search_path = '' as $function$
  select p_bucket_id = 'qnr-chat' and exists (
    select 1 from public.qnr_chat_messages m
    where m.image_path = p_object_name and not m.is_hidden
      and qnr_private.qnr_chat_can_read(m.room_id)
  ) or (p_bucket_id = 'qnr-chat' and qnr_private.qnr_chat_is_moderator() and exists (
    select 1 from qnr_private.qnr_chat_reports r
    join public.qnr_chat_messages m on m.id = r.message_id
    where r.status = 'open' and m.image_path = p_object_name
  ));
$function$;

create or replace function qnr_private.qnr_chat_reserve_upload(p_object_name text)
returns boolean language plpgsql volatile security definer set search_path = '' as $function$
declare
  actor uuid := (select auth.uid());
  room_text text;
  room_key uuid;
  recent_count integer;
begin
  if actor is null or p_object_name !~ '^[0-9a-f-]{36}/[0-9a-f-]{36}[.](jpg|jpeg|png|webp)$' then return false; end if;
  room_text := split_part(p_object_name, '/', 1);
  begin room_key := room_text::uuid; exception when others then return false; end;
  if not exists (select 1 from public.qnr_chat_room_members m where m.room_id = room_key and m.user_id = actor and m.status = 'active') then return false; end if;
  perform pg_advisory_xact_lock(hashtextextended(actor::text || ':chat-upload', 0));
  if exists (select 1 from qnr_private.qnr_chat_upload_events e where e.user_id = actor and e.object_path = p_object_name) then return true; end if;
  select count(*) into recent_count from qnr_private.qnr_chat_upload_events e where e.user_id = actor and e.created_at > now() - interval '24 hours';
  if recent_count >= 10 then return false; end if;
  insert into qnr_private.qnr_chat_upload_events (user_id, object_path) values (actor, p_object_name);
  return true;
end;
$function$;

create or replace function qnr_private.qnr_chat_send_message_secure(p_room_id uuid, p_body text, p_client_nonce uuid, p_image_path text default null)
returns uuid language plpgsql security definer set search_path = '' as $function$
declare
  actor uuid := (select auth.uid());
  clean_body text := trim(replace(coalesce(p_body, ''), E'\\r\\n', E'\\n'));
  room_kind text;
  member_status text;
  existing public.qnr_chat_messages%rowtype;
  message_id uuid;
  recipient_id uuid;
  recent_count integer;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if p_client_nonce is null then raise exception 'INVALID_NONCE' using errcode = '22023'; end if;
  if length(clean_body) > 5000 then raise exception 'MESSAGE_TOO_LONG' using errcode = '22023'; end if;
  if replace(replace(clean_body, E'\\n', ''), E'\\t', '') ~ '[[:cntrl:]]' then raise exception 'INVALID_MESSAGE_CHARACTERS' using errcode = '22023'; end if;
  if clean_body = '' and p_image_path is null then raise exception 'EMPTY_MESSAGE' using errcode = '22023'; end if;
  select * into existing from public.qnr_chat_messages m where m.sender_id = actor and m.client_nonce = p_client_nonce;
  if found then
    if existing.room_id = p_room_id and existing.body = clean_body and existing.image_path is not distinct from p_image_path then return existing.id; end if;
    raise exception 'IDEMPOTENCY_CONFLICT' using errcode = '23505';
  end if;
  select r.room_type, m.status into room_kind, member_status
    from public.qnr_chat_rooms r join public.qnr_chat_room_members m on m.room_id = r.id
    where r.id = p_room_id and r.is_active and m.user_id = actor;
  if not found or member_status = 'removed' then raise exception 'ROOM_ACCESS_DENIED' using errcode = '42501'; end if;
  if member_status = 'banned' then
    if exists (select 1 from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id=actor and (m.banned_until is null or m.banned_until>now())) then
      raise exception 'MEMBER_BANNED' using errcode = '42501';
    end if;
    update public.qnr_chat_room_members set status='active',banned_until=null,moderation_reason=null where room_id=p_room_id and user_id=actor;
    member_status := 'active';
  end if;
  if member_status = 'muted' then
    if exists (select 1 from public.qnr_chat_room_members m where m.room_id = p_room_id and m.user_id = actor and m.muted_until > now()) then
      raise exception 'MEMBER_MUTED' using errcode = '42501';
    end if;
  end if;
  if room_kind = 'direct' and exists (
    select 1 from public.qnr_chat_room_members other
    join qnr_private.qnr_chat_blocks b on
      ((b.user_id = other.user_id and b.blocked_user_id = actor) or (b.user_id=actor and b.blocked_user_id=other.user_id))
    where other.room_id = p_room_id and other.user_id <> actor
  ) then raise exception 'DIRECT_MESSAGE_BLOCKED' using errcode = '42501'; end if;
  if p_image_path is not null then
    if p_image_path !~ ('^' || p_room_id::text || '/[0-9a-f-]{36}\\.(jpg|jpeg|png|webp)$') or not exists (
      select 1 from qnr_private.qnr_chat_upload_tickets t
      where t.object_path = p_image_path and t.user_id = actor and t.room_id = p_room_id and t.client_nonce = p_client_nonce
    ) then raise exception 'UPLOAD_NOT_REGISTERED' using errcode = '42501'; end if;
  end if;
  perform pg_advisory_xact_lock(hashtextextended(actor::text || ':chat-message', 0));
  select count(*) into recent_count from public.qnr_chat_messages m where m.sender_id = actor and m.created_at > now() - interval '5 minutes';
  if recent_count >= 30 then raise exception 'MESSAGE_RATE_LIMIT' using errcode = 'P0001'; end if;
  insert into public.qnr_chat_messages (room_id, sender_id, body, image_path, client_nonce)
  values (p_room_id, actor, clean_body, p_image_path, p_client_nonce)
  returning id into message_id;
  update public.qnr_chat_room_members set last_read_at = now() where room_id = p_room_id and user_id = actor;
  update public.qnr_chat_rooms set updated_at = now() where id = p_room_id;
  if p_image_path is not null then
    update qnr_private.qnr_chat_upload_tickets set consumed_message_id = message_id where object_path = p_image_path and user_id = actor;
  end if;
  begin
    if room_kind = 'direct' then
      insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
      select m.user_id, 'chat_message', 'پیام تازه‌ای داری', 'یک پیام خصوصی تازه برایت رسیده است.', '/community?room=' || p_room_id::text
      from public.qnr_chat_room_members m where m.room_id = p_room_id and m.user_id <> actor and m.status in ('active','muted');
    elsif room_kind = 'course_qa' then
      select m.user_id into recipient_id from public.qnr_chat_room_members m
        where m.room_id = p_room_id and m.user_id <> actor and m.member_role in ('teacher','student') and m.status = 'active' limit 1;
      if recipient_id is not null then
        insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
        values (recipient_id, 'course_question', 'پیام تازه دربارهٔ دوره', 'یک پیام تازه در گفت‌وگوی دوره ثبت شده است.', '/community?room=' || p_room_id::text);
      end if;
    end if;
  exception when others then
    null;
  end;
  return message_id;
end;
$function$;

create or replace function qnr_private.qnr_chat_list_rooms_secure()
returns table (id uuid, room_type text, title text, slug text, course_id uuid, member_status text, other_display_name text, other_chat_handle text, last_message text, last_message_at timestamptz, unread_count bigint)
language plpgsql stable security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid());
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  return query
  select r.id, r.room_type,
    case when r.room_type = 'direct' then coalesce(other_profile.display_name, other_profile.chat_handle, 'گفت‌وگوی خصوصی')
      when r.room_type = 'course_qa' then coalesce(c.title, r.title)
      else r.title end,
    r.slug, r.course_id, mine.status, other_profile.display_name, other_profile.chat_handle,
    case when mine.user_id is null then null else last_msg.preview end,
    last_msg.created_at,
    case when mine.user_id is null then 0 else coalesce(unread.count, 0) end
  from public.qnr_chat_rooms r
  left join public.qnr_chat_room_members mine on mine.room_id = r.id and mine.user_id = actor
  left join public.qnr_courses c on c.id = r.course_id
  left join lateral (
    select p.display_name, p.chat_handle from public.qnr_chat_room_members m
    join public.qnr_profiles p on p.id = m.user_id
    where m.room_id = r.id and m.user_id <> actor and r.room_type in ('direct','course_qa')
    order by case when m.member_role = 'teacher' then 0 else 1 end limit 1
  ) other_profile on true
  left join lateral (
    select left(coalesce(nullif(m.body,''), '📷 تصویر'), 140) as preview, m.created_at
    from public.qnr_chat_messages m where m.room_id = r.id and not m.is_hidden
    order by m.created_at desc, m.id desc limit 1
  ) last_msg on true
  left join lateral (
    select count(*)::bigint as count from public.qnr_chat_messages m
    where m.room_id = r.id and m.sender_id <> actor and not m.is_hidden
      and m.created_at > coalesce(mine.last_read_at, mine.joined_at)
  ) unread on true
  where r.is_active and (r.room_type = 'topic' or (mine.user_id is not null and mine.status <> 'removed'))
  order by case when r.room_type = 'topic' then 1 else 0 end, coalesce(last_msg.created_at, r.updated_at) desc;
end;
$function$;

create or replace function qnr_private.qnr_chat_directory_secure(p_query text)
returns table (user_id uuid, chat_handle text, display_name text)
language plpgsql stable security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); term text := trim(coalesce(p_query,''));
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if length(term) < 2 then return; end if;
  term := left(replace(replace(replace(term, E'\\', E'\\\\'), '%', E'\\%'), '_', E'\\_'), 48);
  return query
  select p.id, p.chat_handle, p.display_name
  from public.qnr_profiles p
  where p.id <> actor and p.allow_direct_messages and p.chat_handle is not null
    and (p.chat_handle ilike '%' || term || '%' escape E'\\' or p.display_name ilike '%' || term || '%' escape E'\\')
    and not exists (select 1 from qnr_private.qnr_chat_blocks b where b.user_id = actor and b.blocked_user_id = p.id)
    and not exists (select 1 from qnr_private.qnr_chat_blocks b where b.user_id = p.id and b.blocked_user_id = actor)
  order by p.chat_handle limit 25;
end;
$function$;

create or replace function qnr_private.qnr_chat_join_room_secure(p_room_id uuid)
returns uuid language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); kind text; room_active boolean;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  select r.room_type, r.is_active into kind, room_active from public.qnr_chat_rooms r where r.id = p_room_id;
  if not found or kind <> 'topic' or not room_active then raise exception 'TOPIC_ROOM_NOT_AVAILABLE' using errcode = '22023'; end if;
  insert into public.qnr_chat_room_members (room_id,user_id,member_role,status)
  values (p_room_id,actor,'member','active')
  on conflict (room_id,user_id) do update set status='active', moderation_reason=null
    where public.qnr_chat_room_members.status='removed';
  if exists (select 1 from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id=actor and m.status='banned' and coalesce(m.banned_until, 'infinity') > now()) then
    raise exception 'MEMBER_BANNED' using errcode = '42501';
  end if;
  return p_room_id;
end;
$function$;

create or replace function qnr_private.qnr_chat_start_direct_secure(p_recipient_id uuid)
returns uuid language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); recipient public.qnr_profiles%rowtype; room_key uuid;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if p_recipient_id is null or p_recipient_id=actor then raise exception 'INVALID_RECIPIENT' using errcode = '22023'; end if;
  select * into recipient from public.qnr_profiles p where p.id=p_recipient_id;
  if not found or not recipient.allow_direct_messages or recipient.chat_handle is null then raise exception 'DIRECT_MESSAGE_NOT_ALLOWED' using errcode = '42501'; end if;
  if exists (select 1 from qnr_private.qnr_chat_blocks b where (b.user_id=actor and b.blocked_user_id=p_recipient_id) or (b.user_id=p_recipient_id and b.blocked_user_id=actor)) then
    raise exception 'DIRECT_MESSAGE_BLOCKED' using errcode = '42501';
  end if;
  insert into public.qnr_chat_rooms (room_type,title,direct_user_a,direct_user_b)
    values ('direct','گفت‌وگوی خصوصی',least(actor,p_recipient_id),greatest(actor,p_recipient_id))
    on conflict (direct_user_a,direct_user_b) do nothing;
  select r.id into room_key from public.qnr_chat_rooms r where r.room_type='direct' and r.direct_user_a=least(actor,p_recipient_id) and r.direct_user_b=greatest(actor,p_recipient_id);
  insert into public.qnr_chat_room_members (room_id,user_id,member_role,status) values
    (room_key,actor,'member','active'), (room_key,p_recipient_id,'member','active')
  on conflict (room_id,user_id) do update set status='active' where public.qnr_chat_room_members.status='removed';
  return room_key;
end;
$function$;

create or replace function qnr_private.qnr_chat_ask_course_question_secure(p_course_id uuid,p_body text,p_client_nonce uuid)
returns uuid language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); course_row public.qnr_courses%rowtype; teacher uuid; room_key uuid;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  select * into course_row from public.qnr_courses c where c.id=p_course_id and c.is_published;
  if not found then raise exception 'COURSE_NOT_AVAILABLE' using errcode = '22023'; end if;
  select ct.teacher_id into teacher from public.qnr_course_teachers ct join public.qnr_user_roles r on r.user_id=ct.teacher_id and r.role='teacher' where ct.course_id=p_course_id;
  if teacher is null then raise exception 'COURSE_TEACHER_NOT_ASSIGNED' using errcode = '22023'; end if;
  if coalesce(course_row.price_amount,0) > 0 and not exists (
    select 1 from public.qnr_course_entitlements e where e.course_id=p_course_id and e.user_id=actor and (e.expires_at is null or e.expires_at>now())
  ) then raise exception 'COURSE_ACCESS_REQUIRED' using errcode = '42501'; end if;
  insert into public.qnr_chat_rooms (room_type,title,course_id,owner_id,teacher_id)
    values ('course_qa',left(course_row.title || ' · پرسش از مدرس',160),p_course_id,actor,teacher)
    on conflict (course_id,owner_id) do nothing;
  select r.id into room_key from public.qnr_chat_rooms r where r.room_type='course_qa' and r.course_id=p_course_id and r.owner_id=actor for update;
  update public.qnr_chat_rooms set teacher_id=teacher,is_active=true where id=room_key;
  update public.qnr_chat_room_members set status='removed' where room_id=room_key and member_role='teacher' and user_id<>teacher and status<>'removed';
  insert into public.qnr_chat_room_members (room_id,user_id,member_role,status) values
    (room_key,actor,'student','active'),(room_key,teacher,'teacher','active')
  on conflict (room_id,user_id) do update set status='active' where public.qnr_chat_room_members.status in ('removed','banned');
  perform qnr_private.qnr_chat_send_message_secure(room_key,p_body,p_client_nonce,null);
  return room_key;
end;
$function$;

create or replace function qnr_private.qnr_chat_history_secure(p_room_id uuid,p_before_at timestamptz default null,p_before_id uuid default null,p_limit integer default 30)
returns table (id uuid,room_id uuid,sender_id uuid,sender_display_name text,sender_chat_handle text,body text,image_path text,created_at timestamptz,is_mine boolean)
language plpgsql stable security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); page_size integer := greatest(1,least(coalesce(p_limit,30),30));
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if not qnr_private.qnr_chat_can_read(p_room_id) then raise exception 'ROOM_ACCESS_DENIED' using errcode = '42501'; end if;
  return query
  select page.id,page.room_id,page.sender_id,coalesce(p.display_name,'عضو'),p.chat_handle,page.body,page.image_path,page.created_at,page.sender_id=actor
  from (
    select m.id,m.room_id,m.sender_id,m.body,m.image_path,m.created_at
    from public.qnr_chat_messages m
    where m.room_id=p_room_id and not m.is_hidden
      and (p_before_at is null or m.created_at<p_before_at or (m.created_at=p_before_at and m.id<p_before_id))
    order by m.created_at desc,m.id desc limit page_size
  ) page
  left join public.qnr_profiles p on p.id=page.sender_id
  order by page.created_at,page.id;
end;
$function$;

create or replace function qnr_private.qnr_chat_mark_read_secure(p_room_id uuid)
returns boolean language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid());
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  update public.qnr_chat_room_members set last_read_at=now()
    where room_id=p_room_id and user_id=actor and status in ('active','muted');
  return found;
end;
$function$;

create or replace function qnr_private.qnr_chat_block_user_secure(p_user_id uuid)
returns void language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid());
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if p_user_id is null or p_user_id=actor or not exists(select 1 from auth.users u where u.id=p_user_id) then raise exception 'INVALID_USER' using errcode = '22023'; end if;
  insert into qnr_private.qnr_chat_blocks (user_id,blocked_user_id) values(actor,p_user_id) on conflict do nothing;
end;
$function$;

create or replace function qnr_private.qnr_chat_unblock_user_secure(p_user_id uuid)
returns void language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid());
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  delete from qnr_private.qnr_chat_blocks where user_id=actor and blocked_user_id=p_user_id;
end;
$function$;

create or replace function qnr_private.qnr_chat_report_message_secure(p_message_id uuid,p_reason text,p_description text default '')
returns uuid language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); room_key uuid; report_key uuid; clean_description text := trim(coalesce(p_description,''));
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if p_reason not in ('harassment','spam','privacy','unsafe','other') or length(clean_description)>500 then raise exception 'INVALID_REPORT' using errcode = '22023'; end if;
  select m.room_id into room_key from public.qnr_chat_messages m where m.id=p_message_id and not m.is_hidden and m.sender_id<>actor;
  if room_key is null or not qnr_private.qnr_chat_can_read(room_key) then raise exception 'MESSAGE_NOT_REPORTABLE' using errcode = '42501'; end if;
  insert into qnr_private.qnr_chat_reports (message_id,room_id,reporter_id,reason,description)
    values(p_message_id,room_key,actor,p_reason,clean_description) returning id into report_key;
  return report_key;
exception when unique_violation then raise exception 'DUPLICATE_REPORT' using errcode = '23505';
end;
$function$;

create or replace function qnr_private.qnr_chat_admin_reports_secure()
returns table (report_id uuid,message_id uuid,room_id uuid,reporter_id uuid,reason text,description text,status text,created_at timestamptz,message_body text,image_path text,sender_id uuid,sender_display_name text)
language plpgsql stable security definer set search_path = '' as $function$
begin
  if (select auth.uid()) is null or not qnr_private.qnr_chat_is_moderator() then raise exception 'MODERATOR_REQUIRED' using errcode = '42501'; end if;
  return query
    select r.id,r.message_id,r.room_id,r.reporter_id,r.reason,r.description,r.status,r.created_at,m.body,m.image_path,m.sender_id,coalesce(p.display_name,'عضو')
    from qnr_private.qnr_chat_reports r join public.qnr_chat_messages m on m.id=r.message_id
    left join public.qnr_profiles p on p.id=m.sender_id
    where r.status='open' order by r.created_at asc limit 100;
end;
$function$;

create or replace function qnr_private.qnr_chat_resolve_report_secure(p_report_id uuid,p_status text,p_note text default '',p_hide_message boolean default false)
returns void language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); report_row qnr_private.qnr_chat_reports%rowtype; clean_note text := left(trim(coalesce(p_note,'')),500);
begin
  if actor is null or not qnr_private.qnr_chat_is_moderator() then raise exception 'MODERATOR_REQUIRED' using errcode = '42501'; end if;
  if p_status not in ('resolved','dismissed') then raise exception 'INVALID_REPORT_STATUS' using errcode = '22023'; end if;
  select * into report_row from qnr_private.qnr_chat_reports r where r.id=p_report_id and r.status='open' for update;
  if not found then raise exception 'REPORT_NOT_OPEN' using errcode = '22023'; end if;
  update qnr_private.qnr_chat_reports set status=p_status,reviewed_by=actor,reviewed_at=now(),resolution_note=clean_note where id=p_report_id;
  if p_hide_message then update public.qnr_chat_messages set is_hidden=true,hidden_at=now(),hidden_by=actor where id=report_row.message_id; end if;
  insert into public.qnr_audit_log(actor_id,action,subject_type,subject_id,details)
    values(actor,case when p_hide_message then 'hide_reported_message' else 'resolve_report' end,'qnr_chat_reports',p_report_id::text,jsonb_build_object('status',p_status,'hide_message',p_hide_message,'note',clean_note));
end;
$function$;

create or replace function qnr_private.qnr_chat_moderate_member_secure(p_room_id uuid,p_user_id uuid,p_action text,p_duration_minutes integer default 60,p_reason text default '')
returns void language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); next_status text; clean_reason text := left(trim(coalesce(p_reason,'')),500);
begin
  if actor is null or not qnr_private.qnr_chat_is_moderator() then raise exception 'MODERATOR_REQUIRED' using errcode = '42501'; end if;
  if p_user_id=actor then raise exception 'CANNOT_MODERATE_SELF' using errcode = '22023'; end if;
  if p_action not in ('mute','ban','unmute','unban','remove','restore') then raise exception 'INVALID_MODERATION_ACTION' using errcode = '22023'; end if;
  if p_action in ('mute','ban') and (p_duration_minutes is null or p_duration_minutes<5 or p_duration_minutes>10080) then raise exception 'INVALID_DURATION' using errcode = '22023'; end if;
  if not exists(select 1 from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id=p_user_id) then raise exception 'MEMBER_NOT_FOUND' using errcode = 'P0002'; end if;
  next_status := case p_action when 'mute' then 'muted' when 'ban' then 'banned' when 'remove' then 'removed' else 'active' end;
  update public.qnr_chat_room_members set status=next_status,
    muted_until=case when p_action='mute' then now()+make_interval(mins=>p_duration_minutes) else null end,
    banned_until=case when p_action='ban' then now()+make_interval(mins=>p_duration_minutes) else null end,
    moderation_reason=case when p_action in ('mute','ban','remove') then clean_reason else null end
    where room_id=p_room_id and user_id=p_user_id;
  insert into public.qnr_audit_log(actor_id,action,subject_type,subject_id,details)
    values(actor,p_action,'qnr_chat_room_members',p_room_id::text || ':' || p_user_id::text,jsonb_build_object('duration_minutes',case when p_action in ('mute','ban') then p_duration_minutes else null end,'reason',clean_reason));
end;
$function$;

create or replace function qnr_private.qnr_chat_my_capabilities_secure()
returns table (is_admin boolean,is_moderator boolean,is_teacher boolean)
language sql stable security definer set search_path = '' as $function$
  select qnr_private.qnr_is_admin(),qnr_private.qnr_chat_is_moderator(),exists(
    select 1 from public.qnr_user_roles r where r.user_id=(select auth.uid()) and r.role='teacher'
  );
$function$;

create or replace function qnr_private.qnr_chat_admin_people_secure()
returns table (user_id uuid,display_name text,chat_handle text,is_teacher boolean)
language plpgsql stable security definer set search_path = '' as $function$
begin
  if (select auth.uid()) is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  return query select p.id,p.display_name,p.chat_handle,exists(select 1 from public.qnr_user_roles r where r.user_id=p.id and r.role='teacher')
    from public.qnr_profiles p order by p.display_name nulls last limit 200;
end;
$function$;

create or replace function qnr_private.qnr_chat_admin_courses_secure()
returns table (course_id uuid,title text,slug text,is_published boolean,teacher_id uuid,teacher_name text)
language plpgsql stable security definer set search_path = '' as $function$
begin
  if (select auth.uid()) is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  return query select c.id,c.title,c.slug,c.is_published,ct.teacher_id,p.display_name
    from public.qnr_courses c left join public.qnr_course_teachers ct on ct.course_id=c.id
    left join public.qnr_profiles p on p.id=ct.teacher_id order by c.title limit 200;
end;
$function$;

create or replace function qnr_private.qnr_chat_set_teacher_role_secure(p_user_id uuid,p_enabled boolean)
returns void language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid());
begin
  if actor is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  if p_user_id is null or not exists(select 1 from auth.users u where u.id=p_user_id) then raise exception 'USER_NOT_FOUND' using errcode = 'P0002'; end if;
  if p_enabled then
    insert into public.qnr_user_roles(user_id,role,granted_by) values(p_user_id,'teacher',actor) on conflict(user_id,role) do nothing;
  else
    delete from public.qnr_course_teachers where teacher_id=p_user_id;
    update public.qnr_chat_room_members set status='removed' where user_id=p_user_id and member_role='teacher' and room_id in (select r.id from public.qnr_chat_rooms r where r.room_type='course_qa');
    update public.qnr_chat_rooms set teacher_id=null where teacher_id=p_user_id and room_type='course_qa';
    delete from public.qnr_user_roles where user_id=p_user_id and role='teacher';
  end if;
  insert into public.qnr_audit_log(actor_id,action,subject_type,subject_id,details)
    values(actor,case when p_enabled then 'grant_teacher' else 'revoke_teacher' end,'qnr_user_roles',p_user_id::text,'{}'::jsonb);
end;
$function$;

create or replace function qnr_private.qnr_chat_assign_teacher_secure(p_course_id uuid,p_teacher_id uuid default null)
returns void language plpgsql security definer set search_path = '' as $function$
declare actor uuid := (select auth.uid()); old_teacher uuid;
begin
  if actor is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  if not exists(select 1 from public.qnr_courses c where c.id=p_course_id) then raise exception 'COURSE_NOT_FOUND' using errcode = 'P0002'; end if;
  if p_teacher_id is not null and not exists(select 1 from public.qnr_user_roles r where r.user_id=p_teacher_id and r.role='teacher') then raise exception 'TEACHER_ROLE_REQUIRED' using errcode = '22023'; end if;
  select teacher_id into old_teacher from public.qnr_course_teachers where course_id=p_course_id;
  if p_teacher_id is null then delete from public.qnr_course_teachers where course_id=p_course_id;
  else insert into public.qnr_course_teachers(course_id,teacher_id,assigned_by,assigned_at) values(p_course_id,p_teacher_id,actor,now())
    on conflict(course_id) do update set teacher_id=excluded.teacher_id,assigned_by=excluded.assigned_by,assigned_at=excluded.assigned_at;
  end if;
  if old_teacher is not null and old_teacher is distinct from p_teacher_id then
    update public.qnr_chat_room_members set status='removed' where member_role='teacher' and user_id=old_teacher and room_id in (select r.id from public.qnr_chat_rooms r where r.course_id=p_course_id and r.room_type='course_qa');
  end if;
  if p_teacher_id is not null then
    update public.qnr_chat_rooms set teacher_id=p_teacher_id where course_id=p_course_id and room_type='course_qa';
  else
    update public.qnr_chat_rooms set teacher_id=null where course_id=p_course_id and room_type='course_qa';
  end if;
  insert into public.qnr_audit_log(actor_id,action,subject_type,subject_id,details)
    values(actor,'assign_teacher','qnr_courses',p_course_id::text,jsonb_build_object('teacher_id',p_teacher_id));
end;
$function$;

create or replace function qnr_private.qnr_chat_register_upload_ticket_secure(p_user_id uuid,p_room_id uuid,p_client_nonce uuid,p_object_path text)
returns uuid language plpgsql security definer set search_path = '' as $function$
declare linked_message uuid; object_owner text;
begin
  if auth.role() <> 'service_role' then raise exception 'SERVICE_ROLE_REQUIRED' using errcode = '42501'; end if;
  if p_user_id is null or p_client_nonce is null or p_object_path !~ ('^' || p_room_id::text || '/[0-9a-f-]{36}\\.(jpg|jpeg|png|webp)$') then raise exception 'INVALID_UPLOAD_TICKET' using errcode = '22023'; end if;
  select m.id into linked_message from public.qnr_chat_messages m where m.sender_id=p_user_id and m.client_nonce=p_client_nonce;
  if linked_message is not null then
    if exists(select 1 from public.qnr_chat_messages m where m.id=linked_message and m.room_id=p_room_id and m.image_path=p_object_path) then return linked_message; end if;
    raise exception 'IDEMPOTENCY_CONFLICT' using errcode = '23505';
  end if;
  if not exists(select 1 from public.qnr_chat_room_members m where m.room_id=p_room_id and m.user_id=p_user_id and m.status='active') then raise exception 'ROOM_ACCESS_DENIED' using errcode = '42501'; end if;
  select o.owner_id into object_owner from storage.objects o where o.bucket_id='qnr-chat' and o.name=p_object_path;
  if object_owner is null or object_owner<>p_user_id::text then raise exception 'UPLOAD_OBJECT_NOT_OWNED' using errcode = '42501'; end if;
  insert into qnr_private.qnr_chat_upload_tickets(object_path,user_id,room_id,client_nonce)
    values(p_object_path,p_user_id,p_room_id,p_client_nonce)
    on conflict(object_path) do update set client_nonce=excluded.client_nonce
      where qnr_private.qnr_chat_upload_tickets.user_id=excluded.user_id and qnr_private.qnr_chat_upload_tickets.room_id=excluded.room_id and qnr_private.qnr_chat_upload_tickets.consumed_message_id is null;
  if not found then raise exception 'UPLOAD_TICKET_CONFLICT' using errcode = '23505'; end if;
  return null;
end;
$function$;

create or replace function qnr_private.qnr_chat_delete_upload_ticket_secure(p_user_id uuid,p_object_path text)
returns boolean language plpgsql security definer set search_path = '' as $function$
begin
  if auth.role() <> 'service_role' then raise exception 'SERVICE_ROLE_REQUIRED' using errcode = '42501'; end if;
  if exists(select 1 from public.qnr_chat_messages m where m.image_path=p_object_path) then return false; end if;
  delete from qnr_private.qnr_chat_upload_tickets where object_path=p_object_path and user_id=p_user_id;
  return found;
end;
$function$;

create or replace function qnr_private.qnr_chat_touch_room()
returns trigger language plpgsql security definer set search_path = '' as $function$
begin
  update public.qnr_chat_rooms set updated_at=new.created_at where id=new.room_id;
  return new;
end;
$function$;
create trigger qnr_chat_messages_touch_room after insert on public.qnr_chat_messages
  for each row execute function qnr_private.qnr_chat_touch_room();

create or replace function public.qnr_chat_list_rooms()
returns table (id uuid,room_type text,title text,slug text,course_id uuid,member_status text,other_display_name text,other_chat_handle text,last_message text,last_message_at timestamptz,unread_count bigint)
language sql security invoker set search_path = '' as $$ select * from qnr_private.qnr_chat_list_rooms_secure() $$;
create or replace function public.qnr_chat_directory(p_query text)
returns table (user_id uuid,chat_handle text,display_name text)
language sql security invoker set search_path = '' as $$ select * from qnr_private.qnr_chat_directory_secure(p_query) $$;
create or replace function public.qnr_chat_join_room(p_room_id uuid)
returns uuid language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_join_room_secure(p_room_id) $$;
create or replace function public.qnr_chat_start_direct(p_recipient_id uuid)
returns uuid language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_start_direct_secure(p_recipient_id) $$;
create or replace function public.qnr_chat_ask_course_question(p_course_id uuid,p_body text,p_client_nonce uuid)
returns uuid language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_ask_course_question_secure(p_course_id,p_body,p_client_nonce) $$;
create or replace function public.qnr_chat_history(p_room_id uuid,p_before_at timestamptz default null,p_before_id uuid default null,p_limit integer default 30)
returns table (id uuid,room_id uuid,sender_id uuid,sender_display_name text,sender_chat_handle text,body text,image_path text,created_at timestamptz,is_mine boolean)
language sql security invoker set search_path = '' as $$ select * from qnr_private.qnr_chat_history_secure(p_room_id,p_before_at,p_before_id,p_limit) $$;
create or replace function public.qnr_chat_send_message(p_room_id uuid,p_body text,p_client_nonce uuid,p_image_path text default null)
returns uuid language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_send_message_secure(p_room_id,p_body,p_client_nonce,p_image_path) $$;
create or replace function public.qnr_chat_mark_read(p_room_id uuid)
returns boolean language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_mark_read_secure(p_room_id) $$;
create or replace function public.qnr_chat_block_user(p_user_id uuid)
returns void language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_block_user_secure(p_user_id) $$;
create or replace function public.qnr_chat_unblock_user(p_user_id uuid)
returns void language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_unblock_user_secure(p_user_id) $$;
create or replace function public.qnr_chat_report_message(p_message_id uuid,p_reason text,p_description text default '')
returns uuid language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_report_message_secure(p_message_id,p_reason,p_description) $$;
create or replace function public.qnr_chat_admin_reports()
returns table (report_id uuid,message_id uuid,room_id uuid,reporter_id uuid,reason text,description text,status text,created_at timestamptz,message_body text,image_path text,sender_id uuid,sender_display_name text)
language sql security invoker set search_path = '' as $$ select * from qnr_private.qnr_chat_admin_reports_secure() $$;
create or replace function public.qnr_chat_resolve_report(p_report_id uuid,p_status text,p_note text default '',p_hide_message boolean default false)
returns void language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_resolve_report_secure(p_report_id,p_status,p_note,p_hide_message) $$;
create or replace function public.qnr_chat_moderate_member(p_room_id uuid,p_user_id uuid,p_action text,p_duration_minutes integer default 60,p_reason text default '')
returns void language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_moderate_member_secure(p_room_id,p_user_id,p_action,p_duration_minutes,p_reason) $$;
create or replace function public.qnr_chat_my_capabilities()
returns table (is_admin boolean,is_moderator boolean,is_teacher boolean)
language sql security invoker set search_path = '' as $$ select * from qnr_private.qnr_chat_my_capabilities_secure() $$;
create or replace function public.qnr_chat_admin_people()
returns table (user_id uuid,display_name text,chat_handle text,is_teacher boolean)
language sql security invoker set search_path = '' as $$ select * from qnr_private.qnr_chat_admin_people_secure() $$;
create or replace function public.qnr_chat_admin_courses()
returns table (course_id uuid,title text,slug text,is_published boolean,teacher_id uuid,teacher_name text)
language sql security invoker set search_path = '' as $$ select * from qnr_private.qnr_chat_admin_courses_secure() $$;
create or replace function public.qnr_chat_set_teacher_role(p_user_id uuid,p_enabled boolean)
returns void language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_set_teacher_role_secure(p_user_id,p_enabled) $$;
create or replace function public.qnr_chat_assign_teacher(p_course_id uuid,p_teacher_id uuid default null)
returns void language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_assign_teacher_secure(p_course_id,p_teacher_id) $$;
create or replace function public.qnr_chat_register_upload_ticket(p_user_id uuid,p_room_id uuid,p_client_nonce uuid,p_object_path text)
returns uuid language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_register_upload_ticket_secure(p_user_id,p_room_id,p_client_nonce,p_object_path) $$;
create or replace function public.qnr_chat_delete_upload_ticket(p_user_id uuid,p_object_path text)
returns boolean language sql security invoker set search_path = '' as $$ select qnr_private.qnr_chat_delete_upload_ticket_secure(p_user_id,p_object_path) $$;

revoke all on public.qnr_chat_rooms,public.qnr_chat_room_members,public.qnr_chat_messages,public.qnr_course_teachers from anon,authenticated,service_role;
grant select (id,room_id,sender_id,body,image_path,client_nonce,is_hidden,hidden_at,hidden_by,created_at) on public.qnr_chat_messages to authenticated;
revoke all on qnr_private.qnr_chat_blocks,qnr_private.qnr_chat_reports,qnr_private.qnr_chat_upload_events,qnr_private.qnr_chat_upload_tickets from anon,authenticated,service_role;
grant usage on schema qnr_private to authenticated,service_role;

revoke all on function qnr_private.qnr_chat_is_moderator() from public,anon;
revoke all on function qnr_private.qnr_chat_can_read(uuid) from public,anon;
revoke all on function qnr_private.qnr_chat_can_read_object(text,text) from public,anon;
revoke all on function qnr_private.qnr_chat_reserve_upload(text) from public,anon;
grant execute on function qnr_private.qnr_chat_is_moderator(),qnr_private.qnr_chat_can_read(uuid),qnr_private.qnr_chat_can_read_object(text,text),qnr_private.qnr_chat_reserve_upload(text) to authenticated;

revoke all on function qnr_private.qnr_chat_send_message_secure(uuid,text,uuid,text),qnr_private.qnr_chat_list_rooms_secure(),qnr_private.qnr_chat_directory_secure(text),qnr_private.qnr_chat_join_room_secure(uuid),qnr_private.qnr_chat_start_direct_secure(uuid),qnr_private.qnr_chat_ask_course_question_secure(uuid,text,uuid),qnr_private.qnr_chat_history_secure(uuid,timestamptz,uuid,integer),qnr_private.qnr_chat_mark_read_secure(uuid),qnr_private.qnr_chat_block_user_secure(uuid),qnr_private.qnr_chat_unblock_user_secure(uuid),qnr_private.qnr_chat_report_message_secure(uuid,text,text),qnr_private.qnr_chat_admin_reports_secure(),qnr_private.qnr_chat_resolve_report_secure(uuid,text,text,boolean),qnr_private.qnr_chat_moderate_member_secure(uuid,uuid,text,integer,text),qnr_private.qnr_chat_my_capabilities_secure(),qnr_private.qnr_chat_admin_people_secure(),qnr_private.qnr_chat_admin_courses_secure(),qnr_private.qnr_chat_set_teacher_role_secure(uuid,boolean),qnr_private.qnr_chat_assign_teacher_secure(uuid,uuid) from public,anon;
grant execute on function qnr_private.qnr_chat_send_message_secure(uuid,text,uuid,text),qnr_private.qnr_chat_list_rooms_secure(),qnr_private.qnr_chat_directory_secure(text),qnr_private.qnr_chat_join_room_secure(uuid),qnr_private.qnr_chat_start_direct_secure(uuid),qnr_private.qnr_chat_ask_course_question_secure(uuid,text,uuid),qnr_private.qnr_chat_history_secure(uuid,timestamptz,uuid,integer),qnr_private.qnr_chat_mark_read_secure(uuid),qnr_private.qnr_chat_block_user_secure(uuid),qnr_private.qnr_chat_unblock_user_secure(uuid),qnr_private.qnr_chat_report_message_secure(uuid,text,text),qnr_private.qnr_chat_admin_reports_secure(),qnr_private.qnr_chat_resolve_report_secure(uuid,text,text,boolean),qnr_private.qnr_chat_moderate_member_secure(uuid,uuid,text,integer,text),qnr_private.qnr_chat_my_capabilities_secure(),qnr_private.qnr_chat_admin_people_secure(),qnr_private.qnr_chat_admin_courses_secure(),qnr_private.qnr_chat_set_teacher_role_secure(uuid,boolean),qnr_private.qnr_chat_assign_teacher_secure(uuid,uuid) to authenticated;
revoke all on function qnr_private.qnr_chat_register_upload_ticket_secure(uuid,uuid,uuid,text),qnr_private.qnr_chat_delete_upload_ticket_secure(uuid,text) from public,anon,authenticated;
grant execute on function qnr_private.qnr_chat_register_upload_ticket_secure(uuid,uuid,uuid,text),qnr_private.qnr_chat_delete_upload_ticket_secure(uuid,text) to service_role;

revoke all on function public.qnr_chat_list_rooms(),public.qnr_chat_directory(text),public.qnr_chat_join_room(uuid),public.qnr_chat_start_direct(uuid),public.qnr_chat_ask_course_question(uuid,text,uuid),public.qnr_chat_history(uuid,timestamptz,uuid,integer),public.qnr_chat_send_message(uuid,text,uuid,text),public.qnr_chat_mark_read(uuid),public.qnr_chat_block_user(uuid),public.qnr_chat_unblock_user(uuid),public.qnr_chat_report_message(uuid,text,text),public.qnr_chat_admin_reports(),public.qnr_chat_resolve_report(uuid,text,text,boolean),public.qnr_chat_moderate_member(uuid,uuid,text,integer,text),public.qnr_chat_my_capabilities(),public.qnr_chat_admin_people(),public.qnr_chat_admin_courses(),public.qnr_chat_set_teacher_role(uuid,boolean),public.qnr_chat_assign_teacher(uuid,uuid),public.qnr_chat_register_upload_ticket(uuid,uuid,uuid,text),public.qnr_chat_delete_upload_ticket(uuid,text) from public,anon;
grant execute on function public.qnr_chat_list_rooms(),public.qnr_chat_directory(text),public.qnr_chat_join_room(uuid),public.qnr_chat_start_direct(uuid),public.qnr_chat_ask_course_question(uuid,text,uuid),public.qnr_chat_history(uuid,timestamptz,uuid,integer),public.qnr_chat_send_message(uuid,text,uuid,text),public.qnr_chat_mark_read(uuid),public.qnr_chat_block_user(uuid),public.qnr_chat_unblock_user(uuid),public.qnr_chat_report_message(uuid,text,text),public.qnr_chat_admin_reports(),public.qnr_chat_resolve_report(uuid,text,text,boolean),public.qnr_chat_moderate_member(uuid,uuid,text,integer,text),public.qnr_chat_my_capabilities(),public.qnr_chat_admin_people(),public.qnr_chat_admin_courses(),public.qnr_chat_set_teacher_role(uuid,boolean),public.qnr_chat_assign_teacher(uuid,uuid) to authenticated;
grant execute on function public.qnr_chat_register_upload_ticket(uuid,uuid,uuid,text),public.qnr_chat_delete_upload_ticket(uuid,text) to service_role;

create policy qnr_chat_storage_read_member on storage.objects for select to authenticated
  using (bucket_id='qnr-chat' and (owner_id=(select auth.uid())::text or qnr_private.qnr_chat_can_read_object(bucket_id,name)));
create policy qnr_chat_storage_insert_member on storage.objects for insert to authenticated
  with check (bucket_id='qnr-chat' and qnr_private.qnr_chat_reserve_upload(name));
create policy qnr_chat_storage_delete_owner on storage.objects for delete to authenticated
  using (bucket_id='qnr-chat' and owner_id=(select auth.uid())::text);

do $publication$
begin
  if exists (select 1 from pg_publication where pubname='supabase_realtime')
     and not exists (select 1 from pg_publication_tables where pubname='supabase_realtime' and schemaname='public' and tablename='qnr_chat_messages') then
    alter publication supabase_realtime add table public.qnr_chat_messages;
  end if;
end;
$publication$;

commit;
