-- User-submitted gallery with explicit consent, private drafts and moderated publication.
create table public.qnr_gallery_posts (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null check (char_length(trim(title)) between 2 and 100),
  caption text not null default '' check (char_length(caption) <= 1000),
  topic text not null default 'other' check (topic in ('pattern', 'color', 'materials', 'technique', 'project', 'other')),
  use_case text not null default 'other' check (use_case in ('quilt', 'home', 'accessory', 'clothing', 'other')),
  skill_level text not null default 'beginner' check (skill_level in ('beginner', 'intermediate', 'advanced')),
  color_family text[] not null default '{}' check (
    cardinality(color_family) <= 4 and
    color_family <@ array['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'neutral', 'mixed']::text[]
  ),
  image_path text not null unique check (image_path ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}[.](jpg|png|webp)$'),
  visibility text not null default 'private' check (visibility in ('private', 'public')),
  publication_consent boolean not null default false,
  consent_version text,
  consented_at timestamptz,
  review_status text not null default 'private' check (review_status in ('private', 'pending', 'approved', 'rejected', 'hidden')),
  moderation_note text check (moderation_note is null or char_length(moderation_note) <= 500),
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  constraint qnr_gallery_visibility_review_check check (
    (visibility = 'private' and review_status = 'private' and publication_consent = false and consent_version is null and consented_at is null and reviewed_by is null and reviewed_at is null and moderation_note is null)
    or
    (visibility = 'public' and publication_consent = true and consent_version = 'gallery-v1' and consented_at is not null and review_status in ('pending', 'approved', 'rejected', 'hidden')
      and ((review_status = 'pending' and reviewed_by is null and reviewed_at is null and moderation_note is null)
        or (review_status in ('approved', 'rejected', 'hidden') and reviewed_by is not null and reviewed_at is not null)))
  )
);

create index qnr_gallery_posts_public_idx on public.qnr_gallery_posts (created_at desc)
  where visibility = 'public' and review_status = 'approved';
create index qnr_gallery_posts_owner_idx on public.qnr_gallery_posts (owner_id, created_at desc);

alter table public.qnr_gallery_posts enable row level security;
revoke all on public.qnr_gallery_posts from public, anon, authenticated;
grant all on public.qnr_gallery_posts to service_role;
create policy qnr_gallery_posts_public_read on public.qnr_gallery_posts for select to anon, authenticated
  using (visibility = 'public' and review_status = 'approved' and consented_at is not null);
create policy qnr_gallery_posts_owner_read on public.qnr_gallery_posts for select to authenticated
  using (owner_id = (select auth.uid()));
create policy qnr_gallery_posts_admin_read on public.qnr_gallery_posts for select to authenticated
  using (qnr_private.qnr_is_admin());

-- Expose only fields needed to render a public post. RLS still determines which rows are visible.
create view public.qnr_public_gallery_posts with (security_invoker = true) as
  select id, title, caption, topic, use_case, skill_level, color_family, image_path, created_at
  from public.qnr_gallery_posts
  where visibility = 'public' and review_status = 'approved' and consented_at is not null;

grant select (id, title, caption, topic, use_case, skill_level, color_family, image_path, visibility, review_status, consented_at, created_at)
  on public.qnr_gallery_posts to anon, authenticated;
grant select on public.qnr_public_gallery_posts to anon, authenticated;

create table public.qnr_gallery_reports (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.qnr_gallery_posts(id) on delete cascade,
  reporter_id uuid not null references auth.users(id) on delete cascade,
  reason text not null check (reason in ('copyright', 'privacy', 'spam', 'harassment', 'other')),
  description text not null default '' check (char_length(description) <= 500),
  status text not null default 'open' check (status in ('open', 'reviewed', 'dismissed')),
  created_at timestamptz not null default now(),
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  resolution_note text check (resolution_note is null or char_length(resolution_note) <= 500),
  constraint qnr_gallery_reports_review_check check (
    (status = 'open' and reviewed_by is null and reviewed_at is null and resolution_note is null)
    or (status in ('reviewed', 'dismissed') and reviewed_by is not null and reviewed_at is not null)
  ),
  unique (post_id, reporter_id)
);
create index qnr_gallery_reports_status_idx on public.qnr_gallery_reports (status, created_at desc);
alter table public.qnr_gallery_reports enable row level security;
revoke all on public.qnr_gallery_reports from public, anon, authenticated;
grant all on public.qnr_gallery_reports to service_role;

-- Publicly callable operations perform strict actor checks and return only safe fields.
create or replace function public.qnr_my_gallery_posts()
returns table (
  id uuid, title text, caption text, topic text, use_case text, skill_level text,
  color_family text[], image_path text, visibility text, review_status text,
  moderation_note text, created_at timestamptz, updated_at timestamptz
)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if (select auth.uid()) is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  return query
    select p.id, p.title, p.caption, p.topic, p.use_case, p.skill_level, p.color_family,
           p.image_path, p.visibility, p.review_status, p.moderation_note, p.created_at, p.updated_at
    from public.qnr_gallery_posts p
    where p.owner_id = (select auth.uid())
    order by p.created_at desc;
end;
$$;
revoke all on function public.qnr_my_gallery_posts() from public, anon;
grant execute on function public.qnr_my_gallery_posts() to authenticated;

create or replace function public.qnr_admin_gallery_queue()
returns table (
  id uuid, owner_id uuid, title text, caption text, topic text, use_case text,
  skill_level text, color_family text[], image_path text, created_at timestamptz
)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if (select auth.uid()) is null or not qnr_private.qnr_is_admin() then
    raise exception 'ADMIN_REQUIRED' using errcode = '42501';
  end if;
  return query
    select p.id, p.owner_id, p.title, p.caption, p.topic, p.use_case, p.skill_level,
           p.color_family, p.image_path, p.created_at
    from public.qnr_gallery_posts p
    where p.visibility = 'public' and p.review_status = 'pending'
    order by p.created_at asc;
end;
$$;
revoke all on function public.qnr_admin_gallery_queue() from public, anon;
grant execute on function public.qnr_admin_gallery_queue() to authenticated;

create or replace function public.qnr_admin_gallery_reports()
returns table (
  id uuid, post_id uuid, post_title text, reason text, description text,
  status text, created_at timestamptz, resolution_note text
)
language plpgsql stable security definer set search_path = ''
as $$
begin
  if (select auth.uid()) is null or not qnr_private.qnr_is_admin() then
    raise exception 'ADMIN_REQUIRED' using errcode = '42501';
  end if;
  return query
    select r.id, r.post_id, p.title, r.reason, r.description, r.status, r.created_at, r.resolution_note
    from public.qnr_gallery_reports r
    join public.qnr_gallery_posts p on p.id = r.post_id
    order by (r.status = 'open') desc, r.created_at desc;
end;
$$;
revoke all on function public.qnr_admin_gallery_reports() from public, anon;
grant execute on function public.qnr_admin_gallery_reports() to authenticated;

create or replace function public.qnr_report_gallery_post(p_post_id uuid, p_reason text, p_description text default '')
returns uuid
language plpgsql security definer set search_path = ''
as $$
declare
  report_id uuid;
  report_text text := coalesce(trim(p_description), '');
begin
  if (select auth.uid()) is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if p_reason not in ('copyright', 'privacy', 'spam', 'harassment', 'other') then
    raise exception 'INVALID_REPORT_REASON' using errcode = '22023';
  end if;
  if char_length(report_text) > 500 then raise exception 'REPORT_TOO_LONG' using errcode = '22023'; end if;
  if not exists (
    select 1 from public.qnr_gallery_posts p
    where p.id = p_post_id and p.visibility = 'public' and p.review_status = 'approved' and p.consented_at is not null
  ) then raise exception 'POST_NOT_REPORTABLE' using errcode = '22023'; end if;
  insert into public.qnr_gallery_reports (post_id, reporter_id, reason, description)
    values (p_post_id, (select auth.uid()), p_reason, report_text)
    returning id into report_id;
  return report_id;
exception when unique_violation then
  raise exception 'DUPLICATE_GALLERY_REPORT' using errcode = '23505';
end;
$$;
revoke all on function public.qnr_report_gallery_post(uuid, text, text) from public, anon;
grant execute on function public.qnr_report_gallery_post(uuid, text, text) to authenticated;

create or replace function public.qnr_moderate_gallery_post(p_post_id uuid, p_action text, p_note text default '')
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  current_status text;
  next_status text;
  owner uuid;
  clean_note text := left(nullif(trim(coalesce(p_note, '')), ''), 500);
begin
  if actor is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  if p_action not in ('approve', 'reject', 'hide') then raise exception 'INVALID_MODERATION_ACTION' using errcode = '22023'; end if;
  select p.review_status, p.owner_id into current_status, owner
    from public.qnr_gallery_posts p where p.id = p_post_id and p.visibility = 'public' for update;
  if not found then raise exception 'POST_NOT_FOUND' using errcode = 'P0002'; end if;
  if p_action in ('approve', 'reject') and current_status <> 'pending' then raise exception 'POST_NOT_PENDING' using errcode = '22023'; end if;
  if p_action = 'hide' and current_status not in ('approved', 'pending') then raise exception 'POST_NOT_VISIBLE' using errcode = '22023'; end if;
  next_status := case p_action when 'approve' then 'approved' when 'reject' then 'rejected' else 'hidden' end;
  update public.qnr_gallery_posts
    set review_status = next_status, moderation_note = clean_note, reviewed_by = actor, reviewed_at = now(), updated_at = now()
    where id = p_post_id;
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
    values (actor, p_action, 'qnr_gallery_posts', p_post_id::text, jsonb_build_object('status', next_status, 'note', clean_note));
  insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
    values (owner, 'gallery_review', 'وضعیت اثر گالری به‌روز شد',
      case next_status when 'approved' then 'اثر تو پس از بازبینی در گالری منتشر شد.'
        when 'rejected' then 'اثر تو برای انتشار در گالری پذیرفته نشد؛ توضیح را در آثار من ببین.'
        else 'نمایش اثر تو از گالری متوقف شد.' end,
      '/gallery');
end;
$$;
revoke all on function public.qnr_moderate_gallery_post(uuid, text, text) from public, anon;
grant execute on function public.qnr_moderate_gallery_post(uuid, text, text) to authenticated;

create or replace function public.qnr_admin_resolve_gallery_report(p_report_id uuid, p_status text, p_note text default '')
returns void
language plpgsql security definer set search_path = ''
as $$
declare
  actor uuid := (select auth.uid());
  clean_note text := left(nullif(trim(coalesce(p_note, '')), ''), 500);
begin
  if actor is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  if p_status not in ('reviewed', 'dismissed') then raise exception 'INVALID_REPORT_STATUS' using errcode = '22023'; end if;
  update public.qnr_gallery_reports
    set status = p_status, reviewed_by = actor, reviewed_at = now(), resolution_note = clean_note
    where id = p_report_id and status = 'open';
  if not found then raise exception 'REPORT_NOT_OPEN' using errcode = '22023'; end if;
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
    values (actor, 'resolve', 'qnr_gallery_reports', p_report_id::text, jsonb_build_object('status', p_status, 'note', clean_note));
end;
$$;
revoke all on function public.qnr_admin_resolve_gallery_report(uuid, text, text) from public, anon;
grant execute on function public.qnr_admin_resolve_gallery_report(uuid, text, text) to authenticated;

create or replace function qnr_private.qnr_gallery_prepare_post()
returns trigger language plpgsql set search_path = ''
as $$
begin
  if new.visibility = 'public' then
    if not new.publication_consent then raise exception 'PUBLIC_CONSENT_REQUIRED' using errcode = '22023'; end if;
    new.review_status := 'pending';
    new.consent_version := 'gallery-v1';
    new.consented_at := now();
  else
    new.visibility := 'private';
    new.publication_consent := false;
    new.review_status := 'private';
    new.consent_version := null;
    new.consented_at := null;
  end if;
  new.moderation_note := null;
  new.reviewed_by := null;
  new.reviewed_at := null;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_gallery_prepare_post() from public, anon, authenticated, service_role;
create trigger qnr_gallery_prepare_before_insert before insert on public.qnr_gallery_posts
  for each row execute function qnr_private.qnr_gallery_prepare_post();

create or replace function qnr_private.qnr_gallery_rate_guard()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  recent_count integer;
begin
  perform pg_advisory_xact_lock(hashtextextended(new.owner_id::text || ':gallery-post', 0));
  select count(*) into recent_count from public.qnr_gallery_posts p
    where p.owner_id = new.owner_id and p.created_at > now() - interval '24 hours';
  if recent_count >= 10 then raise exception 'GALLERY_POST_RATE_LIMIT' using errcode = 'P0001'; end if;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_gallery_rate_guard() from public, anon, authenticated, service_role;
create trigger qnr_gallery_rate_before_insert before insert on public.qnr_gallery_posts
  for each row execute function qnr_private.qnr_gallery_rate_guard();

create or replace function qnr_private.qnr_gallery_report_rate_guard()
returns trigger language plpgsql security definer set search_path = ''
as $$
declare
  recent_count integer;
begin
  perform pg_advisory_xact_lock(hashtextextended(new.reporter_id::text || ':gallery-report', 0));
  select count(*) into recent_count from public.qnr_gallery_reports r
    where r.reporter_id = new.reporter_id and r.created_at > now() - interval '24 hours';
  if recent_count >= 20 then raise exception 'GALLERY_REPORT_RATE_LIMIT' using errcode = 'P0001'; end if;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_gallery_report_rate_guard() from public, anon, authenticated, service_role;
create trigger qnr_gallery_report_rate_before_insert before insert on public.qnr_gallery_reports
  for each row execute function qnr_private.qnr_gallery_report_rate_guard();

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('qnr-gallery', 'qnr-gallery', false, 10485760, array['image/jpeg', 'image/png', 'image/webp']);

create or replace function qnr_private.qnr_gallery_upload_allowed()
returns boolean language plpgsql volatile security definer set search_path = ''
as $$
declare
  recent_count integer;
  actor text := (select auth.uid()::text);
begin
  if actor is null then return false; end if;
  perform pg_advisory_xact_lock(hashtextextended(actor || ':gallery-upload', 0));
  select count(*) into recent_count from storage.objects o
    where o.bucket_id = 'qnr-gallery' and o.owner_id = actor and o.created_at > now() - interval '24 hours';
  return recent_count < 20;
end;
$$;
revoke all on function qnr_private.qnr_gallery_upload_allowed() from public, anon;
grant execute on function qnr_private.qnr_gallery_upload_allowed() to authenticated;

create policy qnr_gallery_storage_upload_owner on storage.objects for insert to authenticated
  with check (
    bucket_id = 'qnr-gallery'
    and owner_id = (select auth.uid()::text)
    and name ~ '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}[.](jpg|png|webp)$'
    and qnr_private.qnr_gallery_upload_allowed()
  );
create policy qnr_gallery_storage_read_owner_admin_or_approved on storage.objects for select to anon, authenticated
  using (
    bucket_id = 'qnr-gallery'
    and (
      owner_id = (select auth.uid()::text)
      or qnr_private.qnr_is_admin()
      or exists (
        select 1 from public.qnr_gallery_posts p
        where p.image_path = name and p.visibility = 'public' and p.review_status = 'approved' and p.consented_at is not null
      )
    )
  );
alter table public.qnr_notifications drop constraint if exists qnr_notifications_notification_type_check;
alter table public.qnr_notifications add constraint qnr_notifications_notification_type_check
  check (notification_type in ('support_new', 'support_reply', 'order_update', 'payment_update', 'learning_update', 'gallery_review', 'system'));

