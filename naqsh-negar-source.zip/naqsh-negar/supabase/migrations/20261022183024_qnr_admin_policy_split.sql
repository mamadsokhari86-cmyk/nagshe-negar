-- Admin read access is already included in the published/read policies. Keep write policies
-- separate so authenticated SELECT queries do not evaluate overlapping permissive policies.
drop policy if exists categories_admin_manage on public.qnr_categories;
create policy categories_admin_insert on public.qnr_categories for insert to authenticated with check (qnr_private.qnr_is_admin());
create policy categories_admin_update on public.qnr_categories for update to authenticated using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
create policy categories_admin_delete on public.qnr_categories for delete to authenticated using (qnr_private.qnr_is_admin());

drop policy if exists products_admin_manage on public.qnr_products;
create policy products_admin_insert on public.qnr_products for insert to authenticated with check (qnr_private.qnr_is_admin());
create policy products_admin_update on public.qnr_products for update to authenticated using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
create policy products_admin_delete on public.qnr_products for delete to authenticated using (qnr_private.qnr_is_admin());

drop policy if exists tutorials_admin_manage on public.qnr_tutorials;
create policy tutorials_admin_insert on public.qnr_tutorials for insert to authenticated with check (qnr_private.qnr_is_admin());
create policy tutorials_admin_update on public.qnr_tutorials for update to authenticated using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
create policy tutorials_admin_delete on public.qnr_tutorials for delete to authenticated using (qnr_private.qnr_is_admin());

drop policy if exists courses_admin_manage on public.qnr_courses;
create policy courses_admin_insert on public.qnr_courses for insert to authenticated with check (qnr_private.qnr_is_admin());
create policy courses_admin_update on public.qnr_courses for update to authenticated using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
create policy courses_admin_delete on public.qnr_courses for delete to authenticated using (qnr_private.qnr_is_admin());

drop policy if exists lessons_admin_manage on public.qnr_course_lessons;
create policy lessons_admin_insert on public.qnr_course_lessons for insert to authenticated with check (qnr_private.qnr_is_admin());
create policy lessons_admin_update on public.qnr_course_lessons for update to authenticated using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
create policy lessons_admin_delete on public.qnr_course_lessons for delete to authenticated using (qnr_private.qnr_is_admin());

drop policy if exists site_pages_admin_manage on public.qnr_site_pages;
create policy site_pages_admin_insert on public.qnr_site_pages for insert to authenticated with check (qnr_private.qnr_is_admin());
create policy site_pages_admin_update on public.qnr_site_pages for update to authenticated using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
create policy site_pages_admin_delete on public.qnr_site_pages for delete to authenticated using (qnr_private.qnr_is_admin());

drop policy if exists qnr_store_settings_admin_manage on public.qnr_store_settings;
create policy qnr_store_settings_admin_insert on public.qnr_store_settings for insert to authenticated with check (qnr_private.qnr_is_admin());
create policy qnr_store_settings_admin_update on public.qnr_store_settings for update to authenticated using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
create policy qnr_store_settings_admin_delete on public.qnr_store_settings for delete to authenticated using (qnr_private.qnr_is_admin());
