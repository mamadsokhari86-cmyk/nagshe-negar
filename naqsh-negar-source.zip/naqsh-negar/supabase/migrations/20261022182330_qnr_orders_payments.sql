create table public.qnr_orders (
  id uuid primary key default gen_random_uuid(),
  order_number text not null unique,
  user_id uuid not null references auth.users(id) on delete restrict,
  idempotency_key text not null,
  status text not null default 'awaiting_payment' check (status in ('awaiting_payment', 'payment_review', 'paid', 'payment_rejected', 'expired', 'cancelled')),
  subtotal_amount bigint not null check (subtotal_amount >= 0),
  shipping_amount bigint not null check (shipping_amount >= 0),
  total_amount bigint not null check (total_amount = subtotal_amount + shipping_amount),
  currency text not null default 'IRR',
  shipping_snapshot jsonb not null,
  consent_versions jsonb not null,
  reservation_expires_at timestamptz not null,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (user_id, idempotency_key)
);

create table public.qnr_order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.qnr_orders(id) on delete cascade,
  product_id uuid not null references public.qnr_products(id) on delete restrict,
  product_name text not null,
  quantity integer not null check (quantity between 1 and 99),
  unit_price_amount bigint not null check (unit_price_amount >= 0),
  line_total_amount bigint not null check (line_total_amount = unit_price_amount * quantity),
  currency text not null default 'IRR',
  created_at timestamptz not null default now()
);

create table public.qnr_order_events (
  id bigint generated always as identity primary key,
  order_id uuid not null references public.qnr_orders(id) on delete cascade,
  actor_id uuid references auth.users(id) on delete set null,
  event_type text not null,
  reason text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create table public.qnr_manual_payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.qnr_orders(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete restrict,
  amount bigint not null check (amount >= 0),
  receipt_path text not null,
  reference_code text,
  status text not null default 'pending' check (status in ('pending', 'approved', 'rejected', 'expired')),
  review_reason text,
  reviewed_by uuid references auth.users(id) on delete set null,
  reviewed_at timestamptz,
  created_at timestamptz not null default now(),
  check (status <> 'rejected' or length(trim(coalesce(review_reason, ''))) > 0)
);

create unique index qnr_manual_payments_one_pending_idx on public.qnr_manual_payments(order_id) where status = 'pending';
create index qnr_orders_user_created_idx on public.qnr_orders(user_id, created_at desc);
create index qnr_order_items_order_idx on public.qnr_order_items(order_id);
create index qnr_order_events_order_idx on public.qnr_order_events(order_id, created_at desc);
create index qnr_orders_expiration_idx on public.qnr_orders(reservation_expires_at) where status = 'awaiting_payment';

create trigger qnr_orders_touch_updated_at before update on public.qnr_orders for each row execute function public.qnr_touch_updated_at();
alter table public.qnr_orders enable row level security;
alter table public.qnr_order_items enable row level security;
alter table public.qnr_order_events enable row level security;
alter table public.qnr_manual_payments enable row level security;

create policy qnr_orders_read_own_or_admin on public.qnr_orders for select to authenticated
  using (user_id = auth.uid() or qnr_private.qnr_is_admin());
create policy qnr_order_items_read_own_or_admin on public.qnr_order_items for select to authenticated
  using (exists (select 1 from public.qnr_orders o where o.id = order_id and (o.user_id = auth.uid() or qnr_private.qnr_is_admin())));
create policy qnr_order_events_read_own_or_admin on public.qnr_order_events for select to authenticated
  using (exists (select 1 from public.qnr_orders o where o.id = order_id and (o.user_id = auth.uid() or qnr_private.qnr_is_admin())));
create policy qnr_manual_payments_read_own_or_admin on public.qnr_manual_payments for select to authenticated
  using (user_id = auth.uid() or qnr_private.qnr_is_admin());
create policy qnr_manual_payments_submit_own on public.qnr_manual_payments for insert to authenticated
  with check (user_id = auth.uid() and status = 'pending' and reviewed_by is null and reviewed_at is null);

revoke all on public.qnr_orders, public.qnr_order_items, public.qnr_order_events, public.qnr_manual_payments from anon, authenticated;
grant select on public.qnr_orders, public.qnr_order_items, public.qnr_order_events, public.qnr_manual_payments to authenticated;
grant insert on public.qnr_manual_payments to authenticated;

create or replace function qnr_private.qnr_validate_payment_submission()
returns trigger
language plpgsql
security definer
set search_path = public, storage
as $$
declare
  order_row public.qnr_orders%rowtype;
begin
  select * into order_row from public.qnr_orders where id = new.order_id and user_id = new.user_id;
  if not found or order_row.status <> 'awaiting_payment' or order_row.reservation_expires_at <= now() then
    raise exception 'ORDER_NOT_PAYABLE' using errcode = '42501';
  end if;
  if new.amount <> order_row.total_amount then
    raise exception 'PAYMENT_AMOUNT_MISMATCH' using errcode = '22023';
  end if;
  if (storage.foldername(new.receipt_path))[1] <> new.user_id::text
    or (storage.foldername(new.receipt_path))[2] <> new.order_id::text
    or not exists (
      select 1 from storage.objects o
      where o.bucket_id = 'qnr-payment-receipts' and o.name = new.receipt_path
    ) then
    raise exception 'INVALID_RECEIPT_OBJECT' using errcode = '42501';
  end if;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_validate_payment_submission() from public, anon, authenticated, service_role;
create trigger qnr_manual_payments_validate before insert on public.qnr_manual_payments
  for each row execute function qnr_private.qnr_validate_payment_submission();

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('qnr-payment-receipts', 'qnr-payment-receipts', false, 10485760, array['image/jpeg', 'image/png', 'image/webp', 'application/pdf'])
on conflict (id) do update set public = false, file_size_limit = excluded.file_size_limit, allowed_mime_types = excluded.allowed_mime_types;

create policy qnr_receipts_upload_own on storage.objects for insert to authenticated
  with check (
    bucket_id = 'qnr-payment-receipts'
    and (storage.foldername(name))[1] = auth.uid()::text
    and exists (
      select 1 from public.qnr_orders o
      where o.id::text = (storage.foldername(name))[2]
        and o.user_id = auth.uid()
        and o.status = 'awaiting_payment'
        and o.reservation_expires_at > now()
    )
  );
create policy qnr_receipts_read_own_or_admin on storage.objects for select to authenticated
  using (
    bucket_id = 'qnr-payment-receipts'
    and exists (
      select 1 from public.qnr_manual_payments p
      where p.receipt_path = name and (p.user_id = auth.uid() or qnr_private.qnr_is_admin())
    )
  );
create policy qnr_receipts_delete_own_unsubmitted on storage.objects for delete to authenticated
  using (
    bucket_id = 'qnr-payment-receipts'
    and (storage.foldername(name))[1] = auth.uid()::text
    and not exists (select 1 from public.qnr_manual_payments p where p.receipt_path = name)
  );

create or replace function public.qnr_expire_orders()
returns integer
language plpgsql
security definer
set search_path = public
as $$
declare
  expired_order record;
  order_line record;
  expired_count integer := 0;
begin
  for expired_order in
    select id from public.qnr_orders
    where status = 'awaiting_payment' and reservation_expires_at <= now()
    order by reservation_expires_at
    for update skip locked
  loop
    for order_line in select product_id, quantity from public.qnr_order_items where order_id = expired_order.id loop
      update public.qnr_products set inventory_count = inventory_count + order_line.quantity where id = order_line.product_id;
    end loop;
    update public.qnr_orders set status = 'expired' where id = expired_order.id;
    update public.qnr_manual_payments set status = 'expired', reviewed_at = now(), review_reason = 'مهلت پرداخت سفارش پایان یافت.'
      where order_id = expired_order.id and status = 'pending';
    insert into public.qnr_order_events (order_id, event_type, reason)
      values (expired_order.id, 'expired', 'مهلت پرداخت سفارش پایان یافت.');
    expired_count := expired_count + 1;
  end loop;
  return expired_count;
end;
$$;
revoke all on function public.qnr_expire_orders() from public, anon, authenticated;
grant execute on function public.qnr_expire_orders() to service_role;

create or replace function public.qnr_create_order(
  p_user_id uuid,
  p_items jsonb,
  p_idempotency_key text,
  p_shipping jsonb,
  p_consent jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_order public.qnr_orders%rowtype;
  settings_row public.qnr_store_settings%rowtype;
  line record;
  product_row public.qnr_products%rowtype;
  new_order public.qnr_orders%rowtype;
  subtotal bigint := 0;
  line_total bigint;
  privacy_version text;
  terms_version text;
begin
  if p_user_id is null or p_items is null or jsonb_typeof(p_items) <> 'array'
    or jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 50 then
    raise exception 'INVALID_ORDER' using errcode = '22023';
  end if;
  if p_idempotency_key !~ '^[A-Za-z0-9._:-]{8,128}$' then
    raise exception 'INVALID_IDEMPOTENCY_KEY' using errcode = '22023';
  end if;

  perform pg_advisory_xact_lock(hashtextextended(p_user_id::text || ':' || p_idempotency_key, 0));
  select * into existing_order from public.qnr_orders where user_id = p_user_id and idempotency_key = p_idempotency_key;
  if found then
    return jsonb_build_object('id', existing_order.id, 'order_number', existing_order.order_number, 'status', existing_order.status, 'total_amount', existing_order.total_amount);
  end if;

  perform public.qnr_expire_orders();

  select * into settings_row from public.qnr_store_settings where singleton = true;
  if not found or not settings_row.checkout_enabled then
    raise exception 'CHECKOUT_NOT_CONFIGURED' using errcode = '55000';
  end if;
  if coalesce(p_consent ->> 'privacy', 'false') <> 'true' or coalesce(p_consent ->> 'terms', 'false') <> 'true' then
    raise exception 'POLICY_CONSENT_REQUIRED' using errcode = '42501';
  end if;
  select updated_at::text into privacy_version from public.qnr_site_pages where slug = 'privacy' and is_published and body <> '[]'::jsonb;
  select updated_at::text into terms_version from public.qnr_site_pages where slug = 'terms' and is_published and body <> '[]'::jsonb;
  if privacy_version is null or terms_version is null then
    raise exception 'POLICY_PAGES_REQUIRED' using errcode = '55000';
  end if;
  if jsonb_typeof(p_shipping) <> 'object'
    or length(trim(coalesce(p_shipping ->> 'full_name', ''))) < 3
    or length(trim(coalesce(p_shipping ->> 'phone', ''))) < 8
    or length(trim(coalesce(p_shipping ->> 'province', ''))) < 2
    or length(trim(coalesce(p_shipping ->> 'city', ''))) < 2
    or length(trim(coalesce(p_shipping ->> 'address', ''))) < 8
    or length(trim(coalesce(p_shipping ->> 'postal_code', ''))) < 5 then
    raise exception 'INVALID_SHIPPING_ADDRESS' using errcode = '22023';
  end if;

  for line in
    select (entry ->> 'product_id')::uuid as product_id, sum((entry ->> 'quantity')::integer)::integer as quantity
    from jsonb_array_elements(p_items) entry
    group by (entry ->> 'product_id')::uuid
    order by (entry ->> 'product_id')::uuid
  loop
    if line.quantity < 1 or line.quantity > 99 then raise exception 'INVALID_QUANTITY' using errcode = '22023'; end if;
    select * into product_row from public.qnr_products where id = line.product_id for update;
    if not found or not product_row.is_published or product_row.price_amount is null then
      raise exception 'PRODUCT_UNAVAILABLE' using errcode = 'P0001';
    end if;
    if product_row.inventory_count < line.quantity then
      raise exception 'INSUFFICIENT_STOCK' using errcode = 'P0001';
    end if;
    line_total := product_row.price_amount * line.quantity;
    subtotal := subtotal + line_total;
  end loop;

  insert into public.qnr_orders (order_number, user_id, idempotency_key, status, subtotal_amount, shipping_amount, total_amount, currency, shipping_snapshot, consent_versions, reservation_expires_at)
  values (
    'NN-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)),
    p_user_id,
    p_idempotency_key,
    'awaiting_payment',
    subtotal,
    settings_row.shipping_amount,
    subtotal + settings_row.shipping_amount,
    'IRR',
    p_shipping,
    jsonb_build_object('privacy_updated_at', privacy_version, 'terms_updated_at', terms_version),
    now() + make_interval(mins => settings_row.reservation_minutes)
  ) returning * into new_order;

  for line in
    select (entry ->> 'product_id')::uuid as product_id, sum((entry ->> 'quantity')::integer)::integer as quantity
    from jsonb_array_elements(p_items) entry
    group by (entry ->> 'product_id')::uuid
    order by (entry ->> 'product_id')::uuid
  loop
    select * into product_row from public.qnr_products where id = line.product_id;
    insert into public.qnr_order_items (order_id, product_id, product_name, quantity, unit_price_amount, line_total_amount, currency)
      values (new_order.id, product_row.id, product_row.name, line.quantity, product_row.price_amount, product_row.price_amount * line.quantity, product_row.currency);
    update public.qnr_products set inventory_count = inventory_count - line.quantity where id = product_row.id;
    delete from public.qnr_cart_items where user_id = p_user_id and product_id = product_row.id;
  end loop;

  insert into public.qnr_order_events (order_id, actor_id, event_type, details)
    values (new_order.id, p_user_id, 'created', jsonb_build_object('status', 'awaiting_payment'));

  return jsonb_build_object('id', new_order.id, 'order_number', new_order.order_number, 'status', new_order.status, 'subtotal_amount', new_order.subtotal_amount, 'shipping_amount', new_order.shipping_amount, 'total_amount', new_order.total_amount, 'reservation_expires_at', new_order.reservation_expires_at);
end;
$$;
revoke all on function public.qnr_create_order(uuid, jsonb, text, jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.qnr_create_order(uuid, jsonb, text, jsonb, jsonb) to service_role;

create or replace function public.qnr_review_payment(p_actor_id uuid, p_payment_id uuid, p_decision text, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  payment_row public.qnr_manual_payments%rowtype;
  order_row public.qnr_orders%rowtype;
  order_line record;
begin
  if not exists (select 1 from public.qnr_user_roles where user_id = p_actor_id and role = 'admin') then
    raise exception 'ADMIN_REQUIRED' using errcode = '42501';
  end if;
  if p_decision not in ('approved', 'rejected') or (p_decision = 'rejected' and length(trim(coalesce(p_reason, ''))) < 4) then
    raise exception 'INVALID_REVIEW_DECISION' using errcode = '22023';
  end if;

  perform public.qnr_expire_orders();
  select * into payment_row from public.qnr_manual_payments where id = p_payment_id for update;
  if not found or payment_row.status <> 'pending' then
    return jsonb_build_object('status', coalesce(payment_row.status, 'not_found'));
  end if;
  select * into order_row from public.qnr_orders where id = payment_row.order_id for update;
  if order_row.status <> 'awaiting_payment' then
    return jsonb_build_object('status', order_row.status, 'order_id', order_row.id);
  end if;

  update public.qnr_manual_payments
    set status = p_decision, review_reason = nullif(trim(p_reason), ''), reviewed_by = p_actor_id, reviewed_at = now()
    where id = p_payment_id;
  if p_decision = 'approved' then
    update public.qnr_orders set status = 'paid' where id = order_row.id;
  else
    update public.qnr_orders set status = 'payment_rejected' where id = order_row.id;
    for order_line in select product_id, quantity from public.qnr_order_items where order_id = order_row.id loop
      update public.qnr_products set inventory_count = inventory_count + order_line.quantity where id = order_line.product_id;
    end loop;
  end if;
  insert into public.qnr_order_events (order_id, actor_id, event_type, reason, details)
    values (order_row.id, p_actor_id, p_decision, nullif(trim(p_reason), ''), jsonb_build_object('payment_id', p_payment_id));
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, reason, details)
    values (p_actor_id, 'review_' || p_decision, 'qnr_manual_payments', p_payment_id::text, nullif(trim(p_reason), ''), jsonb_build_object('order_id', order_row.id));
  return jsonb_build_object('status', p_decision, 'order_id', order_row.id);
end;
$$;
revoke all on function public.qnr_review_payment(uuid, uuid, text, text) from public, anon, authenticated;
grant execute on function public.qnr_review_payment(uuid, uuid, text, text) to service_role;

create or replace function qnr_private.qnr_audit_store_settings()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
  values (auth.uid(), lower(tg_op), 'qnr_store_settings', 'singleton', jsonb_build_object('checkout_enabled', new.checkout_enabled));
  return new;
end;
$$;
revoke all on function qnr_private.qnr_audit_store_settings() from public, anon, authenticated, service_role;
create trigger qnr_store_settings_audit after update on public.qnr_store_settings
  for each row execute function qnr_private.qnr_audit_store_settings();

create extension if not exists pg_cron with schema pg_catalog;
select cron.schedule('qnr-expire-pending-orders', '*/5 * * * *', 'select public.qnr_expire_orders();');

comment on table public.qnr_orders is 'Orders with server-priced line snapshots and expiring inventory reservations.';
comment on table public.qnr_manual_payments is 'Private manual payment receipts; changes are reviewed by server functions.';
