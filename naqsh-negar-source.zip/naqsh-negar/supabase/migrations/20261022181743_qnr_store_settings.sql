create table public.qnr_store_settings (
  singleton boolean primary key default true check (singleton),
  card_holder text,
  card_number text,
  shipping_amount bigint check (shipping_amount is null or shipping_amount >= 0),
  shipping_policy text,
  returns_policy text,
  contact_phone text,
  reservation_minutes integer not null default 30 check (reservation_minutes between 5 and 1440),
  checkout_enabled boolean not null default false,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now(),
  check (
    not checkout_enabled or (
      length(trim(coalesce(card_holder, ''))) > 0
      and card_number ~ '^[0-9]{16}$'
      and shipping_amount is not null
      and length(trim(coalesce(shipping_policy, ''))) >= 20
      and length(trim(coalesce(returns_policy, ''))) >= 20
      and length(trim(coalesce(contact_phone, ''))) >= 7
    )
  )
);

insert into public.qnr_store_settings (singleton) values (true) on conflict (singleton) do nothing;
create trigger qnr_store_settings_touch_updated_at before update on public.qnr_store_settings
  for each row execute function public.qnr_touch_updated_at();
alter table public.qnr_store_settings enable row level security;
create policy qnr_store_settings_read_active_or_admin on public.qnr_store_settings for select to authenticated
  using (checkout_enabled or qnr_private.qnr_is_admin());
create policy qnr_store_settings_admin_manage on public.qnr_store_settings for all to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
revoke all on public.qnr_store_settings from anon, authenticated;
grant select, insert, update on public.qnr_store_settings to authenticated;
comment on table public.qnr_store_settings is 'Owner-configured payment and shipping information. Checkout remains disabled until real values are supplied.';
