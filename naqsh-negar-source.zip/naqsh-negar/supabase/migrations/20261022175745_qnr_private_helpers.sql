-- Keep SECURITY DEFINER helpers outside the Data API schema.
create schema if not exists qnr_private;
revoke all on schema qnr_private from public;
grant usage on schema qnr_private to anon, authenticated;

create or replace function qnr_private.qnr_is_admin()
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.qnr_user_roles
    where user_id = auth.uid() and role = 'admin'
  );
$$;
revoke all on function qnr_private.qnr_is_admin() from public;
grant execute on function qnr_private.qnr_is_admin() to anon, authenticated;

create or replace function qnr_private.qnr_create_profile()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.qnr_profiles (id, display_name)
  values (
    new.id,
    coalesce(nullif(trim(new.raw_user_meta_data ->> 'full_name'), ''), '')
  )
  on conflict (id) do nothing;
  return new;
end;
$$;
revoke all on function qnr_private.qnr_create_profile() from public, anon, authenticated, service_role;

drop trigger if exists qnr_auth_user_profile on auth.users;
create trigger qnr_auth_user_profile
after insert on auth.users
for each row execute function qnr_private.qnr_create_profile();

drop policy if exists profiles_read_self_or_admin on public.qnr_profiles;
create policy profiles_read_self_or_admin on public.qnr_profiles for select to authenticated
  using (id = auth.uid() or qnr_private.qnr_is_admin());
drop policy if exists roles_read_self_or_admin on public.qnr_user_roles;
create policy roles_read_self_or_admin on public.qnr_user_roles for select to authenticated
  using (user_id = auth.uid() or qnr_private.qnr_is_admin());
drop policy if exists audit_read_admin on public.qnr_audit_log;
create policy audit_read_admin on public.qnr_audit_log for select to authenticated
  using (qnr_private.qnr_is_admin());

drop policy if exists categories_read_published on public.qnr_categories;
create policy categories_read_published on public.qnr_categories for select to anon, authenticated
  using (is_published or qnr_private.qnr_is_admin());
drop policy if exists categories_admin_manage on public.qnr_categories;
create policy categories_admin_manage on public.qnr_categories for all to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
drop policy if exists products_read_published on public.qnr_products;
create policy products_read_published on public.qnr_products for select to anon, authenticated
  using (is_published or qnr_private.qnr_is_admin());
drop policy if exists products_admin_manage on public.qnr_products;
create policy products_admin_manage on public.qnr_products for all to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
drop policy if exists tutorials_read_published on public.qnr_tutorials;
create policy tutorials_read_published on public.qnr_tutorials for select to anon, authenticated
  using (is_published or qnr_private.qnr_is_admin());
drop policy if exists tutorials_admin_manage on public.qnr_tutorials;
create policy tutorials_admin_manage on public.qnr_tutorials for all to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
drop policy if exists courses_read_published on public.qnr_courses;
create policy courses_read_published on public.qnr_courses for select to anon, authenticated
  using (is_published or qnr_private.qnr_is_admin());
drop policy if exists courses_admin_manage on public.qnr_courses;
create policy courses_admin_manage on public.qnr_courses for all to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
drop policy if exists entitlements_read_self_or_admin on public.qnr_course_entitlements;
create policy entitlements_read_self_or_admin on public.qnr_course_entitlements for select to authenticated
  using (user_id = auth.uid() or qnr_private.qnr_is_admin());
drop policy if exists lessons_read_by_access on public.qnr_course_lessons;
create policy lessons_read_by_access on public.qnr_course_lessons for select to authenticated using (
  is_published and (
    access_type = 'free'
    or qnr_private.qnr_is_admin()
    or exists (
      select 1 from public.qnr_course_entitlements e
      where e.user_id = auth.uid()
        and e.course_id = qnr_course_lessons.course_id
        and (e.expires_at is null or e.expires_at > now())
    )
  )
);
drop policy if exists lessons_read_free on public.qnr_course_lessons;
create policy lessons_read_free on public.qnr_course_lessons for select to anon
  using (is_published and access_type = 'free');
drop policy if exists lessons_admin_manage on public.qnr_course_lessons;
create policy lessons_admin_manage on public.qnr_course_lessons for all to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());
drop policy if exists site_pages_read_published on public.qnr_site_pages;
create policy site_pages_read_published on public.qnr_site_pages for select to anon, authenticated
  using (is_published or qnr_private.qnr_is_admin());
drop policy if exists site_pages_admin_manage on public.qnr_site_pages;
create policy site_pages_admin_manage on public.qnr_site_pages for all to authenticated
  using (qnr_private.qnr_is_admin()) with check (qnr_private.qnr_is_admin());

revoke all on function public.qnr_is_admin() from public, anon, authenticated, service_role;
drop function public.qnr_is_admin();
revoke all on function public.qnr_create_profile() from public, anon, authenticated, service_role;
drop function public.qnr_create_profile();
