create or replace function qnr_private.qnr_audit_content_change()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
declare
  old_row jsonb := case when tg_op = 'INSERT' then null else to_jsonb(old) end;
  new_row jsonb := case when tg_op = 'DELETE' then null else to_jsonb(new) end;
  subject_id text := coalesce(new_row ->> 'id', old_row ->> 'id');
begin
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
  values (
    auth.uid(),
    lower(tg_op),
    tg_table_name,
    subject_id,
    jsonb_build_object(
      'old_slug', old_row ->> 'slug',
      'new_slug', new_row ->> 'slug',
      'old_published', old_row ->> 'is_published',
      'new_published', new_row ->> 'is_published'
    )
  );
  return coalesce(new, old);
end;
$$;
revoke all on function qnr_private.qnr_audit_content_change() from public, anon, authenticated, service_role;

create trigger qnr_categories_audit after insert or update or delete on public.qnr_categories
  for each row execute function qnr_private.qnr_audit_content_change();
create trigger qnr_products_audit after insert or update or delete on public.qnr_products
  for each row execute function qnr_private.qnr_audit_content_change();
create trigger qnr_tutorials_audit after insert or update or delete on public.qnr_tutorials
  for each row execute function qnr_private.qnr_audit_content_change();
create trigger qnr_courses_audit after insert or update or delete on public.qnr_courses
  for each row execute function qnr_private.qnr_audit_content_change();
create trigger qnr_course_lessons_audit after insert or update or delete on public.qnr_course_lessons
  for each row execute function qnr_private.qnr_audit_content_change();
create trigger qnr_site_pages_audit after insert or update or delete on public.qnr_site_pages
  for each row execute function qnr_private.qnr_audit_content_change();
