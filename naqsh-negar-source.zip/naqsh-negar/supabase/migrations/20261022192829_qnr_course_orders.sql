-- Add digital course purchases to the existing order and receipt flow.
-- Existing physical order items remain intact and continue to use the same RLS policy.
alter table public.qnr_order_items
  add column course_id uuid references public.qnr_courses(id) on delete restrict;

alter table public.qnr_order_items alter column product_id drop not null;

alter table public.qnr_order_items
  add constraint qnr_order_items_exactly_one_sellable_check
  check (
    (product_id is not null) <> (course_id is not null)
    and (course_id is null or quantity = 1)
  );

create index qnr_order_items_course_idx
  on public.qnr_order_items (course_id)
  where course_id is not null;

create or replace function public.qnr_create_order(
  p_user_id uuid,
  p_items jsonb,
  p_idempotency_key text,
  p_shipping jsonb,
  p_consent jsonb
)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  existing_order public.qnr_orders%rowtype;
  settings_row public.qnr_store_settings%rowtype;
  line record;
  product_row public.qnr_products%rowtype;
  course_row public.qnr_courses%rowtype;
  new_order public.qnr_orders%rowtype;
  subtotal bigint := 0;
  shipping_amount bigint := 0;
  line_total bigint;
  has_products boolean := false;
  privacy_version text;
  terms_version text;
begin
  if p_user_id is null or p_items is null or jsonb_typeof(p_items) <> 'array'
    or jsonb_array_length(p_items) < 1 or jsonb_array_length(p_items) > 50 then
    raise exception 'INVALID_ORDER' using errcode = '22023';
  end if;
  if p_idempotency_key !~ '^[A-Za-z0-9._:-]{8,128}$' then
    raise exception 'INVALID_IDEMPOTENCY_KEY' using errcode = '22023';
  end if;

  for line in select value as item from jsonb_array_elements(p_items) as entries(value) loop
    if jsonb_typeof(line.item) <> 'object'
      or (line.item ? 'product_id') = (line.item ? 'course_id')
      or coalesce(line.item ->> 'quantity', '') !~ '^[1-9][0-9]*$'
      or (line.item ->> 'quantity')::integer > 99 then
      raise exception 'INVALID_ORDER' using errcode = '22023';
    end if;
    if line.item ? 'course_id' and (line.item ->> 'quantity')::integer <> 1 then
      raise exception 'INVALID_ORDER' using errcode = '22023';
    end if;
  end loop;

  perform pg_advisory_xact_lock(hashtextextended(p_user_id::text || ':' || p_idempotency_key, 0));
  select * into existing_order from public.qnr_orders where user_id = p_user_id and idempotency_key = p_idempotency_key;
  if found then
    return jsonb_build_object('id', existing_order.id, 'order_number', existing_order.order_number, 'status', existing_order.status, 'total_amount', existing_order.total_amount);
  end if;

  perform public.qnr_expire_orders();

  select * into settings_row from public.qnr_store_settings where singleton = true;
  if not found or not settings_row.checkout_enabled then
    raise exception 'CHECKOUT_NOT_CONFIGURED' using errcode = '55000';
  end if;
  if coalesce(p_consent ->> 'privacy', 'false') <> 'true' or coalesce(p_consent ->> 'terms', 'false') <> 'true' then
    raise exception 'POLICY_CONSENT_REQUIRED' using errcode = '42501';
  end if;
  select updated_at::text into privacy_version from public.qnr_site_pages where slug = 'privacy' and is_published and body <> '[]'::jsonb;
  select updated_at::text into terms_version from public.qnr_site_pages where slug = 'terms' and is_published and body <> '[]'::jsonb;
  if privacy_version is null or terms_version is null then
    raise exception 'POLICY_PAGES_REQUIRED' using errcode = '55000';
  end if;

  select exists (
    select 1 from jsonb_array_elements(p_items) as entries(value) where value ? 'product_id'
  ) into has_products;
  if has_products and (
    jsonb_typeof(p_shipping) <> 'object'
    or length(trim(coalesce(p_shipping ->> 'full_name', ''))) < 3
    or length(trim(coalesce(p_shipping ->> 'phone', ''))) < 8
    or length(trim(coalesce(p_shipping ->> 'province', ''))) < 2
    or length(trim(coalesce(p_shipping ->> 'city', ''))) < 2
    or length(trim(coalesce(p_shipping ->> 'address', ''))) < 8
    or length(trim(coalesce(p_shipping ->> 'postal_code', ''))) < 5
  ) then
    raise exception 'INVALID_SHIPPING_ADDRESS' using errcode = '22023';
  end if;

  for line in
    select (entry ->> 'product_id')::uuid as product_id, sum((entry ->> 'quantity')::integer)::integer as quantity
    from jsonb_array_elements(p_items) entry
    where entry ? 'product_id'
    group by (entry ->> 'product_id')::uuid
    order by (entry ->> 'product_id')::uuid
  loop
    if line.quantity < 1 or line.quantity > 99 then raise exception 'INVALID_QUANTITY' using errcode = '22023'; end if;
    select * into product_row from public.qnr_products where id = line.product_id for update;
    if not found or not product_row.is_published or product_row.price_amount is null then
      raise exception 'PRODUCT_UNAVAILABLE' using errcode = 'P0001';
    end if;
    if product_row.inventory_count < line.quantity then
      raise exception 'INSUFFICIENT_STOCK' using errcode = 'P0001';
    end if;
    line_total := product_row.price_amount * line.quantity;
    subtotal := subtotal + line_total;
  end loop;

  for line in
    select (entry ->> 'course_id')::uuid as course_id,
      sum((entry ->> 'quantity')::integer)::integer as quantity,
      count(*)::integer as line_count
    from jsonb_array_elements(p_items) entry
    where entry ? 'course_id'
    group by (entry ->> 'course_id')::uuid
    order by (entry ->> 'course_id')::uuid
  loop
    if line.quantity <> 1 or line.line_count <> 1 then
      raise exception 'INVALID_ORDER' using errcode = '22023';
    end if;
    select * into course_row from public.qnr_courses where id = line.course_id for update;
    if not found or not course_row.is_published or course_row.price_amount is null
      or course_row.price_amount <= 0 or course_row.currency <> 'IRR' then
      raise exception 'COURSE_UNAVAILABLE' using errcode = 'P0001';
    end if;
    if exists (
      select 1 from public.qnr_course_entitlements entitlement
      where entitlement.user_id = p_user_id and entitlement.course_id = course_row.id
        and (entitlement.expires_at is null or entitlement.expires_at > now())
    ) or exists (
      select 1 from public.qnr_order_items item
      join public.qnr_orders existing on existing.id = item.order_id
      where item.course_id = course_row.id and existing.user_id = p_user_id
        and existing.status in ('awaiting_payment', 'payment_review', 'paid')
    ) then
      raise exception 'COURSE_PURCHASE_EXISTS' using errcode = 'P0001';
    end if;
    subtotal := subtotal + course_row.price_amount;
  end loop;

  if has_products then shipping_amount := settings_row.shipping_amount; end if;

  insert into public.qnr_orders (order_number, user_id, idempotency_key, status, subtotal_amount, shipping_amount, total_amount, currency, shipping_snapshot, consent_versions, reservation_expires_at)
  values (
    'NN-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)),
    p_user_id,
    p_idempotency_key,
    'awaiting_payment',
    subtotal,
    shipping_amount,
    subtotal + shipping_amount,
    'IRR',
    case when has_products then p_shipping else jsonb_build_object('delivery', 'digital') end,
    jsonb_build_object('privacy_updated_at', privacy_version, 'terms_updated_at', terms_version),
    now() + make_interval(mins => settings_row.reservation_minutes)
  ) returning * into new_order;

  for line in
    select (entry ->> 'product_id')::uuid as product_id, sum((entry ->> 'quantity')::integer)::integer as quantity
    from jsonb_array_elements(p_items) entry
    where entry ? 'product_id'
    group by (entry ->> 'product_id')::uuid
    order by (entry ->> 'product_id')::uuid
  loop
    select * into product_row from public.qnr_products where id = line.product_id;
    insert into public.qnr_order_items (order_id, product_id, product_name, quantity, unit_price_amount, line_total_amount, currency)
      values (new_order.id, product_row.id, product_row.name, line.quantity, product_row.price_amount, product_row.price_amount * line.quantity, product_row.currency);
    update public.qnr_products set inventory_count = inventory_count - line.quantity where id = product_row.id;
    delete from public.qnr_cart_items where user_id = p_user_id and product_id = product_row.id;
  end loop;

  for line in
    select (entry ->> 'course_id')::uuid as course_id
    from jsonb_array_elements(p_items) entry
    where entry ? 'course_id'
    order by (entry ->> 'course_id')::uuid
  loop
    select * into course_row from public.qnr_courses where id = line.course_id;
    insert into public.qnr_order_items (order_id, course_id, product_name, quantity, unit_price_amount, line_total_amount, currency)
      values (new_order.id, course_row.id, course_row.title, 1, course_row.price_amount, course_row.price_amount, course_row.currency);
  end loop;

  insert into public.qnr_order_events (order_id, actor_id, event_type, details)
    values (new_order.id, p_user_id, 'created', jsonb_build_object('status', 'awaiting_payment', 'digital_course_order', not has_products));

  return jsonb_build_object('id', new_order.id, 'order_number', new_order.order_number, 'status', new_order.status, 'subtotal_amount', new_order.subtotal_amount, 'shipping_amount', new_order.shipping_amount, 'total_amount', new_order.total_amount, 'reservation_expires_at', new_order.reservation_expires_at);
end;
$$;
revoke all on function public.qnr_create_order(uuid, jsonb, text, jsonb, jsonb) from public, anon, authenticated;
grant execute on function public.qnr_create_order(uuid, jsonb, text, jsonb, jsonb) to service_role;

create or replace function public.qnr_review_payment(p_actor_id uuid, p_payment_id uuid, p_decision text, p_reason text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  payment_row public.qnr_manual_payments%rowtype;
  order_row public.qnr_orders%rowtype;
  order_line record;
begin
  if not exists (select 1 from public.qnr_user_roles where user_id = p_actor_id and role = 'admin') then
    raise exception 'ADMIN_REQUIRED' using errcode = '42501';
  end if;
  if p_decision not in ('approved', 'rejected') or (p_decision = 'rejected' and length(trim(coalesce(p_reason, ''))) < 4) then
    raise exception 'INVALID_REVIEW_DECISION' using errcode = '22023';
  end if;

  perform public.qnr_expire_orders();
  select * into payment_row from public.qnr_manual_payments where id = p_payment_id for update;
  if not found or payment_row.status <> 'pending' then
    return jsonb_build_object('status', coalesce(payment_row.status, 'not_found'));
  end if;
  select * into order_row from public.qnr_orders where id = payment_row.order_id for update;
  if order_row.status not in ('awaiting_payment', 'payment_review') then
    return jsonb_build_object('status', order_row.status, 'order_id', order_row.id);
  end if;

  update public.qnr_manual_payments
    set status = p_decision, review_reason = nullif(trim(p_reason), ''), reviewed_by = p_actor_id, reviewed_at = now()
    where id = p_payment_id;
  if p_decision = 'approved' then
    update public.qnr_orders set status = 'paid' where id = order_row.id;
    for order_line in select course_id from public.qnr_order_items where order_id = order_row.id and course_id is not null loop
      insert into public.qnr_course_entitlements (user_id, course_id, source, expires_at)
        values (order_row.user_id, order_line.course_id, 'purchase', null)
      on conflict (user_id, course_id) do update
        set source = 'purchase', granted_at = now(), expires_at = null;
    end loop;
  else
    update public.qnr_orders set status = 'payment_rejected' where id = order_row.id;
    for order_line in select product_id, quantity from public.qnr_order_items where order_id = order_row.id and product_id is not null loop
      update public.qnr_products set inventory_count = inventory_count + order_line.quantity where id = order_line.product_id;
    end loop;
  end if;
  insert into public.qnr_order_events (order_id, actor_id, event_type, reason, details)
    values (order_row.id, p_actor_id, p_decision, nullif(trim(p_reason), ''), jsonb_build_object('payment_id', p_payment_id));
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, reason, details)
    values (p_actor_id, 'review_' || p_decision, 'qnr_manual_payments', p_payment_id::text, nullif(trim(p_reason), ''), jsonb_build_object('order_id', order_row.id));
  return jsonb_build_object('status', p_decision, 'order_id', order_row.id);
end;
$$;
revoke all on function public.qnr_review_payment(uuid, uuid, text, text) from public, anon, authenticated;
grant execute on function public.qnr_review_payment(uuid, uuid, text, text) to service_role;
