create table public.qnr_support_tickets (
  id uuid primary key default gen_random_uuid(),
  ticket_number text not null unique,
  user_id uuid not null references auth.users(id) on delete cascade,
  subject text not null check (length(trim(subject)) between 5 and 120),
  status text not null default 'waiting_staff' check (status in ('waiting_staff', 'waiting_user', 'closed')),
  priority text not null default 'normal' check (priority in ('normal', 'high')),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  last_message_at timestamptz not null default now()
);

create table public.qnr_support_messages (
  id uuid primary key default gen_random_uuid(),
  ticket_id uuid not null references public.qnr_support_tickets(id) on delete cascade,
  sender_id uuid references auth.users(id) on delete set null,
  sender_role text not null check (sender_role in ('customer', 'staff')),
  body text not null check (length(trim(body)) between 1 and 5000),
  created_at timestamptz not null default now()
);

create table public.qnr_notifications (
  id uuid primary key default gen_random_uuid(),
  recipient_id uuid not null references auth.users(id) on delete cascade,
  notification_type text not null check (notification_type in ('support_new', 'support_reply', 'order_update', 'payment_update', 'learning_update', 'system')),
  title text not null check (length(trim(title)) between 1 and 120),
  body text not null default '' check (length(body) <= 300),
  target_path text,
  read_at timestamptz,
  created_at timestamptz not null default now()
);

create index qnr_support_tickets_user_recent_idx on public.qnr_support_tickets (user_id, last_message_at desc);
create index qnr_support_tickets_queue_idx on public.qnr_support_tickets (status, last_message_at desc);
create index qnr_support_messages_ticket_recent_idx on public.qnr_support_messages (ticket_id, created_at);
create index qnr_notifications_user_recent_idx on public.qnr_notifications (recipient_id, created_at desc);
create index qnr_notifications_user_unread_idx on public.qnr_notifications (recipient_id, created_at desc) where read_at is null;

create trigger qnr_support_tickets_touch_updated_at before update on public.qnr_support_tickets
  for each row execute function public.qnr_touch_updated_at();
alter table public.qnr_support_tickets enable row level security;
alter table public.qnr_support_messages enable row level security;
alter table public.qnr_notifications enable row level security;

create policy qnr_support_tickets_read_owner_admin on public.qnr_support_tickets for select to authenticated
  using (user_id = (select auth.uid()) or qnr_private.qnr_is_admin());
create policy qnr_support_messages_read_owner_admin on public.qnr_support_messages for select to authenticated
  using (exists (select 1 from public.qnr_support_tickets t where t.id = ticket_id and (t.user_id = (select auth.uid()) or qnr_private.qnr_is_admin())));
create policy qnr_notifications_read_own on public.qnr_notifications for select to authenticated
  using (recipient_id = (select auth.uid()));
create policy qnr_notifications_update_own on public.qnr_notifications for update to authenticated
  using (recipient_id = (select auth.uid())) with check (recipient_id = (select auth.uid()));

revoke all on public.qnr_support_tickets, public.qnr_support_messages, public.qnr_notifications from anon, authenticated;
grant select on public.qnr_support_tickets, public.qnr_support_messages, public.qnr_notifications to authenticated;
grant update(read_at) on public.qnr_notifications to authenticated;

create or replace function public.qnr_open_support_ticket(p_subject text, p_body text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  actor uuid := auth.uid();
  ticket_row public.qnr_support_tickets%rowtype;
  recent_count integer;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if length(trim(coalesce(p_subject, ''))) not between 5 and 120
    or length(trim(coalesce(p_body, ''))) not between 1 and 5000 then
    raise exception 'INVALID_SUPPORT_MESSAGE' using errcode = '22023';
  end if;
  perform pg_advisory_xact_lock(hashtextextended(actor::text || ':support-open', 0));
  select count(*) into recent_count from public.qnr_support_tickets
    where user_id = actor and created_at > now() - interval '1 hour';
  if recent_count >= 5 then raise exception 'SUPPORT_RATE_LIMIT' using errcode = '42900'; end if;

  insert into public.qnr_support_tickets (ticket_number, user_id, subject)
  values ('SP-' || to_char(now(), 'YYMMDD') || '-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8)), actor, trim(p_subject))
  returning * into ticket_row;
  insert into public.qnr_support_messages (ticket_id, sender_id, sender_role, body)
    values (ticket_row.id, actor, 'customer', trim(p_body));
  insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
    select user_id, 'support_new', 'درخواست پشتیبانی تازه', 'درخواست تازه‌ای در صندوق پشتیبانی ثبت شد.', '/admin'
    from public.qnr_user_roles where role = 'admin';
  return jsonb_build_object('id', ticket_row.id, 'ticket_number', ticket_row.ticket_number, 'status', ticket_row.status);
end;
$$;
revoke all on function public.qnr_open_support_ticket(text, text) from public, anon, authenticated;
grant execute on function public.qnr_open_support_ticket(text, text) to authenticated;

create or replace function public.qnr_reply_support_ticket(p_ticket_id uuid, p_body text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  actor uuid := auth.uid();
  ticket_row public.qnr_support_tickets%rowtype;
  actor_is_staff boolean;
  new_status text;
begin
  if actor is null then raise exception 'AUTH_REQUIRED' using errcode = '42501'; end if;
  if length(trim(coalesce(p_body, ''))) not between 1 and 5000 then
    raise exception 'INVALID_SUPPORT_MESSAGE' using errcode = '22023';
  end if;
  select * into ticket_row from public.qnr_support_tickets where id = p_ticket_id for update;
  if not found then raise exception 'TICKET_NOT_FOUND' using errcode = 'P0002'; end if;
  actor_is_staff := qnr_private.qnr_is_admin();
  if ticket_row.user_id <> actor and not actor_is_staff then raise exception 'TICKET_ACCESS_DENIED' using errcode = '42501'; end if;
  if ticket_row.status = 'closed' and not actor_is_staff then raise exception 'TICKET_CLOSED' using errcode = '55000'; end if;
  new_status := case when actor_is_staff then 'waiting_user' else 'waiting_staff' end;
  insert into public.qnr_support_messages (ticket_id, sender_id, sender_role, body)
    values (ticket_row.id, actor, case when actor_is_staff then 'staff' else 'customer' end, trim(p_body));
  update public.qnr_support_tickets set status = new_status, last_message_at = now() where id = ticket_row.id;
  if actor_is_staff then
    insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
      values (ticket_row.user_id, 'support_reply', 'پاسخ پشتیبانی آماده است', 'برای دیدن پاسخ، صندوق پشتیبانی را باز کن.', '/support');
  else
    insert into public.qnr_notifications (recipient_id, notification_type, title, body, target_path)
      select user_id, 'support_reply', 'پاسخ تازه به درخواست پشتیبانی', 'کاربر به درخواست پشتیبانی پاسخ داد.', '/admin'
      from public.qnr_user_roles where role = 'admin';
  end if;
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
    values (actor, 'reply', 'qnr_support_tickets', ticket_row.id::text, jsonb_build_object('ticket_number', ticket_row.ticket_number, 'actor_role', case when actor_is_staff then 'staff' else 'customer' end));
  return jsonb_build_object('ticket_id', ticket_row.id, 'status', new_status);
end;
$$;
revoke all on function public.qnr_reply_support_ticket(uuid, text) from public, anon, authenticated;
grant execute on function public.qnr_reply_support_ticket(uuid, text) to authenticated;

create or replace function public.qnr_update_support_ticket(p_ticket_id uuid, p_status text, p_priority text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  actor uuid := auth.uid();
  ticket_row public.qnr_support_tickets%rowtype;
begin
  if actor is null or not qnr_private.qnr_is_admin() then raise exception 'ADMIN_REQUIRED' using errcode = '42501'; end if;
  if p_status not in ('waiting_staff', 'waiting_user', 'closed') or p_priority not in ('normal', 'high') then
    raise exception 'INVALID_TICKET_STATUS' using errcode = '22023';
  end if;
  update public.qnr_support_tickets set status = p_status, priority = p_priority where id = p_ticket_id returning * into ticket_row;
  if not found then raise exception 'TICKET_NOT_FOUND' using errcode = 'P0002'; end if;
  insert into public.qnr_audit_log (actor_id, action, subject_type, subject_id, details)
    values (actor, 'update', 'qnr_support_tickets', ticket_row.id::text, jsonb_build_object('status', p_status, 'priority', p_priority, 'ticket_number', ticket_row.ticket_number));
  return jsonb_build_object('id', ticket_row.id, 'status', ticket_row.status, 'priority', ticket_row.priority);
end;
$$;
revoke all on function public.qnr_update_support_ticket(uuid, text, text) from public, anon, authenticated;
grant execute on function public.qnr_update_support_ticket(uuid, text, text) to authenticated;

comment on table public.qnr_support_tickets is 'Private support tickets with customer and staff replies.';
comment on table public.qnr_notifications is 'Private in-app notifications; sensitive payment and OTP values are never stored here.';
