import assert from 'node:assert/strict'
import test from 'node:test'
import { isChatNonce, normalizeChatMessage } from './chat-validation.ts'

test('trims chat text while preserving Persian and line breaks', () => {
  assert.deepEqual(normalizeChatMessage('  سلام به همه  \r\nاز دوخت امروز بگوییم  '), { ok: true, body: 'سلام به همه\nاز دوخت امروز بگوییم' })
})

test('accepts the exact 5,000-character message limit', () => {
  const result = normalizeChatMessage('ن'.repeat(5000))
  assert.equal(result.ok, true)
  if (result.ok) assert.equal([...result.body].length, 5000)
})

test('rejects a message one character over the limit', () => {
  assert.deepEqual(normalizeChatMessage('ن'.repeat(5001)), { ok: false, error: 'too_long' })
})

test('rejects an empty message body', () => {
  assert.deepEqual(normalizeChatMessage('  \n\t  '), { ok: false, error: 'empty' })
})

test('rejects control characters while allowing tabs and newlines', () => {
  assert.deepEqual(normalizeChatMessage('متن\u0007مخفی'), { ok: false, error: 'control_characters' })
  assert.equal(normalizeChatMessage('ردیف اول\nردیف دوم').ok, true)
})

test('accepts a valid RFC UUID idempotency nonce', () => {
  assert.equal(isChatNonce('f67d5ed8-1b67-4f16-aee8-63a1a2a3f146'), true)
})

test('rejects missing, malformed, and non-RFC idempotency nonces', () => {
  assert.equal(isChatNonce(null), false)
  assert.equal(isChatNonce('not-a-uuid'), false)
  assert.equal(isChatNonce('f67d5ed8-1b67-0f16-7ee8-63a1a2a3f146'), false)
})
