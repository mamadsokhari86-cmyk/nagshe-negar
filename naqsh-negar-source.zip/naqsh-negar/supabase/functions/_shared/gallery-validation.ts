export const GALLERY_IMAGE_LIMIT = 10 * 1024 * 1024

export type GalleryImageValidation =
  | { ok: true; extension: 'jpg' | 'png' | 'webp'; mimeType: 'image/jpeg' | 'image/png' | 'image/webp' }
  | { ok: false; error: 'too_large' | 'unsupported_type' | 'invalid_signature' }

export async function validateGalleryImage(file: Pick<File, 'type' | 'size' | 'slice'>): Promise<GalleryImageValidation> {
  if (!Number.isFinite(file.size) || file.size <= 0) return { ok: false, error: 'invalid_signature' }
  if (file.size > GALLERY_IMAGE_LIMIT) return { ok: false, error: 'too_large' }

  const mimeType = file.type.toLowerCase()
  if (mimeType !== 'image/jpeg' && mimeType !== 'image/png' && mimeType !== 'image/webp') {
    return { ok: false, error: 'unsupported_type' }
  }

  let header: Uint8Array
  try {
    header = new Uint8Array(await file.slice(0, 12).arrayBuffer())
  } catch {
    return { ok: false, error: 'invalid_signature' }
  }

  const valid = mimeType === 'image/jpeg'
    ? header[0] === 0xff && header[1] === 0xd8 && header[2] === 0xff
    : mimeType === 'image/png'
      ? header.length >= 8 && [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a].every((value, index) => header[index] === value)
      : header.length >= 12
        && header[0] === 0x52 && header[1] === 0x49 && header[2] === 0x46 && header[3] === 0x46
        && header[8] === 0x57 && header[9] === 0x45 && header[10] === 0x42 && header[11] === 0x50

  if (!valid) return { ok: false, error: 'invalid_signature' }
  const extension = mimeType === 'image/jpeg' ? 'jpg' : mimeType === 'image/png' ? 'png' : 'webp'
  return { ok: true, extension, mimeType }
}

export type GalleryTextResult =
  | { ok: true; title: string; caption: string }
  | { ok: false; error: 'title_length' | 'caption_too_long' }

export function normalizeGalleryText(title: string, caption: string): GalleryTextResult {
  const normalizedTitle = title.trim().replace(/\s+/gu, ' ')
  const normalizedCaption = caption.replace(/\r\n?/gu, '\n').trim()
  const titleLength = [...normalizedTitle].length
  if (titleLength < 2 || titleLength > 100) return { ok: false, error: 'title_length' }
  if ([...normalizedCaption].length > 1000) return { ok: false, error: 'caption_too_long' }
  return { ok: true, title: normalizedTitle, caption: normalizedCaption }
}

function joinBytes(parts: Uint8Array[]): Uint8Array {
  const size = parts.reduce((sum, part) => sum + part.length, 0)
  const joined = new Uint8Array(size)
  let offset = 0
  for (const part of parts) { joined.set(part, offset); offset += part.length }
  return joined
}

function readU32be(bytes: Uint8Array, offset: number): number {
  return ((bytes[offset] << 24) | (bytes[offset + 1] << 16) | (bytes[offset + 2] << 8) | bytes[offset + 3]) >>> 0
}

function readU32le(bytes: Uint8Array, offset: number): number {
  return (bytes[offset] | (bytes[offset + 1] << 8) | (bytes[offset + 2] << 16) | (bytes[offset + 3] << 24)) >>> 0
}

function writeU32le(bytes: Uint8Array, offset: number, value: number) {
  bytes[offset] = value & 0xff
  bytes[offset + 1] = (value >>> 8) & 0xff
  bytes[offset + 2] = (value >>> 16) & 0xff
  bytes[offset + 3] = (value >>> 24) & 0xff
}

function decodeAscii(bytes: Uint8Array, start: number, length: number): string {
  return String.fromCharCode(...bytes.subarray(start, start + length))
}

function stripJpegMetadata(bytes: Uint8Array): Uint8Array | null {
  if (bytes.length < 4 || bytes[0] !== 0xff || bytes[1] !== 0xd8) return null
  const parts = [bytes.subarray(0, 2)]
  let offset = 2
  let foundScan = false
  let foundEnd = false
  let inScan = false
  while (offset < bytes.length) {
    if (inScan) {
      let cursor = offset
      let markerStart = -1
      while (cursor < bytes.length) {
        if (bytes[cursor] !== 0xff) { cursor++; continue }
        let markerOffset = cursor + 1
        while (markerOffset < bytes.length && bytes[markerOffset] === 0xff) markerOffset++
        if (markerOffset >= bytes.length) return null
        const marker = bytes[markerOffset]
        if (marker === 0x00 || (marker >= 0xd0 && marker <= 0xd7)) { cursor = markerOffset + 1; continue }
        markerStart = cursor
        break
      }
      if (markerStart < 0) return null
      parts.push(bytes.subarray(offset, markerStart))
      offset = markerStart
      inScan = false
    }
    const start = offset
    if (bytes[offset] !== 0xff) return null
    while (offset < bytes.length && bytes[offset] === 0xff) offset++
    if (offset >= bytes.length) return null
    const marker = bytes[offset++]
    if (marker === 0xd9) {
      parts.push(bytes.subarray(start, offset))
      foundEnd = offset === bytes.length
      break
    }
    if (marker === 0xda) {
      if (offset + 2 > bytes.length) return null
      const segmentLength = (bytes[offset] << 8) | bytes[offset + 1]
      const end = offset + segmentLength
      if (segmentLength < 2 || end > bytes.length) return null
      parts.push(bytes.subarray(start, end))
      offset = end
      foundScan = true
      inScan = true
      continue
    }
    if (marker === 0x01) {
      parts.push(bytes.subarray(start, offset))
      continue
    }
    if (marker === 0xd8 || (marker >= 0xd0 && marker <= 0xd7)) return null
    if (offset + 2 > bytes.length) return null
    const segmentLength = (bytes[offset] << 8) | bytes[offset + 1]
    const end = offset + segmentLength
    if (segmentLength < 2 || end > bytes.length) return null
    if (!(marker >= 0xe0 && marker <= 0xef) && marker !== 0xfe) parts.push(bytes.subarray(start, end))
    offset = end
  }
  if (!foundScan || !foundEnd) return null
  return joinBytes(parts)
}

function stripPngMetadata(bytes: Uint8Array): Uint8Array | null {
  const signature = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]
  if (bytes.length < 20 || !signature.every((value, index) => bytes[index] === value)) return null
  const parts = [bytes.subarray(0, 8)]
  const keep = new Set(['IHDR', 'PLTE', 'IDAT', 'IEND', 'tRNS', 'bKGD', 'cHRM', 'gAMA', 'sRGB', 'sBIT', 'pHYs', 'hIST', 'acTL', 'fcTL', 'fdAT'])
  let offset = 8
  let seenHeader = false
  let seenData = false
  let seenEnd = false
  while (offset + 12 <= bytes.length) {
    const length = readU32be(bytes, offset)
    const end = offset + length + 12
    if (end > bytes.length) return null
    const type = decodeAscii(bytes, offset + 4, 4)
    if (!seenHeader && type !== 'IHDR') return null
    if (type === 'IHDR') seenHeader = true
    if (type === 'IDAT') seenData = true
    if (type === 'IEND') {
      if (length !== 0 || !seenHeader || !seenData) return null
      parts.push(bytes.subarray(offset, end))
      seenEnd = true
      if (end !== bytes.length) return null
      break
    }
    if (keep.has(type)) parts.push(bytes.subarray(offset, end))
    else if (type.charCodeAt(0) >= 0x41 && type.charCodeAt(0) <= 0x5a) return null
    offset = end
  }
  if (!seenEnd) return null
  return joinBytes(parts)
}

function stripWebpMetadata(bytes: Uint8Array): Uint8Array | null {
  if (bytes.length < 30 || decodeAscii(bytes, 0, 4) !== 'RIFF' || decodeAscii(bytes, 8, 4) !== 'WEBP'
    || readU32le(bytes, 4) !== bytes.length - 8) return null
  const parts = [bytes.subarray(0, 12)]
  const keep = new Set(['VP8 ', 'VP8L', 'VP8X', 'ALPH', 'ANIM', 'ANMF'])
  let offset = 12
  let seenImage = false
  let seenEnd = false
  let removedExif = false
  let removedXmp = false
  let removedIccp = false
  let extendedHeader: Uint8Array | null = null
  while (offset + 8 <= bytes.length) {
    const start = offset
    const type = decodeAscii(bytes, offset, 4)
    const length = readU32le(bytes, offset + 4)
    const end = offset + 8 + length + (length & 1)
    if (end > bytes.length) return null
    if (type === 'VP8 ' || type === 'VP8L') seenImage = true
    if (type === 'VP8X') {
      if (length !== 10) return null
      const header = bytes.subarray(start, end).slice()
      extendedHeader = header
      parts.push(header)
      offset = end
      continue
    }
    if (type === 'EXIF') removedExif = true
    else if (type === 'XMP ') removedXmp = true
    else if (type === 'ICCP') removedIccp = true
    else if (keep.has(type)) parts.push(bytes.subarray(start, end))
    offset = end
    if (offset === bytes.length) { seenEnd = true; break }
  }
  if (!seenImage || !seenEnd) return null
  if (extendedHeader) {
    if (removedIccp) extendedHeader[8] &= ~0x01
    if (removedExif) extendedHeader[8] &= ~0x08
    if (removedXmp) extendedHeader[8] &= ~0x04
  }
  const sanitized = joinBytes(parts)
  writeU32le(sanitized, 4, sanitized.length - 8)
  return sanitized
}

/** Removes metadata chunks that can carry location or creator details before an image can be published. */
export function stripGalleryImageMetadata(bytes: Uint8Array, mimeType: string): Uint8Array | null {
  if (mimeType === 'image/jpeg') return stripJpegMetadata(bytes)
  if (mimeType === 'image/png') return stripPngMetadata(bytes)
  if (mimeType === 'image/webp') return stripWebpMetadata(bytes)
  return null
}
