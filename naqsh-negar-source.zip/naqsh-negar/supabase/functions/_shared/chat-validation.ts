export const CHAT_MESSAGE_LIMIT = 5000

export type ChatMessageValidation =
  | { ok: true; body: string }
  | { ok: false; error: 'empty' | 'too_long' | 'control_characters' }

export function normalizeChatMessage(raw: string): ChatMessageValidation {
  const body = raw.replace(/\r\n?/gu, '\n').replace(/\t/gu, ' ').split('\n').map((line) => line.trimEnd()).join('\n').trim()
  if ([...body].length > CHAT_MESSAGE_LIMIT) return { ok: false, error: 'too_long' }
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/u.test(body)) return { ok: false, error: 'control_characters' }
  if (!body) return { ok: false, error: 'empty' }
  return { ok: true, body }
}

export function isChatNonce(value: unknown): value is string {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu.test(value)
}
