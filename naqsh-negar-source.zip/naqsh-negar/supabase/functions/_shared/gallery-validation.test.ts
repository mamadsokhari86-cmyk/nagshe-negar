import assert from 'node:assert/strict'
import test from 'node:test'
import { GALLERY_IMAGE_LIMIT, normalizeGalleryText, stripGalleryImageMetadata, validateGalleryImage } from './gallery-validation.ts'

function concat(...parts: ArrayLike<number>[]) { return Uint8Array.from(parts.flatMap((part) => Array.from(part))) }
function pngChunk(type: string, data: number[]) {
  const length = data.length
  return [length >>> 24, length >>> 16 & 0xff, length >>> 8 & 0xff, length & 0xff, ...Array.from(type).map((char) => char.charCodeAt(0)), ...data, 0, 0, 0, 0]
}
function webpChunk(type: string, data: number[]) {
  const length = data.length
  return [...Array.from(type).map((char) => char.charCodeAt(0)), length & 0xff, length >>> 8 & 0xff, length >>> 16 & 0xff, length >>> 24 & 0xff, ...data, ...(length % 2 ? [0] : [])]
}

function image(bytes: number[], type: string, size = bytes.length, name = 'piece.bin') {
  const blob = new Blob([Uint8Array.from(bytes)])
  return { name, type, size, slice: () => blob } as File
}

test('accepts a valid JPEG at the 10 MiB limit', async () => {
  const result = await validateGalleryImage(image([0xff, 0xd8, 0xff, 0x00], 'image/jpeg', GALLERY_IMAGE_LIMIT, 'work.jpg'))
  assert.deepEqual(result, { ok: true, extension: 'jpg', mimeType: 'image/jpeg' })
})

test('accepts PNG and WebP signatures independent of file names', async () => {
  const png = await validateGalleryImage(image([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], 'image/png'))
  const webp = await validateGalleryImage(image([0x52, 0x49, 0x46, 0x46, 0x00, 0x00, 0x00, 0x00, 0x57, 0x45, 0x42, 0x50], 'image/webp'))
  assert.deepEqual(png, { ok: true, extension: 'png', mimeType: 'image/png' })
  assert.deepEqual(webp, { ok: true, extension: 'webp', mimeType: 'image/webp' })
})

test('rejects an image over the 10 MiB limit before reading bytes', async () => {
  const tooLarge = { ...image([0xff, 0xd8, 0xff], 'image/jpeg'), size: GALLERY_IMAGE_LIMIT + 1, slice: () => { throw new Error('must not read') } } as File
  assert.deepEqual(await validateGalleryImage(tooLarge), { ok: false, error: 'too_large' })
})

test('rejects MIME and file signature mismatches', async () => {
  assert.deepEqual(await validateGalleryImage(image([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a], 'image/jpeg')), { ok: false, error: 'invalid_signature' })
})

test('rejects SVG and unsupported media types', async () => {
  assert.deepEqual(await validateGalleryImage(image([0x3c, 0x73, 0x76, 0x67], 'image/svg+xml', 4, 'art.svg')), { ok: false, error: 'unsupported_type' })
})

test('trims text and enforces title and caption bounds', () => {
  assert.deepEqual(normalizeGalleryText('  نقش تازه  ', '  رنگ و پارچه  '), { ok: true, title: 'نقش تازه', caption: 'رنگ و پارچه' })
  assert.deepEqual(normalizeGalleryText('ا', ''), { ok: false, error: 'title_length' })
  assert.deepEqual(normalizeGalleryText('ن'.repeat(101), ''), { ok: false, error: 'title_length' })
  assert.deepEqual(normalizeGalleryText('عنوان', 'ت'.repeat(1001)), { ok: false, error: 'caption_too_long' })
})

test('strips JPEG EXIF and comment segments before publishing', () => {
  const jpeg = concat([0xff, 0xd8], [0xff, 0xe1, 0, 10, 0x45, 0x78, 0x69, 0x66, 0, 0, 1, 2], [0xff, 0xfe, 0, 5, 65, 66, 67], [0xff, 0xda, 0, 8, 1, 1, 0, 0, 0x3f, 0], [1, 2, 0xff, 0xd9])
  const sanitized = stripGalleryImageMetadata(jpeg, 'image/jpeg')
  assert.ok(sanitized)
  assert.equal(new TextDecoder().decode(sanitized).includes('Exif'), false)
  assert.equal(sanitized.at(-1), 0xd9)
})

test('strips metadata markers between progressive JPEG scans', () => {
  const jpeg = concat([0xff, 0xd8], [0xff, 0xda, 0, 8, 1, 1, 0, 0, 0x3f, 0], [1, 0xff, 0, 2], [0xff, 0xe1, 0, 10, 0x45, 0x78, 0x69, 0x66, 0, 0, 1, 2], [0xff, 0xda, 0, 8, 1, 1, 0, 0, 0x3f, 0], [3, 4, 0xff, 0xd9])
  const sanitized = stripGalleryImageMetadata(jpeg, 'image/jpeg')
  assert.ok(sanitized)
  assert.equal(new TextDecoder().decode(sanitized).includes('Exif'), false)
  assert.equal(sanitized.at(-1), 0xd9)
})

test('strips PNG text and EXIF chunks while keeping image data', () => {
  const signature = [0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a]
  const png = concat(signature, pngChunk('IHDR', Array(13).fill(0)), pngChunk('eXIf', [1, 2, 3]), pngChunk('tEXt', [65, 0, 66]), pngChunk('IDAT', [9, 8, 7]), pngChunk('IEND', []))
  const sanitized = stripGalleryImageMetadata(png, 'image/png')
  assert.ok(sanitized)
  const output = new TextDecoder().decode(sanitized)
  assert.equal(output.includes('eXIf'), false)
  assert.equal(output.includes('tEXt'), false)
  assert.equal(output.includes('IDAT'), true)
})

test('strips WebP EXIF and XMP chunks and clears feature flags', () => {
  const vp8x = webpChunk('VP8X', [0x0c, ...Array(9).fill(0)])
  const exif = webpChunk('EXIF', [1, 2, 3])
  const xmp = webpChunk('XMP ', [4, 5])
  const imageChunk = webpChunk('VP8L', [0x2f, 1, 2, 3, 4])
  const payload = concat(Array.from('WEBP').map((char) => char.charCodeAt(0)), vp8x, exif, xmp, imageChunk)
  const header = concat(Array.from('RIFF').map((char) => char.charCodeAt(0)), [payload.length & 0xff, payload.length >>> 8 & 0xff, payload.length >>> 16 & 0xff, payload.length >>> 24 & 0xff], payload)
  const sanitized = stripGalleryImageMetadata(header, 'image/webp')
  assert.ok(sanitized)
  const output = new TextDecoder().decode(sanitized)
  assert.equal(output.includes('EXIF'), false)
  assert.equal(output.includes('XMP '), false)
  assert.equal(sanitized[20] & 0x0c, 0)
})

test('rejects malformed image containers from the server sanitizer', () => {
  assert.equal(stripGalleryImageMetadata(Uint8Array.from([0xff, 0xd8, 0, 0]), 'image/jpeg'), null)
})
