import { createClient } from 'npm:@supabase/supabase-js@2'
import { parseOrderLines } from './order-lines.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
  })
}

function errorMessage(code: string) {
  const messages: Record<string, string> = {
    CHECKOUT_NOT_CONFIGURED: 'ثبت سفارش هنوز از سوی فروشگاه فعال نشده است.',
    POLICY_PAGES_REQUIRED: 'صفحه‌های حریم خصوصی و شرایط فروش باید منتشر شوند.',
    POLICY_CONSENT_REQUIRED: 'برای ثبت سفارش، تأیید هر دو سیاست لازم است.',
    INVALID_SHIPPING_ADDRESS: 'اطلاعات ارسال کامل نیست.',
    PRODUCT_UNAVAILABLE: 'یکی از کالاها دیگر برای سفارش در دسترس نیست.',
    INSUFFICIENT_STOCK: 'موجودی یکی از کالاها برای این تعداد کافی نیست.',
    COURSE_UNAVAILABLE: 'این دوره برای خرید در دسترس نیست یا قیمت‌گذاری نشده است.',
    COURSE_PURCHASE_EXISTS: 'این دوره قبلاً خریداری شده یا یک سفارش پرداخت‌نشده برای آن داری.',
    INVALID_ORDER: 'سبد خرید معتبر نیست.',
  }
  return messages[code] ?? 'ثبت سفارش انجام نشد؛ اطلاعات را بررسی و دوباره تلاش کنید.'
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (request.method !== 'POST') return response({ error: 'روش درخواست پشتیبانی نمی‌شود.' }, 405)

  const authorization = request.headers.get('Authorization')
  if (!authorization?.startsWith('Bearer ')) return response({ error: 'برای ثبت سفارش وارد حساب شو.' }, 401)

  const supabaseUrl = Deno.env.get('SUPABASE_URL')
  const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  if (!supabaseUrl || !serviceRoleKey) return response({ error: 'اتصال امن سرور آماده نیست.' }, 503)
  const server = createClient(supabaseUrl, serviceRoleKey, { auth: { persistSession: false, autoRefreshToken: false } })
  const token = authorization.slice('Bearer '.length)
  const { data: userData, error: userError } = await server.auth.getUser(token)
  if (userError || !userData.user) return response({ error: 'نشست ورود معتبر نیست؛ دوباره وارد شو.' }, 401)

  let payload: Record<string, unknown>
  try {
    payload = await request.json()
  } catch {
    return response({ error: 'درخواست سفارش قابل‌خواندن نیست.' }, 400)
  }

  const parsedItems = parseOrderLines(payload.items)
  if ('error' in parsedItems) return response({ error: errorMessage(parsedItems.error) }, 400)

  const rawShipping = payload.shipping && typeof payload.shipping === 'object' ? payload.shipping as Record<string, unknown> : {}
  const shipping = {
    full_name: String(rawShipping.full_name ?? '').trim(),
    phone: String(rawShipping.phone ?? '').trim(),
    province: String(rawShipping.province ?? '').trim(),
    city: String(rawShipping.city ?? '').trim(),
    address: String(rawShipping.address ?? '').trim(),
    postal_code: String(rawShipping.postal_code ?? '').trim(),
  }
  const idempotencyKey = String(payload.idempotency_key ?? '')
  const consent = {
    privacy: payload.consent && typeof payload.consent === 'object' && (payload.consent as Record<string, unknown>).privacy === true,
    terms: payload.consent && typeof payload.consent === 'object' && (payload.consent as Record<string, unknown>).terms === true,
  }

  const { data: order, error } = await server.rpc('qnr_create_order', {
    p_user_id: userData.user.id,
    p_items: parsedItems.lines,
    p_idempotency_key: idempotencyKey,
    p_shipping: shipping,
    p_consent: consent,
  })
  if (error) {
    const code = error.message.match(/[A-Z_]{4,}/)?.[0] ?? 'ORDER_FAILED'
    const status = ['CHECKOUT_NOT_CONFIGURED', 'POLICY_PAGES_REQUIRED'].includes(code) ? 503 : ['PRODUCT_UNAVAILABLE', 'INSUFFICIENT_STOCK', 'COURSE_UNAVAILABLE', 'COURSE_PURCHASE_EXISTS'].includes(code) ? 409 : 400
    return response({ error: errorMessage(code) }, status)
  }
  return response({ order })
})
