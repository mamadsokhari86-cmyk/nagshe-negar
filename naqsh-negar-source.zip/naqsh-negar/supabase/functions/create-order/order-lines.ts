export type OrderLine =
  | { product_id: string; quantity: number }
  | { course_id: string; quantity: 1 }

export type OrderLineParseResult = { lines: OrderLine[] } | { error: 'INVALID_ORDER' }

const UUID_PATTERN = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i

export function parseOrderLines(raw: unknown): OrderLineParseResult {
  if (!Array.isArray(raw) || raw.length < 1 || raw.length > 50) return { error: 'INVALID_ORDER' }

  const lines: OrderLine[] = []
  const seenCourses = new Set<string>()

  for (const candidate of raw) {
    if (!candidate || typeof candidate !== 'object' || Array.isArray(candidate)) return { error: 'INVALID_ORDER' }

    const entry = candidate as Record<string, unknown>
    const hasProduct = Object.prototype.hasOwnProperty.call(entry, 'product_id')
    const hasCourse = Object.prototype.hasOwnProperty.call(entry, 'course_id')
    const quantity = entry.quantity

    if (hasProduct === hasCourse || typeof quantity !== 'number' || !Number.isInteger(quantity) || quantity < 1 || quantity > 99) {
      return { error: 'INVALID_ORDER' }
    }

    if (hasProduct) {
      const productId = entry.product_id
      if (typeof productId !== 'string' || !UUID_PATTERN.test(productId)) return { error: 'INVALID_ORDER' }
      lines.push({ product_id: productId, quantity })
      continue
    }

    const courseId = entry.course_id
    if (typeof courseId !== 'string' || !UUID_PATTERN.test(courseId) || quantity !== 1 || seenCourses.has(courseId)) {
      return { error: 'INVALID_ORDER' }
    }
    seenCourses.add(courseId)
    lines.push({ course_id: courseId, quantity: 1 })
  }

  return { lines }
}
