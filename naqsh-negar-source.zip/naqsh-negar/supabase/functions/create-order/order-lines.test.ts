import assert from 'node:assert/strict'
import test from 'node:test'
import { parseOrderLines } from './order-lines.ts'

const productId = '22222222-2222-4222-8222-222222222222'
const courseId = '33333333-3333-4333-8333-333333333333'

test('accepts a product line and preserves its quantity', () => {
  assert.deepEqual(parseOrderLines([{ product_id: productId, quantity: 3 }]), {
    lines: [{ product_id: productId, quantity: 3 }],
  })
})

test('accepts a single course line', () => {
  assert.deepEqual(parseOrderLines([{ course_id: courseId, quantity: 1 }]), {
    lines: [{ course_id: courseId, quantity: 1 }],
  })
})

test('accepts mixed product and course lines', () => {
  assert.deepEqual(parseOrderLines([
    { product_id: productId, quantity: 2 },
    { course_id: courseId, quantity: 1 },
  ]), {
    lines: [
      { product_id: productId, quantity: 2 },
      { course_id: courseId, quantity: 1 },
    ],
  })
})

test('rejects empty, non-array, and oversized orders', () => {
  assert.deepEqual(parseOrderLines(null), { error: 'INVALID_ORDER' })
  assert.deepEqual(parseOrderLines([]), { error: 'INVALID_ORDER' })
  assert.deepEqual(parseOrderLines(Array.from({ length: 51 }, () => ({ product_id: productId, quantity: 1 }))), {
    error: 'INVALID_ORDER',
  })
})

test('rejects missing, conflicting, or malformed item identifiers', () => {
  assert.deepEqual(parseOrderLines([{ quantity: 1 }]), { error: 'INVALID_ORDER' })
  assert.deepEqual(parseOrderLines([{ product_id: productId, course_id: courseId, quantity: 1 }]), { error: 'INVALID_ORDER' })
  assert.deepEqual(parseOrderLines([{ product_id: 'not-a-uuid', quantity: 1 }]), { error: 'INVALID_ORDER' })
})

test('rejects invalid quantities and repeated course lines', () => {
  assert.deepEqual(parseOrderLines([{ product_id: productId, quantity: 0 }]), { error: 'INVALID_ORDER' })
  assert.deepEqual(parseOrderLines([{ product_id: productId, quantity: '1' }]), { error: 'INVALID_ORDER' })
  assert.deepEqual(parseOrderLines([{ course_id: courseId, quantity: 2 }]), { error: 'INVALID_ORDER' })
  assert.deepEqual(parseOrderLines([
    { course_id: courseId, quantity: 1 },
    { course_id: courseId, quantity: 1 },
  ]), { error: 'INVALID_ORDER' })
})
