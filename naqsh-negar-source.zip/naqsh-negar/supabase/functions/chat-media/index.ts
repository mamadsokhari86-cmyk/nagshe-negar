import { createClient } from 'npm:@supabase/supabase-js@2'
import { stripGalleryImageMetadata, validateGalleryImage } from '../_shared/gallery-validation.ts'
import { isChatNonce } from '../_shared/chat-validation.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const bucket = 'qnr-chat'
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/iu
const imagePath = /^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})\/([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})\.(jpg|png|webp)$/iu

function respond(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
  })
}

function record(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value))
}

function missingObject(error: { message?: string } | null) {
  return Boolean(error && /not found|does not exist|404/iu.test(error.message ?? ''))
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (request.method !== 'POST') return respond({ error: 'روش درخواست پشتیبانی نمی‌شود.' }, 405)
  const authorization = request.headers.get('Authorization')
  if (!authorization?.startsWith('Bearer ')) return respond({ error: 'برای ادامه وارد حساب شو.' }, 401)
  if (Number(request.headers.get('Content-Length') ?? 0) > 65536) return respond({ error: 'درخواست بیش از اندازه بزرگ است.' }, 413)

  const url = Deno.env.get('SUPABASE_URL')
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  const publicKey = Deno.env.get('SUPABASE_PUBLISHABLE_KEY') ?? Deno.env.get('SUPABASE_ANON_KEY') ?? request.headers.get('apikey')
  if (!url || !serviceKey || !publicKey) return respond({ error: 'اتصال امن سرور آماده نیست.' }, 503)
  const service = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } })
  const token = authorization.slice('Bearer '.length)
  const { data: userData, error: authError } = await service.auth.getUser(token)
  if (authError || !userData.user) return respond({ error: 'نشست ورود معتبر نیست؛ دوباره وارد شو.' }, 401)
  const caller = createClient(url, publicKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  })

  let payload: Record<string, unknown>
  try {
    const input: unknown = await request.json()
    if (!record(input)) return respond({ error: 'درخواست قابل‌خواندن نیست.' }, 400)
    payload = input
  } catch {
    return respond({ error: 'درخواست قابل‌خواندن نیست.' }, 400)
  }

  const path = payload.image_path
  const match = typeof path === 'string' ? path.match(imagePath) : null
  if (!match || !uuid.test(String(payload.room_id)) || match[1].toLowerCase() !== String(payload.room_id).toLowerCase()) {
    return respond({ error: 'نشانی فایل یا اتاق معتبر نیست.' }, 400)
  }

  if (payload.action === 'discard') {
    const { data: canDelete, error: ticketError } = await service.rpc('qnr_chat_delete_upload_ticket', {
      p_user_id: userData.user.id,
      p_object_path: path,
    })
    if (ticketError) return respond({ error: 'وضعیت عکس بررسی نشد؛ دوباره تلاش کن.' }, 503)
    if (canDelete === false) return respond({ error: 'این عکس قبلاً به پیامی پیوست شده است.' }, 409)
    const { data: ownedObject, error: ownershipError } = await caller.storage.from(bucket).download(path)
    if (ownershipError || !ownedObject) return respond({ ok: true, already_removed: true })
    const { error: removeError } = await service.storage.from(bucket).remove([path])
    if (removeError && !missingObject(removeError)) return respond({ error: 'پاک‌سازی عکس نیمه‌کاره انجام نشد.' }, 503)
    return respond({ ok: true })
  }

  if (payload.action !== 'register' || !isChatNonce(payload.client_nonce)) {
    return respond({ error: 'این عملیات یا شناسهٔ پیام معتبر نیست.' }, 400)
  }

  const { data: original, error: downloadError } = await caller.storage.from(bucket).download(path)
  if (downloadError || !original) return respond({ error: 'عکس در فضای خصوصی حسابت پیدا نشد.' }, 403)
  const validation = await validateGalleryImage(original)
  if (!validation.ok) return respond({ error: validation.error === 'too_large' ? 'عکس کمی بزرگ است؛ لطفاً نسخه‌ای زیر ۱۰ مگابایت انتخاب کن.' : 'محتوای عکس با نوع فایل هم‌خوانی ندارد.' }, validation.error === 'too_large' ? 413 : 415)
  if (validation.extension !== match[3].toLowerCase()) return respond({ error: 'محتوای عکس با نوع فایل هم‌خوانی ندارد.' }, 415)
  const bytes = new Uint8Array(await original.arrayBuffer())
  const cleanBytes = stripGalleryImageMetadata(bytes, validation.mimeType)
  if (!cleanBytes) return respond({ error: 'ساختار عکس معتبر نیست یا پاک‌سازی اطلاعات آن انجام نشد.' }, 415)

  const { error: removeRawError } = await service.storage.from(bucket).remove([path])
  if (removeRawError && !missingObject(removeRawError)) return respond({ error: 'آماده‌سازی امن عکس انجام نشد؛ دوباره تلاش کن.' }, 503)
  const { error: sanitizedUploadError } = await caller.storage.from(bucket).upload(
    path,
    new Blob([cleanBytes], { type: validation.mimeType }),
    { contentType: validation.mimeType, cacheControl: '300', upsert: false },
  )
  if (sanitizedUploadError) return respond({ error: 'پاک‌سازی اطلاعات عکس انجام نشد؛ عکس را دوباره بارگذاری کن.' }, 503)

  const { data: linkedMessageId, error: ticketError } = await service.rpc('qnr_chat_register_upload_ticket', {
    p_user_id: userData.user.id,
    p_room_id: payload.room_id,
    p_client_nonce: payload.client_nonce,
    p_object_path: path,
  })
  if (ticketError) {
    console.error('chat upload registration failed', ticketError.code)
    return respond({ error: 'اتاق یا مالکیت عکس تأیید نشد؛ عکس را دوباره انتخاب کن.' }, 409)
  }
  return respond({ ok: true, image_path: path, message_id: linkedMessageId ?? null })
})
