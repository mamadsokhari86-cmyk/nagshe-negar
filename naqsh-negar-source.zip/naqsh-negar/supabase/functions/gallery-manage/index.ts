import { createClient } from 'npm:@supabase/supabase-js@2'
import { normalizeGalleryText, stripGalleryImageMetadata, validateGalleryImage } from '../_shared/gallery-validation.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}
const bucket = 'qnr-gallery'
const uuid = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
const imagePath = /^([0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12})[.](jpg|png|webp)$/i
const topics = new Set(['pattern', 'color', 'materials', 'technique', 'project', 'other'])
const uses = new Set(['quilt', 'home', 'accessory', 'clothing', 'other'])
const levels = new Set(['beginner', 'intermediate', 'advanced'])
const colors = new Set(['red', 'orange', 'yellow', 'green', 'blue', 'purple', 'neutral', 'mixed'])

function respond(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' },
  })
}

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === 'object' && !Array.isArray(value))
}

function isUuid(value: unknown): value is string {
  return typeof value === 'string' && uuid.test(value)
}

function isSafeImagePath(value: unknown): value is string {
  return typeof value === 'string' && imagePath.test(value)
}

function missingObject(error: { message?: string } | null) {
  return Boolean(error && /not found|does not exist|404/iu.test(error.message ?? ''))
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (request.method !== 'POST') return respond({ error: 'روش درخواست پشتیبانی نمی‌شود.' }, 405)
  const authorization = request.headers.get('Authorization')
  if (!authorization?.startsWith('Bearer ')) return respond({ error: 'برای ادامه وارد حساب شو.' }, 401)
  const contentLength = Number(request.headers.get('Content-Length') ?? 0)
  if (contentLength > 65536) return respond({ error: 'درخواست بیش از اندازه بزرگ است.' }, 413)

  const url = Deno.env.get('SUPABASE_URL')
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  const publishableKey = Deno.env.get('SUPABASE_PUBLISHABLE_KEY')
    ?? Deno.env.get('SUPABASE_ANON_KEY')
    ?? request.headers.get('apikey')
  if (!url || !serviceKey || !publishableKey) return respond({ error: 'اتصال امن سرور آماده نیست.' }, 503)

  const server = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } })
  const token = authorization.slice('Bearer '.length)
  const { data: userData, error: authError } = await server.auth.getUser(token)
  if (authError || !userData.user) return respond({ error: 'نشست ورود معتبر نیست؛ دوباره وارد شو.' }, 401)
  const caller = createClient(url, publishableKey, {
    global: { headers: { Authorization: authorization } },
    auth: { persistSession: false, autoRefreshToken: false },
  })

  let payload: Record<string, unknown>
  try {
    const value: unknown = await request.json()
    if (!isRecord(value)) return respond({ error: 'درخواست قابل‌خواندن نیست.' }, 400)
    payload = value
  } catch {
    return respond({ error: 'درخواست قابل‌خواندن نیست.' }, 400)
  }

  const action = payload.action
  if (action === 'register') {
    const path = payload.image_path
    const pathMatch = typeof path === 'string' ? path.match(imagePath) : null
    if (!isSafeImagePath(path) || !pathMatch) return respond({ error: 'نشانی فایل معتبر نیست.' }, 400)
    const { data: linkedPost, error: pathLookupError } = await server.from('qnr_gallery_posts').select('id').eq('image_path', path).maybeSingle()
    if (pathLookupError) return respond({ error: 'وضعیت فایل بررسی نشد.' }, 503)
    if (linkedPost) return respond({ error: 'این عکس قبلاً به یک اثر ثبت‌شده پیوست شده است.' }, 409)
    const title = typeof payload.title === 'string' ? payload.title : ''
    const caption = typeof payload.caption === 'string' ? payload.caption : ''
    const text = normalizeGalleryText(title, caption)
    if (!text.ok) return respond({ error: text.error === 'title_length' ? 'عنوان باید بین ۲ تا ۱۰۰ نویسه باشد.' : 'توضیح بیش از اندازه بلند است.' }, 400)
    const topic = payload.topic
    const useCase = payload.use_case
    const level = payload.skill_level
    const visibility = payload.visibility
    const consent = payload.publication_consent === true
    const family = payload.color_family
    if (typeof topic !== 'string' || !topics.has(topic)
      || typeof useCase !== 'string' || !uses.has(useCase)
      || typeof level !== 'string' || !levels.has(level)
      || (visibility !== 'private' && visibility !== 'public')
      || (visibility === 'public' && !consent)
      || !Array.isArray(family) || family.length > 4
      || family.some((entry) => typeof entry !== 'string' || !colors.has(entry))
      || new Set(family).size !== family.length) {
      return respond({ error: 'یکی از دسته‌بندی‌ها یا گزینه‌های انتشار معتبر نیست.' }, 400)
    }

    const { data: object, error: downloadError } = await caller.storage.from(bucket).download(path)
    if (downloadError || !object) return respond({ error: 'فایل در فضای خصوصی حساب پیدا نشد.' }, 403)
    const imageCheck = await validateGalleryImage(object)
    if (!imageCheck.ok || imageCheck.extension !== pathMatch[2].toLowerCase()) {
      return respond({ error: 'محتوای فایل با نوع و پسوند اعلام‌شده هم‌خوانی ندارد.' }, 415)
    }
    const imageBytes = new Uint8Array(await object.arrayBuffer())
    const cleanedBytes = stripGalleryImageMetadata(imageBytes, imageCheck.mimeType)
    if (!cleanedBytes) return respond({ error: 'ساختار عکس معتبر نیست یا پاک‌سازی اطلاعات نهفتهٔ آن انجام نشد.' }, 415)
    const { error: removeOriginalError } = await server.storage.from(bucket).remove([path])
    if (removeOriginalError && !missingObject(removeOriginalError)) return respond({ error: 'آماده‌سازی امن عکس انجام نشد؛ دوباره تلاش کن.' }, 503)
    const { error: sanitizeUploadError } = await caller.storage.from(bucket).upload(
      path, new Blob([cleanedBytes], { type: imageCheck.mimeType }),
      { contentType: imageCheck.mimeType, cacheControl: '300', upsert: false },
    )
    if (sanitizeUploadError) return respond({ error: 'پاک‌سازی اطلاعات نهفتهٔ عکس انجام نشد؛ دوباره تلاش کن.' }, 503)

    const { data: post, error: insertError } = await server.from('qnr_gallery_posts').insert({
      owner_id: userData.user.id,
      title: text.title,
      caption: text.caption,
      topic,
      use_case: useCase,
      skill_level: level,
      color_family: family,
      image_path: path,
      visibility,
      publication_consent: consent,
    }).select('id,review_status').single()
    if (insertError || !post) {
      console.error('gallery register failed', insertError?.code)
      return respond({ error: insertError?.code === 'P0001' ? 'سقف ثبت اثر روزانه پر شده است.' : 'ثبت اثر انجام نشد؛ دوباره تلاش کن.' }, 409)
    }
    return respond({ id: post.id, review_status: post.review_status })
  }

  if (action === 'discard') {
    const path = payload.image_path
    if (!isSafeImagePath(path)) return respond({ error: 'نشانی فایل معتبر نیست.' }, 400)
    const { data: attached, error: attachedError } = await server.from('qnr_gallery_posts').select('id').eq('image_path', path).maybeSingle()
    if (attachedError) return respond({ error: 'وضعیت فایل بررسی نشد.' }, 503)
    if (attached) return respond({ error: 'این فایل به یک اثر ثبت‌شده پیوست شده است.' }, 409)
    const { data: ownedFile, error: ownershipError } = await caller.storage.from(bucket).download(path)
    if (ownershipError || !ownedFile) return respond({ ok: true, already_removed: true })
    const { error: removeError } = await server.storage.from(bucket).remove([path])
    if (removeError && !missingObject(removeError)) return respond({ error: 'پاک‌سازی فایل نیمه‌کاره انجام نشد.' }, 503)
    return respond({ ok: true })
  }

  if (action === 'delete') {
    const postId = payload.post_id
    if (!isUuid(postId)) return respond({ error: 'شناسهٔ اثر معتبر نیست.' }, 400)
    const { data: post, error: lookupError } = await server.from('qnr_gallery_posts')
      .select('id,owner_id,image_path').eq('id', postId).maybeSingle()
    if (lookupError) return respond({ error: 'اثر دریافت نشد.' }, 503)
    if (!post || post.owner_id !== userData.user.id) return respond({ error: 'اثر در حساب تو پیدا نشد.' }, 404)

    const { error: hideError } = await server.from('qnr_gallery_posts').update({
      visibility: 'private', publication_consent: false, consent_version: null, consented_at: null,
      review_status: 'private', moderation_note: null, reviewed_by: null, reviewed_at: null,
    }).eq('id', postId).eq('owner_id', userData.user.id)
    if (hideError) return respond({ error: 'برداشتن اثر از نمایش عمومی انجام نشد.' }, 503)

    const { error: removeError } = await server.storage.from(bucket).remove([post.image_path])
    if (removeError && !missingObject(removeError)) return respond({ error: 'اثر از نمایش عمومی برداشته شد، اما پاک‌کردن فایل کامل نشد؛ دوباره تلاش کن.' }, 503)
    const { error: deleteError } = await server.from('qnr_gallery_posts').delete().eq('id', postId).eq('owner_id', userData.user.id)
    if (deleteError) return respond({ error: 'اثر خصوصی شد، اما حذف نهایی انجام نشد؛ دوباره تلاش کن.' }, 503)
    return respond({ ok: true })
  }

  return respond({ error: 'این عملیات پشتیبانی نمی‌شود.' }, 400)
})
