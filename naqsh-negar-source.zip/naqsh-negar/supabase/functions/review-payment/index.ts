import { createClient } from 'npm:@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
}

function response(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { ...corsHeaders, 'Content-Type': 'application/json; charset=utf-8' } })
}

Deno.serve(async (request: Request) => {
  if (request.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders })
  if (request.method !== 'POST') return response({ error: 'روش درخواست پشتیبانی نمی‌شود.' }, 405)
  const authorization = request.headers.get('Authorization')
  if (!authorization?.startsWith('Bearer ')) return response({ error: 'نشست مدیر معتبر نیست.' }, 401)
  const url = Deno.env.get('SUPABASE_URL')
  const serviceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')
  if (!url || !serviceKey) return response({ error: 'اتصال امن سرور آماده نیست.' }, 503)
  const server = createClient(url, serviceKey, { auth: { persistSession: false, autoRefreshToken: false } })
  const token = authorization.slice('Bearer '.length)
  const { data: userData, error: userError } = await server.auth.getUser(token)
  if (userError || !userData.user) return response({ error: 'نشست ورود معتبر نیست؛ دوباره وارد شو.' }, 401)
  const { data: role, error: roleError } = await server.from('qnr_user_roles').select('user_id').eq('user_id', userData.user.id).eq('role', 'admin').maybeSingle()
  if (roleError || !role) return response({ error: 'این حساب اجازهٔ بررسی رسید را ندارد.' }, 403)

  let payload: Record<string, unknown>
  try { payload = await request.json() } catch { return response({ error: 'درخواست بررسی قابل‌خواندن نیست.' }, 400) }
  const paymentId = String(payload.payment_id ?? '')
  const decision = String(payload.decision ?? '')
  const reason = String(payload.reason ?? '').trim()
  if (!/^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(paymentId)
    || !['approved', 'rejected'].includes(decision)
    || (decision === 'rejected' && reason.length < 4)) {
    return response({ error: 'اطلاعات بررسی کامل یا معتبر نیست.' }, 400)
  }
  const { data, error } = await server.rpc('qnr_review_payment', {
    p_actor_id: userData.user.id,
    p_payment_id: paymentId,
    p_decision: decision,
    p_reason: reason || null,
  })
  if (error) return response({ error: 'بررسی رسید ثبت نشد؛ ممکن است مهلت سفارش پایان یافته یا رسید قبلاً بررسی شده باشد.' }, 409)
  return response({ status: data?.status ?? 'not_found', order_id: data?.order_id ?? null })
})
